package io.aeron.spring.archive.receiver.controller;

import io.aeron.spring.archive.receiver.service.ArchiveReceiverService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * REST API：查询实时消息、触发 Archive 历史回放。
 *
 * <pre>
 * GET  /status    查询 Subscription 连接状态和消息统计
 * GET  /messages  查询最近收到的消息（实时 + 历史混合）
 * POST /replay    触发一次 Archive 历史回放（同步，等待回放结束返回）
 * </pre>
 */
@RestController
public class ArchiveReceiverController
{
    private final ArchiveReceiverService receiverService;

    public ArchiveReceiverController(final ArchiveReceiverService receiverService)
    {
        this.receiverService = receiverService;
    }

    /**
     * 查询 Subscription 状态和消息统计。
     *
     * <p>请求示例：
     * <pre>
     * curl http://localhost:7083/status
     * </pre>
     */
    @GetMapping("/status")
    public ResponseEntity<ArchiveReceiverService.ReceiverStatus> status()
    {
        return ResponseEntity.ok(receiverService.status());
    }

    /**
     * 查询最近收到的消息列表（实时 + 回放混合，按到达时间排序）。
     *
     * <p>请求示例：
     * <pre>
     * curl http://localhost:7083/messages
     * </pre>
     */
    @GetMapping("/messages")
    public ResponseEntity<List<ArchiveReceiverService.ReceivedMessage>> messages()
    {
        return ResponseEntity.ok(receiverService.getRecentMessages());
    }

    /**
     * 触发一次 Archive 历史回放（同步阻塞直到回放结束）。
     *
     * <p>回放流程：连接 sender Archive → 查找最新 recordingId → 请求回放 → 读完返回。
     *
     * <p>请求示例：
     * <pre>
     * curl -X POST http://localhost:7083/replay
     * </pre>
     */
    @PostMapping("/replay")
    public ResponseEntity<Map<String, Object>> replay()
    {
        try
        {
            final long replayedCount = receiverService.triggerReplay();
            return ResponseEntity.ok(Map.of(
                "success",       true,
                "replayedCount", replayedCount
            ));
        }
        catch (final IllegalStateException e)
        {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }
}
