package io.aeron.spring.archive.receiver.service;

import io.aeron.Aeron;
import io.aeron.ChannelUri;
import io.aeron.Image;
import io.aeron.Subscription;
import io.aeron.archive.client.AeronArchive;
import io.aeron.archive.client.RecordingDescriptorConsumer;
import io.aeron.driver.MediaDriver;
import io.aeron.logbuffer.FragmentHandler;
import io.aeron.spring.archive.receiver.config.ArchiveReceiverProperties;
import io.aeron.spring.cluster.config.ContextFactory;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.agrona.CloseHelper;
import org.agrona.collections.MutableLong;
import org.agrona.concurrent.SleepingIdleStrategy;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Spring Service：封装 Aeron Archive 接收端逻辑。
 *
 * <h3>功能（对应 ArchiveReceiver demo）</h3>
 * <ol>
 *   <li><b>实时接收</b>：启动独立 poll 线程，持续订阅实时 UDP 流，收到消息后缓存并通知注册的监听器。</li>
 *   <li><b>历史回放</b>：调用 {@link #triggerReplay()} 后，连接 sender 的 Archive 服务，
 *       查询最新 recordingId，请求回放，将历史消息一次性读出并追加到消息缓存。</li>
 * </ol>
 *
 * <h3>线程模型</h3>
 * <p>实时 poll 由专用后台线程执行；回放由调用 {@link #triggerReplay()} 的 HTTP 线程同步执行
 * （期间暂停 live poll，回放结束后恢复），与 ArchiveReceiver demo 的 {@code doReplay} 逻辑一致。
 *
 * <h3>回放流程（对应 ArchiveReceiver.doReplay）</h3>
 * <ol>
 *   <li>通过 {@link AeronArchive} 连接 sender 的 Archive 控制端口</li>
 *   <li>{@code listRecordingsForUri} 找到最新 recordingId</li>
 *   <li>{@code startReplay} 触发回放，Archive 侧读盘并以 UDP 发到 replayChannel</li>
 *   <li>订阅带 sessionId 的 replayChannel，poll 直到 {@link Image} 关闭（录制读完）</li>
 * </ol>
 */
@Service
public class ArchiveReceiverService
{
    private final ArchiveReceiverProperties props;

    private MediaDriver  mediaDriver;
    private Aeron        aeron;
    private Subscription liveSubscription;

    private Thread           pollThread;
    private volatile boolean running      = false;
    /** 回放执行中标志，通知 poll 线程暂停 live poll */
    private final AtomicBoolean replaying = new AtomicBoolean(false);

    private final AtomicLong liveCount   = new AtomicLong(0);
    private final AtomicLong replayCount = new AtomicLong(0);

    private final CopyOnWriteArrayList<ReceivedMessage> recentMessages = new CopyOnWriteArrayList<>();

    public ArchiveReceiverService(final ArchiveReceiverProperties props)
    {
        this.props = props;
    }

    // ──────────────────────────────────────────────
    // 生命周期
    // ──────────────────────────────────────────────

    @PostConstruct
    public void start()
    {
        System.out.println("[ArchiveReceiver] liveChannel=" + props.getLiveChannel()
            + "  liveStreamId=" + props.getLiveStreamId());
        System.out.println("[ArchiveReceiver] controlRequestChannel=" + props.getControlRequestChannel());

        mediaDriver      = MediaDriver.launch(ContextFactory.mediaDriverContext(props.getMediaDriver())
            .errorHandler(Throwable::printStackTrace));
        aeron            = Aeron.connect(ContextFactory.aeronContext(
            props.getAeron(), mediaDriver.aeronDirectoryName()));
        liveSubscription = aeron.addSubscription(props.getLiveChannel(), props.getLiveStreamId());

        startPollThread();
    }

    @PreDestroy
    public void stop()
    {
        System.out.println("[ArchiveReceiver] Stopping...");
        running = false;
        if (pollThread != null)
        {
            pollThread.interrupt();
        }
        CloseHelper.closeAll(liveSubscription, aeron, mediaDriver);
    }

    // ──────────────────────────────────────────────
    // 公开接口（HTTP 线程调用）
    // ──────────────────────────────────────────────

    /**
     * 触发历史回放（同步执行）。
     *
     * <p>连接 sender 的 Archive 服务，查找最新录制，请求回放，
     * 将所有历史消息读出并追加到 {@link #recentMessages}。
     *
     * @return 本次回放读取的消息条数
     * @throws IllegalStateException Archive 连接失败或无录制记录
     */
    public long triggerReplay()
    {
        replaying.set(true);
        try
        {
            return doReplay();
        }
        finally
        {
            replaying.set(false);
        }
    }

    /** 返回最近收到的消息列表（实时 + 历史回放，混合按到达顺序排列） */
    public List<ReceivedMessage> getRecentMessages()
    {
        return new ArrayList<>(recentMessages);
    }

    /** 查询当前状态快照 */
    public ReceiverStatus status()
    {
        final Subscription sub = liveSubscription;
        return new ReceiverStatus(
            sub != null && !sub.isClosed(),
            props.getLiveChannel(),
            props.getLiveStreamId(),
            props.getControlRequestChannel(),
            sub != null ? sub.imageCount() : 0,
            liveCount.get(),
            replayCount.get(),
            replaying.get());
    }

    // ──────────────────────────────────────────────
    // poll 线程（实时接收）
    // ──────────────────────────────────────────────

    private void startPollThread()
    {
        running    = true;
        pollThread = new Thread(this::pollLoop, "aeron-archive-receiver-poll");
        pollThread.setDaemon(true);
        pollThread.start();
        System.out.println("[ArchiveReceiver] Poll thread started");
    }

    /**
     * 实时 poll 主循环。
     *
     * <p>回放期间（{@link #replaying} 为 true）暂停 poll，避免和回放线程竞争 Aeron 资源。
     * 回放结束后自动恢复。
     */
    private void pollLoop()
    {
        final SleepingIdleStrategy idle = new SleepingIdleStrategy(TimeUnit.MILLISECONDS.toNanos(1));

        final FragmentHandler liveHandler = (buffer, offset, length, header) ->
        {
            final byte[] bytes = new byte[length];
            buffer.getBytes(offset, bytes);
            final String text = new String(bytes, StandardCharsets.UTF_8);
            final long seq = liveCount.incrementAndGet();

            System.out.println("[ArchiveReceiver] Live #" + seq + ": " + text);
            appendMessage(new ReceivedMessage(text, bytes, System.currentTimeMillis(), "live", seq));
        };

        while (running && !Thread.currentThread().isInterrupted())
        {
            if (replaying.get())
            {
                // 回放中，让出 CPU
                idle.idle(0);
                continue;
            }
            final int fragmentsRead = liveSubscription.poll(liveHandler, props.getFragmentLimit());
            idle.idle(fragmentsRead);
        }
    }

    // ──────────────────────────────────────────────
    // 回放（HTTP 线程调用，对应 ArchiveReceiver.doReplay）
    // ──────────────────────────────────────────────

    /**
     * 回放核心逻辑，与 ArchiveReceiver demo 的 {@code doReplay} 方法对应：
     * <ol>
     *   <li>建立 AeronArchive 控制会话</li>
     *   <li>查找最新 recordingId</li>
     *   <li>startReplay 并订阅带 sessionId 的 replayChannel</li>
     *   <li>poll 直到 Image 关闭（录制读完）</li>
     * </ol>
     */
    private long doReplay()
    {
        try (AeronArchive archive = AeronArchive.connect(new AeronArchive.Context()
            .controlRequestChannel(props.getControlRequestChannel())
            .controlResponseChannel(props.getControlResponseChannel())
            .aeron(aeron)))
        {
            final long recordingId = findLatestRecording(archive);
            if (recordingId < 0)
            {
                throw new IllegalStateException(
                    "[ArchiveReceiver] No recording found. Please send messages first.");
            }

            System.out.println("[ArchiveReceiver] Replaying recordingId=" + recordingId);

            // startReplay 返回值低 32 位为 replay publication 的 sessionId
            final long sessionId = archive.startReplay(
                recordingId, 0L, Long.MAX_VALUE,
                props.getReplayChannel(), props.getReplayStreamId());

            final String replayChannelWithSession =
                ChannelUri.addSessionId(props.getReplayChannel(), (int) sessionId);

            final long[] count = { 0L };
            final FragmentHandler replayHandler = (buffer, offset, length, header) ->
            {
                final byte[] bytes = new byte[length];
                buffer.getBytes(offset, bytes);
                final String text = new String(bytes, StandardCharsets.UTF_8);
                count[0]++;
                final long seq = replayCount.incrementAndGet();

                System.out.println("[ArchiveReceiver] Replay #" + seq + ": " + text);
                appendMessage(new ReceivedMessage(text, bytes, System.currentTimeMillis(), "replay", seq));
            };

            try (Subscription replaySub = aeron.addSubscription(
                replayChannelWithSession, props.getReplayStreamId()))
            {
                final SleepingIdleStrategy idle =
                    new SleepingIdleStrategy(TimeUnit.MILLISECONDS.toNanos(1));

                // 等待与 Archive 侧 replay publication 建链
                while (!replaySub.isConnected())
                {
                    idle.idle();
                }

                final Image image = replaySub.imageAtIndex(0);

                // poll 直到 Image 关闭（Archive ReplaySession 读完后关闭 publication）
                while (true)
                {
                    final int fragments = image.poll(replayHandler, props.getFragmentLimit());
                    if (fragments == 0 && image.isClosed())
                    {
                        break;
                    }
                    idle.idle(fragments);
                }
            }

            System.out.println("[ArchiveReceiver] Replay done, count=" + count[0]);
            return count[0];
        }
        catch (final IllegalStateException e)
        {
            throw e;
        }
        catch (final Exception e)
        {
            throw new IllegalStateException("[ArchiveReceiver] Replay failed: " + e.getMessage(), e);
        }
    }

    /**
     * 从 Archive catalog 查找与 liveChannel/liveStreamId 匹配的最新 recordingId。
     * 与 ArchiveReceiver demo 的 {@code findLatestRecording} 方法对应。
     */
    private long findLatestRecording(final AeronArchive archive)
    {
        final MutableLong lastRecordingId = new MutableLong(-1);

        final RecordingDescriptorConsumer consumer =
            (controlSessionId, correlationId, recordingId,
             startTimestamp, stopTimestamp, startPosition, stopPosition,
             initialTermId, segmentFileLength, termBufferLength, mtuLength,
             sessionId, streamId, strippedChannel, originalChannel, sourceIdentity)
                -> lastRecordingId.set(recordingId);

        final int found = archive.listRecordingsForUri(
            0L, 100, props.getLiveChannel(), props.getLiveStreamId(), consumer);

        return found > 0 ? lastRecordingId.get() : -1;
    }

    // ──────────────────────────────────────────────
    // 私有工具
    // ──────────────────────────────────────────────

    private void appendMessage(final ReceivedMessage msg)
    {
        if (recentMessages.size() >= props.getRecentMessageLimit())
        {
            recentMessages.remove(0);
        }
        recentMessages.add(msg);
    }

    // ──────────────────────────────────────────────
    // 内部类型
    // ──────────────────────────────────────────────

    /**
     * 接收到的单条消息。
     *
     * @param text        UTF-8 解码后的消息内容
     * @param rawBytes    原始字节
     * @param timestampMs 接收时刻（毫秒）
     * @param source      消息来源："live" 或 "replay"
     * @param seq         该来源的顺序号
     */
    public record ReceivedMessage(
        String text,
        byte[] rawBytes,
        long   timestampMs,
        String source,
        long   seq) {}

    public record ReceiverStatus(
        boolean connected,
        String  liveChannel,
        int     liveStreamId,
        String  controlRequestChannel,
        int     imageCount,
        long    liveCount,
        long    replayCount,
        boolean replaying) {}
}
