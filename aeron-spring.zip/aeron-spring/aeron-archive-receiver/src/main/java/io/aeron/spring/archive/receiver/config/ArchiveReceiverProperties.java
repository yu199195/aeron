package io.aeron.spring.archive.receiver.config;

import io.aeron.spring.cluster.config.AeronContextProperties;
import io.aeron.spring.cluster.config.MediaDriverProperties;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.stereotype.Component;

/**
 * {@code aeron.archive.receiver.*} 配置映射。
 *
 * <p>核心参数说明：
 * <ul>
 *   <li>{@code liveChannel} / {@code liveStreamId} — 实时订阅通道，与 sender 的 publication 一致。</li>
 *   <li>{@code replayChannel} / {@code replayStreamId} — 回放专用通道，与 liveChannel 使用不同端口，
 *       避免和 sender 的实时流冲突。</li>
 *   <li>{@code controlRequestChannel} — Archive 服务所在地址（即 sender 的 controlRequestChannel），
 *       {@link io.aeron.archive.client.AeronArchive} 通过此建立控制会话。</li>
 * </ul>
 */
@Data
@Component
@ConfigurationProperties(prefix = "aeron.archive.receiver")
public class ArchiveReceiverProperties
{
    private String liveChannel            = "aeron:udp?endpoint=localhost:40456";
    private int    liveStreamId           = 10;
    private String replayChannel          = "aeron:udp?endpoint=localhost:40457";
    private int    replayStreamId         = 11;
    private String controlRequestChannel  = "aeron:udp?endpoint=localhost:8010";
    private String controlResponseChannel = "aeron:udp?endpoint=localhost:0";
    private int    fragmentLimit          = 10;
    private int    recentMessageLimit     = 100;

    @NestedConfigurationProperty
    private MediaDriverProperties mediaDriver = new MediaDriverProperties();

    @NestedConfigurationProperty
    private AeronContextProperties aeron = new AeronContextProperties();
}
