package io.aeron.spring.archive.receiver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

/**
 * Aeron Archive Receiver Spring Boot 启动类。
 *
 * <p>启动后：
 * <ul>
 *   <li>内嵌普通 {@link io.aeron.driver.MediaDriver}（无 Archive）</li>
 *   <li>后台 poll 线程持续订阅实时 UDP 流，可通过 {@code GET /messages} 查看</li>
 *   <li>通过 {@code POST /replay} 触发历史回放：连接 sender 的 Archive 服务，
 *       读取录制数据并追加到消息列表</li>
 * </ul>
 */
@SpringBootApplication
@EnableConfigurationProperties
public class AeronArchiveReceiverApplication
{
    public static void main(final String[] args)
    {
        SpringApplication.run(AeronArchiveReceiverApplication.class, args);
    }
}
