package io.aeron.spring.cluster.config;

import lombok.Data;

/**
 * MediaDriver 调优配置，绑定 {@code aeron.*.media-driver.*}。
 *
 * <h3>MediaDriver 的职责</h3>
 * MediaDriver 是 Aeron 的核心进程，负责管理底层 UDP 网络 I/O、
 * 内存映射的日志缓冲区（log-buffer）和 IPC 管道。
 * 集群节点使用嵌入式（Embedded）MediaDriver，与 JVM 进程共生。
 *
 * <h3>线程模型说明</h3>
 * <ul>
 *   <li><b>DEDICATED</b>（生产默认）：Sender / Receiver / Conductor 各独占一个线程，
 *       忙轮询（busy-spin），延迟最低，吞吐最高，但 CPU 占用最高（至少 3 核）。</li>
 *   <li><b>SHARED_NETWORK</b>：Sender 和 Receiver 共用一个线程，Conductor 独立，
 *       共 2 个线程；适合 2 核环境。</li>
 *   <li><b>SHARED</b>（开发默认）：三者共用一个线程，CPU 占用最低，
 *       但延迟和吞吐均较差；仅适用于开发/测试场景。</li>
 * </ul>
 */
@Data
public class MediaDriverProperties
{
    // ── 目录 ─────────────────────────────────────────────────────────────────

    /**
     * MediaDriver 共享内存目录（绝对路径）。
     * <p>
     * 指定 Aeron 日志缓冲区、CncFile 等文件的存放路径。
     * 同一主机上多个进程需使用不同目录以避免冲突。
     * 留空时由 Aeron 自动生成临时目录（{@code /tmp/aeron-<pid>}）。
     */
    private String aeronDirectoryName = "";

    // ── 线程模型 ─────────────────────────────────────────────────────────────

    /**
     * 线程模型。
     * <ul>
     *   <li>{@code DEDICATED}：Sender / Receiver / Conductor 各独占一个线程（生产推荐）</li>
     *   <li>{@code SHARED_NETWORK}：Sender + Receiver 共用一个线程，Conductor 独立</li>
     *   <li>{@code SHARED}：三者共用一个线程（开发/测试场景）</li>
     * </ul>
     */
    private String threadingMode = "DEDICATED";

    // ── 目录 ─────────────────────────────────────────────────────────────────

    /**
     * 是否在进程退出时删除 Aeron 目录（aeron-media-driver）。
     * 开发环境建议 {@code true}，生产建议 {@code false} 以保留崩溃诊断信息。
     */
    private boolean dirDeleteOnShutdown = false;

    /**
     * 是否在启动时打印完整配置参数（方便排查配置问题）。默认 false。
     */
    private boolean printConfigurationOnStart = false;

    // ── 缓冲区大小 ────────────────────────────────────────────────────────────

    /**
     * Conductor 缓冲区大小（字节）。
     * <p>
     * Driver 与客户端（Publication/Subscription）之间的命令通信环形缓冲区。
     * 使用 {@link org.agrona.concurrent.ringbuffer.ManyToOneRingBuffer}，
     * agrona 2.x 中 TRAILER_LENGTH = 768（6 × 128）。
     * 要求容量为 {@code 2^n + 768}，如 1_049_344、2_097_920、4_195_072。
     * 同时存在大量 Publication/Subscription 时可适当调大（如 4MB 对应 4_195_072）。
     */
    private int conductorBufferLength = 2_097_920; // 2^21 + 768

    /**
     * Driver 向客户端（Aeron）发送状态通知的广播缓冲区大小（字节）。
     * <p>
     * 使用 BroadcastTransmitter，要求 {@code capacity - 128 (TRAILER_LENGTH)} 必须是 2 的幂次。
     * 有效值形如 {@code 2^n + 128}，如 1048704、2097280、4194432。
     */
    private int toClientsBufferLength = 2_097_280; // 2^21 + 128

    /**
     * 错误日志缓冲区大小（字节）。
     * <p>
     * Driver 内部记录错误事件的环形缓冲区（{@link org.agrona.concurrent.ringbuffer.ManyToOneRingBuffer}）。
     * agrona 2.x 中 TRAILER_LENGTH = 768，要求容量为 {@code 2^n + 768}，如 2_097_920、4_195_072。
     * 错误频繁时可增大以保留更多历史记录。
     */
    private int errorBufferLength = 4_195_072; // 2^22 + 768

    /**
     * 丢包报告缓冲区大小（字节）。
     * <p>
     * 记录网络丢包事件，用于诊断和监控。
     * 使用 {@link org.agrona.concurrent.ringbuffer.ManyToOneRingBuffer}，
     * agrona 2.x 中 TRAILER_LENGTH = 768，要求容量为 {@code 2^n + 768}，如 2_097_920、4_195_072。
     */
    private int lossReportBufferLength = 2_097_920; // 2^21 + 768

    /**
     * 计数器值缓冲区大小（字节）。
     * <p>
     * 存储所有 Aeron 计数器（Counter）的当前值，通过共享内存暴露给外部监控工具。
     * 使用 {@link org.agrona.concurrent.ringbuffer.ManyToOneRingBuffer}，
     * agrona 2.x 中 TRAILER_LENGTH = 768，要求容量为 {@code 2^n + 768}，如 2_097_920、4_195_072。
     */
    private int counterValuesBufferLength = 2_097_920; // 2^21 + 768

    // ── Socket 缓冲区 ─────────────────────────────────────────────────────────

    /**
     * OS Socket 发送缓冲区大小（字节），0 = 使用操作系统默认值。
     * 高吞吐场景下调大可减少因 OS 缓冲溢出导致的丢包，建议与 net.core.wmem_max 对齐。
     */
    private int socketSndbufLength = 0;

    /**
     * OS Socket 接收缓冲区大小（字节），0 = 使用操作系统默认值。
     * 高吞吐场景下调大可减少因 OS 缓冲溢出导致的丢包，建议与 net.core.rmem_max 对齐。
     */
    private int socketRcvbufLength = 0;

    /**
     * 组播 Socket TTL（生存时间）。
     * <p>
     * 控制组播数据包能经过多少跳路由器转发。局域网内部通常设为 1 即可。默认 0（OS 默认）。
     */
    private int socketMulticastTtl = 0;

    // ── 流量控制与窗口 ────────────────────────────────────────────────────────

    /**
     * 流量控制初始窗口大小（字节）。
     * <p>
     * 接收方在发送 SM（状态消息）前愿意一次性接收的字节数。
     * 较大的值可提升高带宽低延迟网络的吞吐，但会增加内存用量。默认 128KB。
     */
    private int initialWindowLength = 131_072;

    /**
     * MTU（最大传输单元）大小（字节）。
     * <p>
     * UDP 单播发布的 MTU，影响每次传输的最大数据量。
     * 局域网万兆网推荐设为 8192（巨帧），默认 1408。
     */
    private int mtuLength = 1_408;

    /**
     * IPC（进程内）发布的 MTU 大小（字节）。默认与 {@link #mtuLength} 相同（1408）。
     */
    private int ipcMtuLength = 1_408;

    /**
     * 组播流控接收方超时（纳秒）。
     * <p>
     * 超过此时间未响应的接收方将从流控窗口中移除，避免慢接收方拖累整体吞吐。
     * 默认 5 秒（5_000_000_000）。
     */
    private long flowControlReceiverTimeoutNs = 5_000_000_000L;

    /**
     * 流控组标签（multicast/min-flow-control 时使用）。默认 -1（不启用）。
     */
    private long flowControlGroupTag = -1L;

    /**
     * 流控组最小成员数（min-flow-control 时使用）。
     * 达到该成员数后才开始发送。默认 0（不限制）。
     */
    private int flowControlGroupMinSize = 0;

    // ── Term 缓冲区 ───────────────────────────────────────────────────────────

    /**
     * 单播发布的 Term 缓冲区大小（字节）。
     * <p>
     * Term 是 Aeron 日志的基本分段单元，决定了在不丢失消息的情况下能缓冲多少数据。
     * 必须是 2 的幂次，范围 64KB ～ 1GB。默认 16MB。
     */
    private int publicationTermBufferLength = 16_777_216;

    /**
     * IPC 发布的 Term 缓冲区大小（字节）。默认 64MB，必须是 2 的幂次。
     */
    private int ipcTermBufferLength = 67_108_864;

    /**
     * 单播发布的 Term 窗口大小（字节），0 = 使用默认（Term 大小的一半）。
     * 较小的窗口可减少内存用量，但会降低吞吐。默认 0。
     */
    private int publicationTermWindowLength = 0;

    /**
     * IPC 发布的 Term 窗口大小（字节），0 = 使用默认。默认 0。
     */
    private int ipcPublicationTermWindowLength = 0;

    /**
     * Term 缓冲区是否使用稀疏文件（sparse file）。
     * <p>
     * 稀疏文件不预先分配磁盘空间，适合磁盘空间有限的开发环境。
     * 生产环境建议 false（预分配），可避免运行时 I/O 延迟抖动。默认 false。
     */
    private boolean termBufferSparseFile = false;

    /**
     * Term 文件的 page 对齐大小（字节）。
     * 必须 >= 4096（操作系统最小页大小）。大页内存（HugePages）场景可设为 2097152（2MB）。默认 4096。
     */
    private int filePageSize = 4096;

    // ── 发布行为 ─────────────────────────────────────────────────────────────

    /**
     * 是否允许 Spy 订阅模拟连接状态，使 Publication 认为有订阅者存在。
     * <p>
     * 启用后 Spy 订阅可触发 Publication 开始发送数据，适合调试和监控场景。默认 false。
     */
    private boolean spiesSimulateConnection = false;

    /**
     * 是否启用可靠传输（reliable delivery via NAK 重传）。
     * <p>
     * true（默认）= 通过 NAK 机制保证数据不丢失；false = 不重传，适合实时但可丢包场景。
     */
    private boolean reliableStream = true;

    /**
     * 发布在没有活跃订阅后继续保持连接的时间（纳秒）。
     * <p>
     * 避免短暂无订阅时 Publication 立即关闭连接。默认 5 秒（5_000_000_000）。
     */
    private long publicationLingerTimeoutNs = 5_000_000_000L;

    /**
     * 发布在检测到 Subscriber 无响应后等待多久认为阻塞（纳秒）。
     * <p>
     * 超时后 Driver 将尝试解除阻塞（unblock），避免整个发布管道卡住。默认 10 秒。
     */
    private long publicationUnblockTimeoutNs = 20_000_000_000L;

    /**
     * 发布从建立到确认连接的超时时间（纳秒）。默认 5 秒。
     */
    private long publicationConnectionTimeoutNs = 5_000_000_000L;

    /**
     * Session ID 保留范围下限。
     * <p>
     * 此范围内的 Session ID 由应用层显式分配，不由 Driver 自动生成。默认 -1（不保留）。
     */
    private int publicationReservedSessionIdLow = -1;

    /**
     * Session ID 保留范围上限。默认 1000。
     */
    private int publicationReservedSessionIdHigh = 1_000;

    // ── 订阅行为 ─────────────────────────────────────────────────────────────

    /**
     * 订阅是否默认 tethered（与 Publication 生命周期绑定）。
     * <p>
     * tethered = true 时，慢消费者会被驱逐以保护其他订阅者不受影响。默认 true。
     */
    private boolean tetherSubscriptions = true;

    /**
     * 订阅在与 Publication 断连后是否自动重新加入（rejoin）。
     * <p>
     * 适合流式场景（如多播），断连后自动重新加入组播组。默认 true。
     */
    private boolean rejoinStream = true;

    /**
     * Untethered 订阅在窗口被限制后的超时时间（纳秒）。
     * <p>
     * 超过此时间窗口仍未恢复，则订阅被暂时挂起（linger 状态）。默认 5 秒。
     */
    private long untetheredWindowLimitTimeoutNs = 5_000_000_000L;

    /**
     * 被挂起的 Untethered 订阅在 linger 状态下的等待时间（纳秒）。
     * <p>
     * 等待期满后重新尝试加入。默认 1 秒。
     */
    private long untetheredRestingTimeoutNs = 2_000_000_000L;

    // ── 重传与 NAK ────────────────────────────────────────────────────────────

    /**
     * 单播重传延迟（纳秒）。
     * <p>
     * 收到 NAK 后等待多久再重传，避免突发重传风暴。默认 0（立即重传）。
     */
    private long retransmitUnicastDelayNs = 0L;

    /**
     * 单播重传持续时间（纳秒）。
     * <p>
     * 每次重传后等待 ACK 的最长时间，超时后停止重传。默认 1 秒。
     */
    private long retransmitUnicastLingerNs = 1_000_000_000L;

    /**
     * 单播 NAK 延迟（纳秒）。
     * <p>
     * 检测到丢包后等待多久才发送 NAK，避免突发 NAK 请求。默认 60 毫秒。
     */
    private long nakUnicastDelayNs = 60_000_000L;

    /**
     * 单播 NAK 重试间隔倍率。
     * <p>
     * 每次重试间隔 = 上次间隔 × 此倍率（指数退避）。默认 100（即 100 倍退避）。
     */
    private long nakUnicastRetryDelayRatio = 100L;

    /**
     * 组播 NAK 最大退避时间（纳秒）。默认 60 毫秒。
     */
    private long nakMulticastMaxBackoffNs = 60_000_000L;

    /**
     * 组播 NAK 组大小估计值。
     * <p>
     * 用于计算 NAK 随机退避时间，值越大退避越分散，适合大规模组播场景。默认 10。
     */
    private int nakMulticastGroupSize = 10;

    // ── 超时 ─────────────────────────────────────────────────────────────────

    /**
     * Image（远端发布者）存活超时（纳秒）。
     * <p>
     * 超过此时间未收到发布者消息，Image 将被关闭（触发 unavailable image 回调）。
     * 默认 10 秒。
     */
    private long imageLivenessTimeoutNs = 10_000_000_000L;

    /**
     * 客户端存活超时（纳秒）。
     * <p>
     * Driver 超过此时间未收到客户端（AeronCluster、Aeron 等）的心跳，
     * 则认为客户端已死亡，自动清理其资源。默认 10 秒。
     */
    private long clientLivenessTimeoutNs = 10_000_000_000L;

    /**
     * 状态消息（Status Message）发送间隔（纳秒）。
     * <p>
     * 接收方定期向发送方发送 SM 以反馈流控窗口。默认 200 毫秒。
     */
    private long statusMessageTimeoutNs = 200_000_000L;

    /**
     * 计数器（Counter）释放后可被复用的最短等待时间（纳秒）。
     * <p>
     * 避免 Counter ID 被立即重用，给监控系统留出采集窗口。默认 1 秒。
     */
    private long counterFreeToReuseTimeoutNs = 1_000_000_000L;

    /**
     * Driver 内部定时器轮询间隔（纳秒）。
     * <p>
     * 控制超时检测的精度。较小的值精度更高，但 CPU 占用稍高。默认 1 秒。
     */
    private long timerIntervalNs = 1_000_000_000L;

    // ── Duty Cycle 监控 ───────────────────────────────────────────────────────

    /**
     * Conductor 线程单次 duty-cycle 超过此时间（纳秒）则记录告警。
     * <p>
     * 用于检测 GC 停顿或其他导致 Conductor 线程阻塞的问题。默认 1 秒。
     */
    private long conductorCycleThresholdNs = 1_000_000_000L;

    /**
     * Sender 线程单次 duty-cycle 超过此时间（纳秒）则记录告警。默认 1 秒。
     */
    private long senderCycleThresholdNs = 1_000_000_000L;

    /**
     * Receiver 线程单次 duty-cycle 超过此时间（纳秒）则记录告警。默认 1 秒。
     */
    private long receiverCycleThresholdNs = 1_000_000_000L;

    // ── 发送/接收轮询比率 ──────────────────────────────────────────────────────

    /**
     * Sender 每发送 N 次数据后检查一次状态消息（SM）的比率。
     * <p>
     * 较小的值可更及时地响应流控信号，但增加轮询开销。默认 4。
     */
    private int sendToStatusMessagePollRatio = 4;

    /**
     * 资源（Publication/Subscription）释放时每次最多清理的条目数。
     * <p>
     * 控制资源清理对主循环的影响。默认 10。
     */
    private int resourceFreeLimit = 10;

    // ── 磁盘空间检查 ─────────────────────────────────────────────────────────

    /**
     * 是否在创建 log-buffer 时检查磁盘剩余空间。
     * <p>
     * 启用后磁盘空间不足时会提前告警，避免运行时写入失败。默认 true。
     */
    private boolean performStorageChecks = true;

    /**
     * 磁盘剩余空间低于此阈值（字节）时打印告警日志。默认 40MB。
     */
    private long lowStorageWarningThreshold = 40 * 1_048_576L;

    // ── DNS 解析 ─────────────────────────────────────────────────────────────

    /**
     * 重新解析主机名的检查间隔（纳秒）。
     * <p>
     * Aeron 会定期重新解析 channel URI 中的 hostname，适合 DNS 动态变化的场景。
     * 默认 1 分钟（60_000_000_000）。
     */
    private long reResolutionCheckIntervalNs = 60_000_000_000L;
}
