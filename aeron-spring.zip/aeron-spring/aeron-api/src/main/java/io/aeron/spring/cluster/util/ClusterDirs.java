package io.aeron.spring.cluster.util;

import java.io.File;

/**
 * 集群节点目录命名规范，集中管理所有子目录名称。
 *
 * <p>节点根目录（nodeDir）由 {@link io.aeron.spring.cluster.config.ClusterProperties#aeronDir()} 提供，
 * 本类只负责在 nodeDir 下各子目录名的统一命名，避免字符串散落在各处。
 *
 * <pre>
 * nodeDir/
 * ├── aeron-media-driver/   ← MediaDriver 共享内存、cnc.dat
 * ├── aeron-archive/        ← Archive 录制文件
 * └── aeron-cluster/        ← ConsensusModule / ClusteredService 状态文件
 * </pre>
 */
public final class ClusterDirs
{
    /** MediaDriver 共享内存子目录名 */
    public static final String MEDIA_DRIVER = "aeron-media-driver";

    /** Archive 录制文件子目录名 */
    public static final String ARCHIVE = "aeron-archive";

    /** ConsensusModule / ClusteredService 状态文件子目录名 */
    public static final String CLUSTER = "aeron-cluster";

    private ClusterDirs() {}

    /** 返回 MediaDriver 目录路径字符串（供 aeronDirectoryName 使用） */
    public static String mediaDriverDir(final String nodeDir)
    {
        return nodeDir + "/" + MEDIA_DRIVER;
    }

    /** 返回 Archive 目录 File 对象 */
    public static File archiveDir(final String nodeDir)
    {
        return new File(nodeDir, ARCHIVE);
    }

    /** 返回 Cluster 状态目录 File 对象 */
    public static File clusterDir(final String nodeDir)
    {
        return new File(nodeDir, CLUSTER);
    }
}
