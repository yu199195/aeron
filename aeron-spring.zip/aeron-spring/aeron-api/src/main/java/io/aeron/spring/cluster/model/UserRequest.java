package io.aeron.spring.cluster.model;

import lombok.Data;

/**
 * REST 请求体：User 消息。
 */
@Data
public class UserRequest
{
    private long userId;
    private String username;
    private String email;
    private int age;
    private double balance;
    private boolean active = true;
    
}
