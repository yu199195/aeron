package io.aeron.spring.cluster.model;

import lombok.Data;

/**
 * REST 请求体：Order 消息。
 */
@Data
public class OrderRequest
{
    private long orderId;
    private String symbol;
    private double price;
    private int quantity;
    private char side;
}
