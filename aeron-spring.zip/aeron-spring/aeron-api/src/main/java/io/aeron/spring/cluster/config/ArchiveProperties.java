package io.aeron.spring.cluster.config;

import lombok.Data;

/**
 * Archive 调优配置，绑定 {@code aeron.cluster.archive.*}。
 *
 * <h3>Archive 的职责</h3>
 * Archive 负责将集群 Ingress 消息流持久化到磁盘，
 * 并为新加入或落后的节点提供日志回放（Replay）服务。
 * 同时管理集群快照文件的存储和读取。
 *
 * <h3>线程模型说明</h3>
 * <ul>
 *   <li><b>DEDICATED</b>：Conductor / Recorder / Replayer 各独占一个线程（生产推荐）</li>
 *   <li><b>SHARED</b>：三者共用一个线程（开发/测试场景）</li>
 * </ul>
 */
@Data
public class ArchiveProperties
{
    // ── 线程模型 ─────────────────────────────────────────────────────────────

    /**
     * Archive 线程模型。
     * <ul>
     *   <li>{@code DEDICATED}：Conductor / Recorder / Replayer 各独占一个线程（生产推荐）</li>
     *   <li>{@code SHARED}：三者共用一个线程（开发/测试场景）</li>
     * </ul>
     * 默认 {@code DEDICATED}。
     */
    private String threadingMode = "DEDICATED";

    // ── 日志文件 ─────────────────────────────────────────────────────────────

    /**
     * Segment 文件大小（字节）。
     * <p>
     * Archive 将日志切分为固定大小的 {@code .rec} 文件存储在磁盘上。
     * 较小的值（如 64MB）便于磁盘空间回收；较大的值（如 512MB）I/O 效率更高。
     * 必须是 2 的幂次。默认 128MB。
     */
    private int segmentFileLength = 134_217_728;

    /**
     * 日志文件磁盘同步级别。
     * <ul>
     *   <li>{@code 0} - 异步刷盘（默认，性能最高，极端崩溃时可能丢失少量最新数据）</li>
     *   <li>{@code 1} - fdatasync（每次写后同步数据，元数据可能延迟落盘）</li>
     *   <li>{@code 2} - fsync（每次写后同步数据 + 元数据，最安全，性能最低）</li>
     * </ul>
     */
    private int fileSyncLevel = 0;

    /**
     * Catalog 元数据文件磁盘同步级别（独立于日志文件的 fileSyncLevel）。
     * <p>
     * Catalog 文件记录每个 Recording 的元数据，建议与 {@link #fileSyncLevel} 保持一致。
     * 取值与 {@link #fileSyncLevel} 相同。默认 0（异步）。
     */
    private int catalogFileSyncLevel = 0;

    /**
     * Catalog 容量（最大录制条目数）。
     * <p>
     * Catalog 文件记录每个 Recording（日志段/快照）的元数据，容量耗尽时自动扩展。
     * 默认 1024 条。
     */
    private long catalogCapacity = 1_024L;

    /**
     * 单次文件 I/O 读写的最大数据量（字节）。
     * <p>
     * 控制 Recorder/Replayer 每次写入或读取磁盘的块大小，影响吞吐与延迟的平衡。
     * 默认 1MB（1_048_576）。
     */
    private int fileIoMaxLength = 1_048_576;

    // ── 并发限制 ─────────────────────────────────────────────────────────────

    /**
     * 最大并发录制数（Concurrent Recordings）。
     * <p>
     * 同时进行的日志录制会话上限。超过此限制的录制请求将被拒绝。默认 20。
     */
    private int maxConcurrentRecordings = 20;

    /**
     * 最大并发回放数（Concurrent Replays）。
     * <p>
     * 同时进行的日志回放会话上限。新加入节点追日志时会发起 Replay 请求。默认 20。
     */
    private int maxConcurrentReplays = 20;

    // ── 控制通道 ─────────────────────────────────────────────────────────────

    /**
     * Archive 控制通道响应 Term 缓冲区是否使用稀疏文件。
     * <p>
     * true = 稀疏文件（不预分配磁盘空间，适合开发）；
     * false = 预分配（生产推荐，避免运行时磁盘分配延迟）。默认 true。
     */
    private boolean controlTermBufferSparse = true;

    /**
     * Archive 控制通道 Term 缓冲区大小（字节）。
     * <p>
     * 高并发 Replay 请求时可适当增大。必须是 2 的幂次。默认 64KB。
     */
    private int controlTermBufferLength = 65_536;

    /**
     * Archive 控制通道 MTU 大小（字节）。
     * <p>
     * 控制消息的最大单次传输大小。默认 1408 字节。
     */
    private int controlMtuLength = 1_408;

    // ── 超时 ─────────────────────────────────────────────────────────────────

    /**
     * Archive 客户端连接超时（纳秒）。
     * <p>
     * 建立 Archive 控制会话的最长等待时间。节点启动时会连接本地 Archive，
     * 若超时则启动失败。默认 10 秒。
     */
    private long connectTimeoutNs = 10_000_000_000L;

    /**
     * Replay 会话在完成后的持续时间（纳秒）。
     * <p>
     * Replay 流结束后，会话不立即关闭，而是等待此时间后再关闭，
     * 允许消费者读取最后的数据。默认 1 秒。
     */
    private long replayLingerTimeoutNs = 1_000_000_000L;

    // ── Duty Cycle 监控 ───────────────────────────────────────────────────────

    /**
     * Archive Conductor 线程单次 duty-cycle 超过此时间（纳秒）则记录告警。
     * <p>
     * 用于检测 GC 停顿或 I/O 阻塞。默认 1 秒。
     */
    private long conductorCycleThresholdNs = 1_000_000_000L;

    /**
     * Recorder 线程单次 duty-cycle 超过此时间（纳秒）则记录告警。默认 1 秒。
     */
    private long recorderCycleThresholdNs = 1_000_000_000L;

    /**
     * Replayer 线程单次 duty-cycle 超过此时间（纳秒）则记录告警。默认 1 秒。
     */
    private long replayerCycleThresholdNs = 1_000_000_000L;

    // ── 错误缓冲区 ────────────────────────────────────────────────────────────

    /**
     * 错误日志缓冲区大小（字节）。
     * <p>
     * Archive 内部记录错误事件的环形缓冲区（{@link org.agrona.concurrent.ringbuffer.ManyToOneRingBuffer}）。
     * agrona 2.x 中 TRAILER_LENGTH = 768，要求容量为 {@code 2^n + 768}，如 1_049_344、2_097_920。
     */
    private int errorBufferLength = 1_049_344; // 2^20 + 768

    // ── 磁盘空间 ─────────────────────────────────────────────────────────────

    /**
     * 磁盘剩余空间低于此阈值（字节）时打印告警日志。
     * <p>
     * 提前预警磁盘不足，避免录制因磁盘写满而中断。默认 0（不检查）。
     */
    private long lowStorageSpaceThreshold = 0L;
}
