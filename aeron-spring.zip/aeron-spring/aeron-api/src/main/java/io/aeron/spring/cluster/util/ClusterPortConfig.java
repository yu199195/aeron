package io.aeron.spring.cluster.util;

import java.util.List;

/**
 * 集群端口分配规则常量与工具方法，供所有模块共享。
 *
 * <h3>端口分配规则</h3>
 * 每个节点占用 {@link #PORTS_PER_NODE} 个连续端口，起始于 {@code portBase + nodeId * PORTS_PER_NODE}：
 * <pre>
 *   offset  用途
 *   ──────  ──────────────────────────────────────────────────────────
 *     +1    Archive 控制通道（内部 IPC + 节点间 replay 控制请求）
 *     +2    客户端 Ingress（Sender 连接入口）
 *     +3    成员共识（Raft 投票/心跳）
 *     +4    日志复制（Leader → Follower 正常日志流）
 *     +5    文件传输（快照 snapshot 传输）
 *     +6    日志追赶数据流（replicationChannel，Archive replay 数据回传）
 *     +7    Archive 控制应答（controlResponseChannel，replay 控制响应回传）
 *
 *   portBase=20000, node-0: 20001..20007
 *   portBase=20000, node-1: 20101..20107
 *   portBase=20000, node-2: 20201..20207
 * </pre>
 */
public final class ClusterPortConfig
{
    /** 每个节点预留的端口数量 */
    public static final int PORTS_PER_NODE = 100;

    /** Archive 控制通道端口偏移 */
    public static final int ARCHIVE_CONTROL_PORT_OFFSET = 1;

    /** 客户端 Ingress 端口偏移（sender/receiver 连接此端口） */
    public static final int CLIENT_FACING_PORT_OFFSET = 2;

    /** 成员共识流量端口偏移（Raft 投票/心跳） */
    public static final int MEMBER_FACING_PORT_OFFSET = 3;

    /** 日志复制端口偏移 */
    public static final int LOG_PORT_OFFSET = 4;

    /** 文件传输（快照）端口偏移 */
    public static final int TRANSFER_PORT_OFFSET = 5;

    /**
     * 日志追赶数据流端口偏移。
     * <p>
     * 用于 {@code Archive.Context.replicationChannel} 和
     * {@code ConsensusModule.Context.replicationChannel}。
     * 当 Follower 落后需要从 Archive 回放历史日志时，Archive Replayer
     * 将数据流推送到此固定端口（取代随机端口 {@code :0}）。
     */
    public static final int REPLICATION_PORT_OFFSET = 6;

    /**
     * Archive 控制应答端口偏移。
     * <p>
     * 用于发起 replication 的 {@code AeronArchive.Context.controlResponseChannel}。
     * 远端 Archive Conductor 将 replay 控制响应（OK/Error）回传到此固定端口
     * （取代随机端口 {@code :0}）。
     */
    public static final int ARCHIVE_RESPONSE_PORT_OFFSET = 7;

    private ClusterPortConfig() {}

    /**
     * 计算指定节点的某类端口号。
     *
     * @param nodeId   节点 ID（0-based）
     * @param portBase 端口基础值
     * @param offset   端口偏移（使用本类常量，如 {@link #CLIENT_FACING_PORT_OFFSET}）
     * @return 对应端口号
     */
    public static int calculatePort(final int nodeId, final int portBase, final int offset)
    {
        return portBase + (nodeId * PORTS_PER_NODE) + offset;
    }

    /**
     * 根据主机列表和端口基础值生成 ingress endpoints 字符串。
     * <p>
     * 格式：{@code 0=host0:port0,1=host1:port1,...}
     * <p>
     * 端口 = {@code portBase + nodeId * PORTS_PER_NODE + CLIENT_FACING_PORT_OFFSET}
     *
     * @param hostnames 主机名列表，下标即 nodeId
     * @param portBase  端口基础值
     * @return ingress endpoints 字符串，可直接传给 {@code AeronCluster.Context.ingressEndpoints()}
     */
    public static String ingressEndpoints(final List<String> hostnames, final int portBase)
    {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < hostnames.size(); i++)
        {
            if (i > 0)
            {
                sb.append(',');
            }
            sb.append(i).append('=')
              .append(hostnames.get(i).trim()).append(':')
              .append(calculatePort(i, portBase, CLIENT_FACING_PORT_OFFSET));
        }
        return sb.toString();
    }
}
