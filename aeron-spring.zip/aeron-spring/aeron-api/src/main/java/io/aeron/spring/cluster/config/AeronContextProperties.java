package io.aeron.spring.cluster.config;

import lombok.Data;

/**
 * Aeron 客户端连接配置，对应 {@link io.aeron.Aeron.Context} 的所有标量字段。
 *
 * <h3>Aeron.Context 的职责</h3>
 * {@code Aeron.Context} 是客户端与 MediaDriver 之间的连接配置：
 * <ul>
 *   <li>指定 MediaDriver 的目录（{@code aeronDirectoryName}），用于定位共享内存文件</li>
 *   <li>配置客户端心跳、空闲策略、资源回收、超时等行为</li>
 * </ul>
 *
 * <p>在大多数嵌入式场景中，{@code aeronDirectoryName} 由程序自动从 {@link io.aeron.driver.MediaDriver}
 * 实例获取，无需手动配置。
 */
@Data
public class AeronContextProperties
{
    // ── 目录 ─────────────────────────────────────────────────────────────────

    /**
     * Aeron 目录名（绝对路径）。
     * <p>
     * 指向 MediaDriver 的共享内存目录（{@code CncFile} 所在位置）。
     * 留空时由程序根据 MediaDriver 实例自动填充，通常不需要手动配置。
     */
    private String aeronDirectoryName = "";

    // ── 客户端标识 ────────────────────────────────────────────────────────────

    /**
     * 客户端名称，用于日志和计数器标识。
     * <p>
     * 为空时由 Aeron 自动生成。
     */
    private String clientName = "";

    // ── 超时 ─────────────────────────────────────────────────────────────────

    /**
     * 客户端等待 MediaDriver 响应的超时时间（毫秒）。
     * <p>
     * 客户端发出命令后（如添加 Publication/Subscription），等待 Driver 确认的最长时间。
     * 超时未收到响应则抛出异常。默认 10 秒（10_000 ms）。
     */
    private long driverTimeoutMs = 10_000L;

    // ── 心跳 ─────────────────────────────────────────────────────────────────

    /**
     * 客户端向 MediaDriver 发送心跳的间隔（纳秒）。
     * <p>
     * 此间隔应明显小于 MediaDriver 的 {@code clientLivenessTimeoutNs}，
     * 否则 Driver 会认为客户端已死亡并回收资源。默认 10 秒（10_000_000_000 ns）。
     */
    private long keepAliveIntervalNs = 10_000_000_000L;

    // ── 空闲策略 ──────────────────────────────────────────────────────────────

    /**
     * Conductor 线程空闲时的休眠时长（纳秒）。
     * <p>
     * 值越小响应越快但 CPU 占用越高；值越大越节省 CPU 但延迟更高。
     * 默认 16 毫秒（16_000_000 ns）。
     */
    private long idleSleepDurationNs = 16_000_000L;

    // ── 资源回收 ──────────────────────────────────────────────────────────────

    /**
     * Publication/Subscription 关闭后在本地保留的最短时间（纳秒）。
     * <p>
     * 防止过早释放共享内存，避免对端还在访问时内存已被回收。
     * 默认 5 秒（5_000_000_000 ns）。
     */
    private long resourceLingerDurationNs = 5_000_000_000L;

    /**
     * Aeron 客户端关闭时等待资源回收的最长时间（纳秒）。
     * <p>
     * 关闭 {@code Aeron} 实例时，内部会等待所有 Publication/Subscription
     * 完成回收，此参数控制最长等待时间。默认 1 秒（1_000_000_000 ns）。
     */
    private long closeLingerDurationNs = 1_000_000_000L;

    // ── 高级选项 ──────────────────────────────────────────────────────────────

    /**
     * 是否使用 Conductor AgentInvoker（手动 duty-cycle）模式。
     * <p>
     * 默认 {@code false}（使用独立线程）。仅在需要将 Conductor 集成到
     * 自定义线程模型时设为 {@code true}。
     */
    private boolean useConductorAgentInvoker = false;

    /**
     * 是否在映射内存时执行预触页（pre-touch），提前分配物理页，避免首次访问缺页中断。
     * <p>
     * 开启可降低延迟抖动，但启动时消耗更多时间。默认 {@code false}。
     */
    private boolean preTouchMappedMemory = false;
}
