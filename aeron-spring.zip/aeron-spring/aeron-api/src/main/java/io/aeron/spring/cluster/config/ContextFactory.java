package io.aeron.spring.cluster.config;

import io.aeron.Aeron;
import io.aeron.archive.Archive;
import io.aeron.archive.ArchiveThreadingMode;
import io.aeron.driver.MediaDriver;
import io.aeron.driver.ThreadingMode;

/**
 * Aeron Context 工厂类。
 *
 * <p>统一封装 {@link MediaDriver.Context}、{@link Archive.Context}、
 * {@link ConsensusModule.Context}、{@link Aeron.Context} 的配置逻辑。
 *
 * <p>每类 Context 提供两种使用方式：
 * <ul>
 *   <li><b>新建</b>：{@code mediaDriverContext(cfg)} — 创建并返回新 Context</li>
 *   <li><b>应用</b>：{@code applyMediaDriver(ctx, cfg)} — 将属性应用到已有 Context 上</li>
 * </ul>
 * 应用方式适用于需要保留已有 Context 上特定字段（如集群端口、IPC 通道等）的场景。
 */
public final class ContextFactory
{
    private ContextFactory() {}

    // ──────────────────────────────────────────────────────────────────
    // MediaDriver.Context
    // ──────────────────────────────────────────────────────────────────

    /**
     * 根据 {@link MediaDriverProperties} 构建新的 {@link MediaDriver.Context}。
     */
    public static MediaDriver.Context mediaDriverContext(final MediaDriverProperties cfg)
    {
        return applyMediaDriver(new MediaDriver.Context(), cfg);
    }

    /**
     * 将 {@link MediaDriverProperties} 的调优参数应用到已有的 {@link MediaDriver.Context}。
     * <p>
     * 不覆盖：{@code aeronDirectoryName}、{@code errorHandler}、{@code terminationHook}。
     *
     * @param ctx 已有 Context，通常来自 ClusterConfig
     * @param cfg 调优属性
     * @return 同一个 {@code ctx} 实例（方便链式调用）
     */
    public static MediaDriver.Context applyMediaDriver(
        final MediaDriver.Context ctx,
        final MediaDriverProperties cfg)
    {
        return ctx
            // ── 线程模型 ──────────────────────────────────────────────────────
            .threadingMode(ThreadingMode.valueOf(cfg.getThreadingMode()))
            .printConfigurationOnStart(cfg.isPrintConfigurationOnStart())

            // ── 目录管理 ──────────────────────────────────────────────────────
            .dirDeleteOnStart(true)
            .dirDeleteOnShutdown(cfg.isDirDeleteOnShutdown())

            // ── 缓冲区大小 ────────────────────────────────────────────────────
            .conductorBufferLength(cfg.getConductorBufferLength())
            .toClientsBufferLength(cfg.getToClientsBufferLength())
            .errorBufferLength(cfg.getErrorBufferLength())
            .lossReportBufferLength(cfg.getLossReportBufferLength())
            .counterValuesBufferLength(cfg.getCounterValuesBufferLength())

            // ── Socket 缓冲区 ──────────────────────────────────────────────────
            .socketSndbufLength(cfg.getSocketSndbufLength())
            .socketRcvbufLength(cfg.getSocketRcvbufLength())
            .socketMulticastTtl(cfg.getSocketMulticastTtl())

            // ── 流量控制 ───────────────────────────────────────────────────────
            .initialWindowLength(cfg.getInitialWindowLength())
            .flowControlReceiverTimeoutNs(cfg.getFlowControlReceiverTimeoutNs())
            .flowControlGroupTag(cfg.getFlowControlGroupTag())
            .flowControlGroupMinSize(cfg.getFlowControlGroupMinSize())

            // ── Term 缓冲区 ────────────────────────────────────────────────────
            .publicationTermBufferLength(cfg.getPublicationTermBufferLength())
            .ipcTermBufferLength(cfg.getIpcTermBufferLength())
            .publicationTermWindowLength(cfg.getPublicationTermWindowLength())
            .ipcPublicationTermWindowLength(cfg.getIpcPublicationTermWindowLength())
            .termBufferSparseFile(cfg.isTermBufferSparseFile())
            .filePageSize(cfg.getFilePageSize())

            // ── MTU ────────────────────────────────────────────────────────────
            .mtuLength(cfg.getMtuLength())
            .ipcMtuLength(cfg.getIpcMtuLength())

            // ── 发布行为 ────────────────────────────────────────────────────────
            .spiesSimulateConnection(cfg.isSpiesSimulateConnection())
            .reliableStream(cfg.isReliableStream())
            .publicationLingerTimeoutNs(cfg.getPublicationLingerTimeoutNs())
            .publicationUnblockTimeoutNs(cfg.getPublicationUnblockTimeoutNs())
            .publicationConnectionTimeoutNs(cfg.getPublicationConnectionTimeoutNs())
            .publicationReservedSessionIdLow(cfg.getPublicationReservedSessionIdLow())
            .publicationReservedSessionIdHigh(cfg.getPublicationReservedSessionIdHigh())

            // ── 订阅行为 ────────────────────────────────────────────────────────
            .tetherSubscriptions(cfg.isTetherSubscriptions())
            .rejoinStream(cfg.isRejoinStream())
            .untetheredWindowLimitTimeoutNs(cfg.getUntetheredWindowLimitTimeoutNs())
            .untetheredRestingTimeoutNs(cfg.getUntetheredRestingTimeoutNs())

            // ── 重传与 NAK ─────────────────────────────────────────────────────
            .retransmitUnicastDelayNs(cfg.getRetransmitUnicastDelayNs())
            .retransmitUnicastLingerNs(cfg.getRetransmitUnicastLingerNs())
            .nakUnicastDelayNs(cfg.getNakUnicastDelayNs())
            .nakUnicastRetryDelayRatio(cfg.getNakUnicastRetryDelayRatio())
            .nakMulticastMaxBackoffNs(cfg.getNakMulticastMaxBackoffNs())
            .nakMulticastGroupSize(cfg.getNakMulticastGroupSize())

            // ── 超时 ───────────────────────────────────────────────────────────
            .imageLivenessTimeoutNs(cfg.getImageLivenessTimeoutNs())
            .clientLivenessTimeoutNs(cfg.getClientLivenessTimeoutNs())
            .statusMessageTimeoutNs(cfg.getStatusMessageTimeoutNs())
            .counterFreeToReuseTimeoutNs(cfg.getCounterFreeToReuseTimeoutNs())
            .timerIntervalNs(cfg.getTimerIntervalNs())

            // ── Duty Cycle 监控 ────────────────────────────────────────────────
            .conductorCycleThresholdNs(cfg.getConductorCycleThresholdNs())
            .senderCycleThresholdNs(cfg.getSenderCycleThresholdNs())
            .receiverCycleThresholdNs(cfg.getReceiverCycleThresholdNs())

            // ── 轮询比率与资源 ─────────────────────────────────────────────────
            .sendToStatusMessagePollRatio(cfg.getSendToStatusMessagePollRatio())
            .resourceFreeLimit(cfg.getResourceFreeLimit())

            // ── 磁盘空间检查 ───────────────────────────────────────────────────
            .performStorageChecks(cfg.isPerformStorageChecks())
            .lowStorageWarningThreshold(cfg.getLowStorageWarningThreshold())

            // ── DNS 解析 ───────────────────────────────────────────────────────
            .reResolutionCheckIntervalNs(cfg.getReResolutionCheckIntervalNs());
    }

    // ──────────────────────────────────────────────────────────────────
    // Archive.Context
    // ──────────────────────────────────────────────────────────────────

    /**
     * 根据 {@link ArchiveProperties} 构建新的 {@link Archive.Context}。
     */
    public static Archive.Context archiveContext(final ArchiveProperties cfg)
    {
        return applyArchive(new Archive.Context(), cfg);
    }

    /**
     * 将 {@link ArchiveProperties} 的调优参数应用到已有的 {@link Archive.Context}。
     * <p>
     * 不覆盖：{@code archiveDir}、{@code controlChannel}、{@code replicationChannel}、
     * {@code deleteArchiveOnStart}、{@code errorHandler}。
     *
     * @param ctx 已有 Context，通常来自 ClusterConfig
     * @param cfg 调优属性
     * @return 同一个 {@code ctx} 实例
     */
    public static Archive.Context applyArchive(
        final Archive.Context ctx,
        final ArchiveProperties cfg)
    {
        return ctx
            // ── 线程模型 ──────────────────────────────────────────────────────
            .threadingMode(ArchiveThreadingMode.valueOf(cfg.getThreadingMode()))

            // ── 日志文件 ──────────────────────────────────────────────────────
            .segmentFileLength(cfg.getSegmentFileLength())
            .fileSyncLevel(cfg.getFileSyncLevel())
            .catalogFileSyncLevel(cfg.getCatalogFileSyncLevel())
            .catalogCapacity(cfg.getCatalogCapacity())
            .fileIoMaxLength(cfg.getFileIoMaxLength())

            // ── 并发限制 ──────────────────────────────────────────────────────
            .maxConcurrentRecordings(cfg.getMaxConcurrentRecordings())
            .maxConcurrentReplays(cfg.getMaxConcurrentReplays())

            // ── 控制通道 ──────────────────────────────────────────────────────
            .controlTermBufferSparse(cfg.isControlTermBufferSparse())
            .controlTermBufferLength(cfg.getControlTermBufferLength())
            .controlMtuLength(cfg.getControlMtuLength())

            // ── 超时 ───────────────────────────────────────────────────────────
            .connectTimeoutNs(cfg.getConnectTimeoutNs())
            .replayLingerTimeoutNs(cfg.getReplayLingerTimeoutNs())

            // ── Duty Cycle 监控 ────────────────────────────────────────────────
            .conductorCycleThresholdNs(cfg.getConductorCycleThresholdNs())
            .recorderCycleThresholdNs(cfg.getRecorderCycleThresholdNs())
            .replayerCycleThresholdNs(cfg.getReplayerCycleThresholdNs())

            // ── 错误缓冲区 ─────────────────────────────────────────────────────
            .errorBufferLength(cfg.getErrorBufferLength())

            // ── 磁盘空间 ───────────────────────────────────────────────────────
            .lowStorageSpaceThreshold(cfg.getLowStorageSpaceThreshold());
    }

    // ──────────────────────────────────────────────────────────────────
    // Aeron.Context
    // ──────────────────────────────────────────────────────────────────

    /**
     * 根据 {@link AeronContextProperties} 和已启动的 MediaDriver 目录构建 {@link Aeron.Context}。
     */
    public static Aeron.Context aeronContext(
        final AeronContextProperties cfg,
        final String mediaDriverDir)
    {
        final String dir = (cfg.getAeronDirectoryName() != null && !cfg.getAeronDirectoryName().isBlank())
            ? cfg.getAeronDirectoryName()
            : mediaDriverDir;

        final Aeron.Context ctx = new Aeron.Context()
            .aeronDirectoryName(dir)
            .driverTimeoutMs(cfg.getDriverTimeoutMs())
            .keepAliveIntervalNs(cfg.getKeepAliveIntervalNs())
            .idleSleepDurationNs(cfg.getIdleSleepDurationNs())
            .resourceLingerDurationNs(cfg.getResourceLingerDurationNs())
            .closeLingerDurationNs(cfg.getCloseLingerDurationNs())
            .useConductorAgentInvoker(cfg.isUseConductorAgentInvoker())
            .preTouchMappedMemory(cfg.isPreTouchMappedMemory());

        if (cfg.getClientName() != null && !cfg.getClientName().isBlank())
        {
            ctx.clientName(cfg.getClientName());
        }

        return ctx;
    }

    /**
     * 使用默认配置构建 {@link Aeron.Context}，仅指定 MediaDriver 目录。
     */
    public static Aeron.Context aeronContext(final String mediaDriverDir)
    {
        return new Aeron.Context().aeronDirectoryName(mediaDriverDir);
    }
}
