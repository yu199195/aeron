package io.aeron.spring.cluster.receiver.controller;

import io.aeron.spring.cluster.receiver.stroe.MessageStore.ReceivedMessage;
import io.aeron.spring.cluster.receiver.service.ReceiverFacade;
import io.aeron.spring.cluster.receiver.service.ReceiverFacade.ReceiverStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Receiver REST 接口。
 *
 * <pre>
 * GET /cluster/receiver/status   — 当前模式、运行状态、消息计数、连接情况
 * GET /cluster/receiver/messages — 最近收到的消息列表
 * </pre>
 */
@RestController
@RequestMapping("/cluster/receiver")
public class ClusterReceiverController
{
    private final ReceiverFacade facade;

    public ClusterReceiverController(final ReceiverFacade facade)
    {
        this.facade = facade;
    }

    @GetMapping("/status")
    public ResponseEntity<ReceiverStatus> status()
    {
        return ResponseEntity.ok(facade.status());
    }

    @GetMapping("/messages")
    public ResponseEntity<List<ReceivedMessage>> messages()
    {
        return ResponseEntity.ok(facade.recentMessages());
    }
}
