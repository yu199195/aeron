package io.aeron.spring.cluster.receiver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
@EnableConfigurationProperties
public class ClusterReceiverApplication
{
    public static void main(final String[] args)
    {
        SpringApplication.run(ClusterReceiverApplication.class, args);
    }
}
