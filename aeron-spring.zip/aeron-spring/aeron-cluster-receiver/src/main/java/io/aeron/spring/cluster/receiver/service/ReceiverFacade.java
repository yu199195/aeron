package io.aeron.spring.cluster.receiver.service;

import io.aeron.spring.cluster.receiver.stroe.MessageStore;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Spring 门面 Service，统一管理 {@link ReceiverService} 的生命周期，
 * 并为 REST 控制器提供聚合视图。
 */
@Service
public class ReceiverFacade
{
    private final ReceiverService receiver;
    private final MessageStore store;

    public ReceiverFacade(final ReceiverService receiver, final MessageStore store)
    {
        this.receiver = receiver;
        this.store    = store;
    }

    @PostConstruct
    public void start()
    {
        receiver.start();
    }

    @PreDestroy
    public void stop()
    {
        receiver.stop();
    }

    public ReceiverStatus status()
    {
        final ReceiverService.ConnectionStatus conn = receiver.connectionStatus();
        return new ReceiverStatus(
            receiver.mode(),
            receiver.isRunning(),
            store.orderCount(),
            store.userCount(),
            conn.orderConnected(),
            conn.userConnected());
    }

    public List<MessageStore.ReceivedMessage> recentMessages()
    {
        return store.snapshot();
    }

    // ──────────────────────────────────────────────
    // 数据类型
    // ──────────────────────────────────────────────

    public record ReceiverStatus(
        String  mode,
        boolean running,
        long    orderCount,
        long    userCount,
        boolean orderConnected,
        boolean userConnected) {}
}
