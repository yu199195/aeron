package io.aeron.spring.cluster.receiver.stroe;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 线程安全的消息环形缓冲，供两种接收模式共享。
 * <p>
 * 写入：单 poll/duty-cycle 线程；读取：REST 线程（通过 {@link #snapshot()} 复制快照）。
 */
public class MessageStore
{
    private final int              maxSize;
    private final Deque<ReceivedMessage> ring = new ArrayDeque<>();
    private final AtomicLong       orderCount = new AtomicLong(0);
    private final AtomicLong       userCount  = new AtomicLong(0);

    public MessageStore(final int maxSize)
    {
        this.maxSize = maxSize;
    }

    /** 追加一条 Order 记录，返回更新后的计数（可在 poll 线程直接调用）。 */
    public long appendOrder(final String summary)
    {
        final long n = orderCount.incrementAndGet();
        append(new ReceivedMessage("ORDER", summary, System.currentTimeMillis()));
        return n;
    }

    /** 追加一条 User 记录，返回更新后的计数。 */
    public long appendUser(final String summary)
    {
        final long n = userCount.incrementAndGet();
        append(new ReceivedMessage("USER", summary, System.currentTimeMillis()));
        return n;
    }

    public long orderCount() { return orderCount.get(); }
    public long userCount()  { return userCount.get(); }

    /** 返回当前所有消息的快照（线程安全：synchronized 复制）。 */
    public List<ReceivedMessage> snapshot()
    {
        synchronized (ring)
        {
            return new ArrayList<>(ring);
        }
    }

    private void append(final ReceivedMessage msg)
    {
        synchronized (ring)
        {
            ring.addLast(msg);
            if (ring.size() > maxSize)
            {
                ring.removeFirst();
            }
        }
    }

    // ──────────────────────────────────────────────
    // 数据类型
    // ──────────────────────────────────────────────

    public record ReceivedMessage(
        String type,
        String summary,
        long   receivedAt) {}
}
