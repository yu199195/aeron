package io.aeron.spring.cluster.receiver.config;

import io.aeron.spring.cluster.receiver.service.ClusterEgressReceiverService;
import io.aeron.spring.cluster.receiver.service.DirectReceiverService;
import io.aeron.spring.cluster.receiver.stroe.MessageStore;
import io.aeron.spring.cluster.receiver.service.ReceiverService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 根据 {@code aeron.receiver.mode} 选择并创建对应的接收器实现。
 */
@Configuration
public class ReceiverBeanConfig
{
    @Bean
    public MessageStore messageStore(final ReceiverProperties props)
    {
        return new MessageStore(props.getMaxRecentMessages());
    }

    @Bean
    public ReceiverService receiverService(
        final ReceiverProperties props,
        final MessageStore store)
    {
        final String mode = props.getMode();
        System.out.println("[ReceiverConfig] mode=" + mode);

        return switch (mode.toLowerCase())
        {
            case "cluster" -> new ClusterEgressReceiverService(props, store);
            case "direct"  -> new DirectReceiverService(props, store);
            default        -> throw new IllegalArgumentException(
                "Unknown aeron.receiver.mode: " + mode + " (supported: direct, cluster)");
        };
    }
}
