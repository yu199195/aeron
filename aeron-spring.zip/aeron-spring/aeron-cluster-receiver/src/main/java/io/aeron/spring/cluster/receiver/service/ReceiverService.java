package io.aeron.spring.cluster.receiver.service;

/**
 * 接收器服务接口，direct 和 cluster 两种模式的共同契约。
 */
public interface ReceiverService
{
    void start();

    void stop();

    boolean isRunning();

    /** 返回当前工作模式名称：{@code "direct"} 或 {@code "cluster"}。 */
    String mode();

    /** 返回底层 Aeron 连接状态。 */
    ConnectionStatus connectionStatus();

    record ConnectionStatus(
        boolean orderConnected,
        boolean userConnected) {}
}
