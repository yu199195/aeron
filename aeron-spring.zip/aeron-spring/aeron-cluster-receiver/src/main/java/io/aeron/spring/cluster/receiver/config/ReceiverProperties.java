package io.aeron.spring.cluster.receiver.config;

import io.aeron.spring.cluster.config.AeronContextProperties;
import io.aeron.spring.cluster.config.MediaDriverProperties;
import io.aeron.spring.cluster.util.ClusterPortConfig;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.stereotype.Component;

import java.util.Arrays;

/**
 * Receiver 配置属性，绑定 application.yml 中的 aeron.receiver.* 前缀。
 *
 * <h3>两种工作模式</h3>
 * <ul>
 *   <li><b>direct</b>：直接订阅 Aeron UDP 频道，接收 ForwardingClusteredService 转发的原始 SBE 消息。
 *       cluster-node 需以 {@code service.type: forwarding} 运行。</li>
 *   <li><b>cluster</b>：作为 AeronCluster 客户端连接集群，发送 SUBSCRIBE 命令，
 *       通过 egress 接收 PubSubClusteredService 广播的 SBE 消息。
 *       cluster-node 需以 {@code service.type: pubsub} 运行。</li>
 * </ul>
 */
@Data
@Component
@ConfigurationProperties(prefix = "aeron.receiver")
public class ReceiverProperties
{
    /** 工作模式：direct | cluster */
    private String mode = "direct";

    // ── direct 模式配置 ───────────────────────────

    /** 订阅频道，需与 ForwardingClusteredService.FORWARD_CHANNEL 一致 */
    private String channel = "aeron:udp?endpoint=localhost:9010";

    /** Order 消息的 streamId */
    private int orderStreamId = 100;

    /** User 消息的 streamId */
    private int userStreamId = 200;

    // ── cluster 模式配置 ──────────────────────────

    /** 集群主机列表（逗号分隔，顺序对应 nodeId），用于自动生成 ingress endpoints */
    private String hostnames = "localhost,localhost,localhost";

    /** 端口基础值 */
    private int portBase = 9000;

    /** 手动指定 ingress endpoints，非空时忽略 hostnames/portBase */
    private String ingressEndpoints = "";

    /** 订阅的消息类型，逗号分隔，可选值：ORDER, USER */
    private String subscribeTypes = "ORDER,USER";

    // ── 公共配置 ──────────────────────────────────

    /** 保留最近收到消息的条数上限 */
    private int maxRecentMessages = 100;

    /** MediaDriver 调优配置 */
    @NestedConfigurationProperty
    private MediaDriverProperties mediaDriver = new MediaDriverProperties();

    /** Aeron 客户端配置 */
    @NestedConfigurationProperty
    private AeronContextProperties aeron = new AeronContextProperties();

    /**
     * 自动生成 ingress endpoints 字符串（格式：0=host:port,1=host:port,...）。
     * 手动指定 {@code ingress-endpoints} 时直接返回，否则由 {@link ClusterPortConfig} 计算。
     *
     * @see ClusterPortConfig#ingressEndpoints(java.util.List, int)
     */
    public String resolvedIngressEndpoints()
    {
        if (ingressEndpoints != null && !ingressEndpoints.isBlank())
        {
            return ingressEndpoints;
        }
        return ClusterPortConfig.ingressEndpoints(
            Arrays.asList(hostnames.split(",")), portBase);
    }
}
