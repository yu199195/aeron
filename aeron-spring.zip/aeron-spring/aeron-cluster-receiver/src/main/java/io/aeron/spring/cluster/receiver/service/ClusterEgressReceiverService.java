package io.aeron.spring.cluster.receiver.service;

import io.aeron.cluster.client.AeronCluster;
import io.aeron.driver.MediaDriver;
import io.aeron.spring.cluster.config.ContextFactory;
import io.aeron.spring.cluster.receiver.config.ReceiverProperties;
import io.aeron.spring.cluster.receiver.listener.ReceiverEgressListener;
import io.aeron.spring.cluster.receiver.stroe.MessageStore;
import org.agrona.CloseHelper;
import org.agrona.ExpandableArrayBuffer;
import org.agrona.concurrent.BackoffIdleStrategy;

import java.nio.charset.StandardCharsets;

/**
 * cluster 模式接收器。
 * <p>
 * 作为 {@link AeronCluster} 客户端连接集群，连接后自动发送 SUBSCRIBE 命令，
 * 通过 egress 接收 PubSubClusteredService 广播的 SBE 消息。
 * <p>
 * cluster-node 需以 {@code aeron.cluster.service.type: pubsub} 运行。
 *
 * <h3>线程模型</h3>
 * 与 cluster-sender 保持一致，单一 duty-cycle 线程独占访问 {@link AeronCluster}：
 * <ol>
 *   <li>连接后立即发送订阅命令</li>
 *   <li>循环调用 {@link AeronCluster#pollEgress()} 接收广播消息</li>
 *   <li>定期发送 keep-alive 防止 session 超时</li>
 * </ol>
 */
public class ClusterEgressReceiverService implements ReceiverService
{
    private static final long KEEP_ALIVE_INTERVAL_MS = 1_000;

    private final ReceiverProperties      props;
    private final ReceiverEgressListener egressListener;

    private MediaDriver      mediaDriver;
    private volatile AeronCluster aeronCluster;

    private Thread          dutyCycleThread;
    private volatile boolean running = false;
    private volatile boolean subscribed = false;

    public ClusterEgressReceiverService(
        final ReceiverProperties props,
        final MessageStore store)
    {
        this.props          = props;
        this.egressListener = new ReceiverEgressListener(store);
    }

    @Override
    public void start()
    {
        final String ingressEndpoints = props.resolvedIngressEndpoints();
        System.out.println("[Receiver/cluster] Starting, ingressEndpoints=" + ingressEndpoints);

        mediaDriver = MediaDriver.launch(ContextFactory.mediaDriverContext(props.getMediaDriver()));

        aeronCluster = AeronCluster.connect(new AeronCluster.Context()
            .aeronDirectoryName(mediaDriver.aeronDirectoryName())
            .ingressChannel("aeron:udp")
            .ingressEndpoints(ingressEndpoints)
            .egressChannel("aeron:udp?endpoint=localhost:0")
            .egressListener(egressListener)
            .errorHandler(t -> System.err.println("[Receiver/cluster] Error: " + t.getMessage())));

        System.out.println("[Receiver/cluster] Connected, sessionId=" + aeronCluster.clusterSessionId()
            + ", leader=" + aeronCluster.leaderMemberId());

        running = true;
        dutyCycleThread = new Thread(this::dutyCycle, "aeron-receiver-duty-cycle");
        dutyCycleThread.setDaemon(true);
        dutyCycleThread.start();

        System.out.println("[Receiver/cluster] Duty-cycle thread started");
    }

    @Override
    public void stop()
    {
        System.out.println("[Receiver/cluster] Stopping...");
        running = false;
        if (dutyCycleThread != null)
        {
            dutyCycleThread.interrupt();
        }
        CloseHelper.closeAll(aeronCluster, mediaDriver);
    }

    @Override
    public boolean isRunning() { return running; }

    @Override
    public String mode() { return "cluster"; }

    @Override
    public ReceiverService.ConnectionStatus connectionStatus()
    {
        final AeronCluster cluster = aeronCluster;
        final boolean connected = cluster != null && !cluster.isClosed();
        // cluster 模式下两个类型共享同一个 session
        return new ReceiverService.ConnectionStatus(connected, connected);
    }

    // ──────────────────────────────────────────────
    // Duty-cycle 线程
    // ──────────────────────────────────────────────

    private void dutyCycle()
    {
        final BackoffIdleStrategy idle = new BackoffIdleStrategy();
        long keepAliveDeadlineMs = System.currentTimeMillis() + KEEP_ALIVE_INTERVAL_MS;

        // 连接后先发送订阅命令
        sendSubscribeCommands();

        while (running && !Thread.currentThread().isInterrupted())
        {
            int workCount = 0;

            if (aeronCluster != null && !aeronCluster.isClosed())
            {
                workCount += aeronCluster.pollEgress();
            }

            final long nowMs = System.currentTimeMillis();
            if (nowMs >= keepAliveDeadlineMs)
            {
                if (aeronCluster != null && !aeronCluster.isClosed())
                {
                    aeronCluster.sendKeepAlive();
                }
                keepAliveDeadlineMs = nowMs + KEEP_ALIVE_INTERVAL_MS;
            }

            idle.idle(workCount);
        }
    }

    // ──────────────────────────────────────────────
    // 订阅命令
    // ──────────────────────────────────────────────

    private void sendSubscribeCommands()
    {
        final String[] types = props.getSubscribeTypes().split(",");
        for (final String type : types)
        {
            final String trimmed = type.trim().toUpperCase();
            if (!trimmed.isEmpty())
            {
                sendText("SUBSCRIBE " + trimmed);
                System.out.println("[Receiver/cluster] Sent: SUBSCRIBE " + trimmed);
            }
        }
        subscribed = true;
    }

    private void sendText(final String message)
    {
        final byte[] bytes = message.getBytes(StandardCharsets.UTF_8);
        final ExpandableArrayBuffer buf = new ExpandableArrayBuffer(bytes.length);
        buf.putBytes(0, bytes);

        final BackoffIdleStrategy idle = new BackoffIdleStrategy();
        long result;
        int retries = 0;
        while ((result = aeronCluster.offer(buf, 0, bytes.length)) < 0 && retries++ < 10)
        {
            idle.idle();
        }
        if (result <= 0)
        {
            System.err.println("[Receiver/cluster] Failed to send: " + message + ", result=" + result);
        }
    }
}
