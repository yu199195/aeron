package io.aeron.spring.cluster.receiver.service;

import io.aeron.Aeron;
import io.aeron.Subscription;
import io.aeron.driver.MediaDriver;
import io.aeron.logbuffer.FragmentHandler;
import io.aeron.spring.cluster.config.ContextFactory;
import io.aeron.spring.cluster.receiver.config.ReceiverProperties;
import io.aeron.spring.cluster.receiver.stroe.MessageStore;
import io.aeron.spring.cluster.sbe.MessageHeaderDecoder;
import io.aeron.spring.cluster.sbe.OrderDecoder;
import io.aeron.spring.cluster.sbe.UserDecoder;
import org.agrona.CloseHelper;
import org.agrona.DirectBuffer;
import org.agrona.concurrent.BackoffIdleStrategy;

import java.nio.charset.StandardCharsets;

/**
 * direct 模式接收器。
 * <p>
 * 订阅 {@link io.aeron.spring.cluster.service.ForwardingClusteredService} 转发的 Aeron UDP 频道，
 * 直接以 SBE 格式接收 Order（streamId=100）和 User（streamId=200）消息。
 * <p>
 * cluster-node 需以 {@code aeron.cluster.service.type: forwarding} 运行。
 */
public class DirectReceiverService implements ReceiverService
{
    private static final int FRAGMENT_LIMIT = 10;

    private final ReceiverProperties props;
    private final MessageStore store;

    private MediaDriver  mediaDriver;
    private Aeron        aeron;
    private Subscription orderSubscription;
    private Subscription userSubscription;

    private Thread          pollThread;
    private volatile boolean running = false;

    // SBE 解码器 flyweight（只在 pollThread 使用）
    private final MessageHeaderDecoder headerDecoder = new MessageHeaderDecoder();
    private final OrderDecoder         orderDecoder  = new OrderDecoder();
    private final UserDecoder          userDecoder   = new UserDecoder();

    public DirectReceiverService(final ReceiverProperties props, final MessageStore store)
    {
        this.props = props;
        this.store = store;
    }

    @Override
    public void start()
    {
        System.out.println("[Receiver/direct] Starting, channel=" + props.getChannel()
            + ", orderStreamId=" + props.getOrderStreamId()
            + ", userStreamId=" + props.getUserStreamId());

        mediaDriver = MediaDriver.launch(ContextFactory.mediaDriverContext(props.getMediaDriver()));

        aeron = Aeron.connect(ContextFactory.aeronContext(props.getAeron(), mediaDriver.aeronDirectoryName()));

        orderSubscription = aeron.addSubscription(props.getChannel(), props.getOrderStreamId());
        userSubscription  = aeron.addSubscription(props.getChannel(), props.getUserStreamId());

        running    = true;
        pollThread = new Thread(this::pollLoop, "aeron-receiver-poll");
        pollThread.setDaemon(true);
        pollThread.start();

        System.out.println("[Receiver/direct] Started, poll thread running");
    }

    @Override
    public void stop()
    {
        System.out.println("[Receiver/direct] Stopping...");
        running = false;
        if (pollThread != null)
        {
            pollThread.interrupt();
        }
        CloseHelper.closeAll(orderSubscription, userSubscription, aeron, mediaDriver);
    }

    @Override
    public boolean isRunning() { return running; }

    @Override
    public String mode() { return "direct"; }

    @Override
    public ReceiverService.ConnectionStatus connectionStatus()
    {
        return new ReceiverService.ConnectionStatus(
            orderSubscription != null && orderSubscription.isConnected(),
            userSubscription  != null && userSubscription.isConnected());
    }

    // ──────────────────────────────────────────────
    // Poll 循环
    // ──────────────────────────────────────────────

    private void pollLoop()
    {
        final BackoffIdleStrategy idle = new BackoffIdleStrategy();
        while (running && !Thread.currentThread().isInterrupted())
        {
            int fragments = 0;
            fragments += orderSubscription.poll(orderHandler, FRAGMENT_LIMIT);
            fragments += userSubscription.poll(userHandler,   FRAGMENT_LIMIT);
            idle.idle(fragments);
        }
    }

    // ──────────────────────────────────────────────
    // FragmentHandler
    // ──────────────────────────────────────────────

    private final FragmentHandler orderHandler = (buffer, offset, length, header) ->
        handleOrder(buffer, offset, length);

    private final FragmentHandler userHandler = (buffer, offset, length, header) ->
        handleUser(buffer, offset, length);

    private void handleOrder(final DirectBuffer buffer, final int offset, final int length)
    {
        if (length < MessageHeaderDecoder.ENCODED_LENGTH)
        {
            System.err.println("[Receiver/direct] Order fragment too short: " + length);
            return;
        }

        orderDecoder.wrapAndApplyHeader(buffer, offset, headerDecoder);

        final long orderId   = orderDecoder.orderId();
        final double price   = orderDecoder.price() / 100.0;
        final int quantity   = orderDecoder.quantity();
        final char side      = (char) orderDecoder.side();
        final long timestamp = orderDecoder.timestamp();

        final int symLen = orderDecoder.symbolLength();
        final byte[] symBytes = new byte[symLen];
        orderDecoder.getSymbol(symBytes, 0, symLen);
        final String symbol = new String(symBytes, StandardCharsets.UTF_8);

        final String summary = String.format(
            "Order{id=%d, symbol=%s, price=%.2f, qty=%d, side=%c, ts=%d}",
            orderId, symbol, price, quantity, side, timestamp);

        final long n = store.appendOrder(summary);
        System.out.printf("[Receiver/direct] Order #%d: %s%n", n, summary);
    }

    private void handleUser(final DirectBuffer buffer, final int offset, final int length)
    {
        if (length < MessageHeaderDecoder.ENCODED_LENGTH)
        {
            System.err.println("[Receiver/direct] User fragment too short: " + length);
            return;
        }

        userDecoder.wrapAndApplyHeader(buffer, offset, headerDecoder);

        final long userId    = userDecoder.userId();
        final int age        = userDecoder.age();
        final double balance = userDecoder.balance() / 100.0;
        final boolean active = userDecoder.isActive() != 0;

        final int unameLen = userDecoder.usernameLength();
        final byte[] unameBytes = new byte[unameLen];
        userDecoder.getUsername(unameBytes, 0, unameLen);
        final String username = new String(unameBytes, StandardCharsets.UTF_8);

        final int emailLen = userDecoder.emailLength();
        final byte[] emailBytes = new byte[emailLen];
        userDecoder.getEmail(emailBytes, 0, emailLen);
        final String email = new String(emailBytes, StandardCharsets.UTF_8);

        final String summary = String.format(
            "User{id=%d, username=%s, email=%s, age=%d, balance=%.2f, active=%s}",
            userId, username, email, age, balance, active);

        final long n = store.appendUser(summary);
        System.out.printf("[Receiver/direct] User #%d: %s%n", n, summary);
    }
}
