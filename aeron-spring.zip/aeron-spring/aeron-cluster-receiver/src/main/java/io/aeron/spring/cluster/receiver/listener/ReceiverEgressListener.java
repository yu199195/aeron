package io.aeron.spring.cluster.receiver.listener;

import io.aeron.cluster.client.EgressListener;
import io.aeron.cluster.codecs.AdminRequestType;
import io.aeron.cluster.codecs.AdminResponseCode;
import io.aeron.cluster.codecs.EventCode;
import io.aeron.logbuffer.Header;
import io.aeron.spring.cluster.receiver.stroe.MessageStore;
import io.aeron.spring.cluster.sbe.MessageHeaderDecoder;
import io.aeron.spring.cluster.sbe.OrderDecoder;
import io.aeron.spring.cluster.sbe.UserDecoder;
import org.agrona.DirectBuffer;

import java.nio.charset.StandardCharsets;

/**
 * cluster 模式的 EgressListener。
 * <p>
 * 接收 PubSubClusteredService 广播的 SBE 消息，解码后写入 {@link MessageStore}。
 * 同时处理文本响应（如 Welcome、订阅确认）。
 */
public class ReceiverEgressListener implements EgressListener
{
    private final MessageStore store;

    // SBE 解码器 flyweight（只在 duty-cycle 线程使用）
    private final MessageHeaderDecoder headerDecoder = new MessageHeaderDecoder();
    private final OrderDecoder         orderDecoder  = new OrderDecoder();
    private final UserDecoder          userDecoder   = new UserDecoder();

    public ReceiverEgressListener(final MessageStore store)
    {
        this.store = store;
    }

    @Override
    public void onMessage(
        final long clusterSessionId,
        final long timestamp,
        final DirectBuffer buffer,
        final int offset,
        final int length,
        final Header header)
    {
        if (length < MessageHeaderDecoder.ENCODED_LENGTH)
        {
            // 纯文本响应（Welcome、订阅确认等）
            final byte[] bytes = new byte[length];
            buffer.getBytes(offset, bytes);
            System.out.println("[Receiver/cluster] Text: " + new String(bytes, StandardCharsets.UTF_8));
            return;
        }

        headerDecoder.wrap(buffer, offset);
        final int templateId = headerDecoder.templateId();

        if (templateId == OrderDecoder.TEMPLATE_ID)
        {
            handleOrder(buffer, offset);
        }
        else if (templateId == UserDecoder.TEMPLATE_ID)
        {
            handleUser(buffer, offset);
        }
        else
        {
            // 未知 SBE 模板，当作文本处理
            final byte[] bytes = new byte[length];
            buffer.getBytes(offset, bytes);
            System.out.println("[Receiver/cluster] Unknown templateId=" + templateId
                + ", text: " + new String(bytes, StandardCharsets.UTF_8));
        }
    }

    @Override
    public void onSessionEvent(
        final long correlationId,
        final long clusterSessionId,
        final long leadershipTermId,
        final int leaderMemberId,
        final EventCode code,
        final String detail)
    {
        System.out.println("[Receiver/cluster] SessionEvent: code=" + code
            + ", detail=" + detail + ", leader=" + leaderMemberId);
    }

    @Override
    public void onNewLeader(
        final long clusterSessionId,
        final long leadershipTermId,
        final int leaderMemberId,
        final String endpoints)
    {
        System.out.println("[Receiver/cluster] New Leader: memberId=" + leaderMemberId
            + ", term=" + leadershipTermId);
    }

    @Override
    public void onAdminResponse(
        final long clusterSessionId,
        final long correlationId,
        final AdminRequestType requestType,
        final AdminResponseCode responseCode,
        final String message,
        final DirectBuffer payload,
        final int payloadOffset,
        final int payloadLength)
    {
        System.out.println("[Receiver/cluster] AdminResponse: type=" + requestType
            + ", code=" + responseCode
            + (message != null && !message.isEmpty() ? ", msg=" + message : ""));
    }

    // ──────────────────────────────────────────────
    // 私有解码方法
    // ──────────────────────────────────────────────

    private void handleOrder(final DirectBuffer buffer, final int offset)
    {
        orderDecoder.wrapAndApplyHeader(buffer, offset, headerDecoder);

        final long orderId   = orderDecoder.orderId();
        final double price   = orderDecoder.price() / 100.0;
        final int quantity   = orderDecoder.quantity();
        final char side      = (char) orderDecoder.side();
        final long timestamp = orderDecoder.timestamp();

        final int symLen = orderDecoder.symbolLength();
        final byte[] symBytes = new byte[symLen];
        orderDecoder.getSymbol(symBytes, 0, symLen);
        final String symbol = new String(symBytes, StandardCharsets.UTF_8);

        final String summary = String.format(
            "Order{id=%d, symbol=%s, price=%.2f, qty=%d, side=%c, ts=%d}",
            orderId, symbol, price, quantity, side, timestamp);

        final long n = store.appendOrder(summary);
        System.out.printf("[Receiver/cluster] Order #%d: %s%n", n, summary);
    }

    private void handleUser(final DirectBuffer buffer, final int offset)
    {
        userDecoder.wrapAndApplyHeader(buffer, offset, headerDecoder);

        final long userId    = userDecoder.userId();
        final int age        = userDecoder.age();
        final double balance = userDecoder.balance() / 100.0;
        final boolean active = userDecoder.isActive() != 0;

        final int unameLen = userDecoder.usernameLength();
        final byte[] unameBytes = new byte[unameLen];
        userDecoder.getUsername(unameBytes, 0, unameLen);
        final String username = new String(unameBytes, StandardCharsets.UTF_8);

        final int emailLen = userDecoder.emailLength();
        final byte[] emailBytes = new byte[emailLen];
        userDecoder.getEmail(emailBytes, 0, emailLen);
        final String email = new String(emailBytes, StandardCharsets.UTF_8);

        final String summary = String.format(
            "User{id=%d, username=%s, email=%s, age=%d, balance=%.2f, active=%s}",
            userId, username, email, age, balance, active);

        final long n = store.appendUser(summary);
        System.out.printf("[Receiver/cluster] User #%d: %s%n", n, summary);
    }
}
