package io.aeron.spring.cluster.store;

import io.aeron.ExclusivePublication;
import io.aeron.Image;
import io.aeron.cluster.service.Cluster;
import io.aeron.spring.cluster.model.OrderRecord;
import io.aeron.spring.cluster.sbe.MessageHeaderDecoder;
import io.aeron.spring.cluster.sbe.MessageHeaderEncoder;
import io.aeron.spring.cluster.sbe.OrderDecoder;
import io.aeron.spring.cluster.sbe.OrderEncoder;
import org.agrona.ExpandableArrayBuffer;
import org.agrona.MutableDirectBuffer;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Order 业务存储。
 *
 * <h3>快照序列化（SBE）</h3>
 * 使用与网络传输完全相同的 {@link OrderEncoder}/{@link OrderDecoder}：
 * <pre>
 * Frame-0  : count (int32) ── 共多少条记录
 * Frame-1…N: SBE Order 消息（MessageHeader + Order body），每条一帧
 * </pre>
 * 读写格式一一对应，字段顺序由 SBE schema 保证，不会手写错位。
 */
public class OrderStore
{
    // orderId → OrderRecord，LinkedHashMap 保持写入顺序
    private final Map<Long, OrderRecord> store = new LinkedHashMap<>();

    // SBE 编解码器（仅快照 I/O 时使用，非线程安全，但快照在单线程服务中调用）
    private final MessageHeaderEncoder headerEncoder = new MessageHeaderEncoder();
    private final MessageHeaderDecoder headerDecoder = new MessageHeaderDecoder();
    private final OrderEncoder         orderEncoder  = new OrderEncoder();
    private final OrderDecoder         orderDecoder  = new OrderDecoder();

    // ──────────────────────────────────────────────
    // 业务操作
    // ──────────────────────────────────────────────

    /**
     * 插入或更新一条 Order 记录（幂等）。
     *
     * @return true 表示新增；false 表示覆盖已有记录
     */
    public boolean upsert(final OrderRecord record)
    {
        final boolean isNew = !store.containsKey(record.orderId());
        store.put(record.orderId(), record);
        return isNew;
    }

    public OrderRecord get(final long orderId)
    {
        return store.get(orderId);
    }

    public List<OrderRecord> all()
    {
        return Collections.unmodifiableList(new ArrayList<>(store.values()));
    }

    public int size()
    {
        return store.size();
    }

    public void clear()
    {
        store.clear();
    }

    // ──────────────────────────────────────────────
    // 快照：写出（SBE 编码）
    // ──────────────────────────────────────────────

    /**
     * 将全部 Order 记录用 SBE 序列化到快照 Publication。
     *
     * <p><b>Frame-0</b>：4 字节 int32，存放记录数量。
     * <p><b>Frame-1…N</b>：每条记录编码为标准 SBE Order 消息
     * （{@code MessageHeader(8字节) + orderId + price + qty + side + ts + symbol}），
     * 和网络传输的消息格式完全一致，可直接用现有 Decoder 读取。
     */
    public void writeSnapshot(
        final ExclusivePublication publication,
        final ExpandableArrayBuffer buf,
        final Cluster cluster)
    {
        // ── Frame-0: 记录总数 ──
        buf.putInt(0, store.size());
        offerUntilDone(publication, buf, 0, Integer.BYTES, cluster);

        // ── Frame-1…N: 每条 Order 用 SBE 编码 ──
        for (final OrderRecord r : store.values())
        {
            final byte[] symBytes = r.symbol().getBytes(StandardCharsets.UTF_8);

            // SBE 编码：先写 MessageHeader，再写 Order body
            // wrapAndApplyHeader 会自动填好 header 并将 encoder 定位到 body 起始位置
            orderEncoder.wrapAndApplyHeader(buf, 0, headerEncoder)
                .orderId(r.orderId())
                .price(r.price())
                .quantity(r.quantity())
                .side((byte) r.side())
                .timestamp(r.timestamp())
                .putSymbol(symBytes, 0, symBytes.length);

            // 总长度 = header 固定长度 + body block 长度 + symbol 变长段（4字节长度前缀 + 数据）
            final int encodedLength = MessageHeaderEncoder.ENCODED_LENGTH
                + OrderEncoder.BLOCK_LENGTH
                + Integer.BYTES          // varStringEncoding.length 字段（uint32）
                + symBytes.length;

            offerUntilDone(publication, buf, 0, encodedLength, cluster);
        }

        System.out.println("  [OrderStore] 快照写出: " + store.size() + " 条 Order 记录 (SBE)");
    }

    // ──────────────────────────────────────────────
    // 快照：读入（SBE 解码）
    // ──────────────────────────────────────────────

    /**
     * 从快照 Image 用 SBE 解码并还原全部 Order 记录。
     *
     * <p>每次 poll 得到一个完整帧，对应 {@link #writeSnapshot} 的一次 offer：
     * <ul>
     *   <li>第 1 帧 → 记录数量（int32）</li>
     *   <li>后续帧 → 标准 SBE Order 消息，用 {@link OrderDecoder} 直接解析</li>
     * </ul>
     */
    public void readSnapshot(
        final Image snapshotImage,
        final ExpandableArrayBuffer buf,
        final Cluster cluster)
    {
        store.clear();

        // ── Frame-0: 记录总数 ──
        pollUntilDone(snapshotImage, buf, cluster);
        final int count = buf.getInt(0);

        // ── Frame-1…N: 每条 Order ──
        for (int i = 0; i < count; i++)
        {
            pollUntilDone(snapshotImage, buf, cluster);

            // 用 wrapAndApplyHeader 解析：它会读取 header，定位 decoder 到 body 起始位置
            orderDecoder.wrapAndApplyHeader(buf, 0, headerDecoder);

            final long orderId   = orderDecoder.orderId();
            final long price     = orderDecoder.price();
            final int  quantity  = orderDecoder.quantity();
            final char side      = (char) orderDecoder.side();
            final long timestamp = orderDecoder.timestamp();

            final int symLen = orderDecoder.symbolLength();
            final byte[] symBytes = new byte[symLen];
            orderDecoder.getSymbol(symBytes, 0, symLen);
            final String symbol = new String(symBytes, StandardCharsets.UTF_8);

            store.put(orderId, new OrderRecord(orderId, symbol, price, quantity, side, timestamp));
        }

        System.out.println("  [OrderStore] 快照恢复: " + store.size() + " 条 Order 记录 (SBE)");
    }

    // ──────────────────────────────────────────────
    // 工具
    // ──────────────────────────────────────────────

    private static void offerUntilDone(
        final ExclusivePublication pub,
        final MutableDirectBuffer buf,
        final int offset,
        final int length,
        final Cluster cluster)
    {
        while (pub.offer(buf, offset, length) < 0)
        {
            cluster.idleStrategy().idle();
        }
    }

    /**
     * 轮询快照流，直到收到一个完整帧，将帧内容写入 buf[0..)。
     *
     * <p>写快照时每条记录是一次独立的 offer，因此 poll 到的每个 fragment
     * 就是一条完整记录，不存在跨帧拼包的问题。
     */
    private static void pollUntilDone(
        final Image image,
        final MutableDirectBuffer buf,
        final Cluster cluster)
    {
        while (true)
        {
            final int[] written = {0};
            final int fragments = image.poll(
                (srcBuf, offset, length, header) ->
                {
                    buf.putBytes(0, srcBuf, offset, length);
                    written[0] = length;
                }, 1);

            if (fragments > 0)
            {
                return;  // 成功读到一帧
            }
            else if (image.isClosed() || image.isEndOfStream())
            {
                throw new IllegalStateException("[OrderStore] 快照流意外关闭");
            }
            else
            {
                cluster.idleStrategy().idle();
            }
        }
    }
}
