package io.aeron.spring.cluster.config;

import lombok.Data;
import org.springframework.boot.context.properties.NestedConfigurationProperty;

/**
 * 快照相关配置，绑定 application.yml 中的 aeron.cluster.snapshot.* 前缀。
 */
@Data
public class SnapshotProperties {
    
    @NestedConfigurationProperty
    private SchedulerConfig scheduler = new SchedulerConfig();

    /**
     * 当本节点成为 Leader 时触发快照，默认 false。
     */
    private boolean onLeaderElection = false;

    /**
     * 日志增长超过 N 字节后触发快照（仅 Leader 节点生效）。
     * 0 禁用，默认 0。示例：268435456 = 256 MB。
     */
    private long logGrowthBytes = 0;
    
    
    @Data
    public static class SchedulerConfig {
        
        private boolean enabled = false;
        
        /**
         * 定时快照间隔（毫秒）；0 或负数禁用，默认 60000。
         */
        private long intervalMs = 60_000;
    }
}
