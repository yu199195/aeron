package io.aeron.spring.cluster;

import io.aeron.spring.cluster.config.ClusterProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

/**
 * cluster-node 启动入口。
 *
 * <h3>K8s StatefulSet 部署（推荐）</h3>
 * 只需配置相同的镜像和 ConfigMap，无需为每个节点单独设置 node-id。
 * StatefulSet 为每个 Pod 分配固定 hostname（pod-name 部分），节点启动时自动推断 nodeId。
 * <pre>
 * # application.yml 或 ConfigMap 中统一配置：
 * aeron.cluster.hostnames=node-0.cluster-svc,node-1.cluster-svc,node-2.cluster-svc
 * aeron.cluster.port-base=9000
 * aeron.cluster.aeron-dir=/data/aeron   # PVC 挂载点
 * </pre>
 *
 * <h3>本地多进程部署（开发/调试）</h3>
 * localhost 无法自动区分节点，需手动指定 node-id：
 * <pre>
 * # 节点 0（端口 8080）
 * java -jar cluster-node.jar --aeron.cluster.node-id=0 --server.port=8080
 *
 * # 节点 1（端口 8081）
 * java -jar cluster-node.jar --aeron.cluster.node-id=1 --server.port=8081
 *
 * # 节点 2（端口 8082）
 * java -jar cluster-node.jar --aeron.cluster.node-id=2 --server.port=8082
 * </pre>
 *
 * <h3>REST 接口</h3>
 * <pre>
 * GET  /cluster/node/status    - 节点状态
 * </pre>
 */
@SpringBootApplication
@EnableConfigurationProperties(ClusterProperties.class)
public class ClusterNodeApplication
{
    public static void main(final String[] args)
    {
        SpringApplication.run(ClusterNodeApplication.class, args);
    }
}
