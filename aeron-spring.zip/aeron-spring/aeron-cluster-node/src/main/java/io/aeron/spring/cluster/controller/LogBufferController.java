package io.aeron.spring.cluster.controller;

import io.aeron.spring.cluster.config.ClusterProperties;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 查看单个 logbuffer 文件内容。
 *
 * <p>访问方式：
 * <pre>
 * GET /cluster/node/logbuffer?type=publications&id=174&maxFrames=20
 * GET /cluster/node/logbuffer?type=images&id=147&maxFrames=20
 * </pre>
 *
 * <p>如需同时查看所有计数器及其对应的 logbuffer，使用：
 * <pre>
 * GET /cluster/node/aeron-stat?includeLogBuffer=true&maxFrames=20
 * </pre>
 */
@RestController
@RequestMapping("/cluster/node")
public class LogBufferController
{
    private final ClusterProperties props;

    public LogBufferController(final ClusterProperties props)
    {
        this.props = props;
    }

    /**
     * @param type      {@code publications} 或 {@code images}
     * @param id        correlationId（即文件名中的 N）
     * @param maxFrames 最多返回多少帧，默认 50
     */
    @GetMapping("/logbuffer")
    public LogBufferReader.LogBufferResult read(
        @RequestParam final String type,
        @RequestParam final long   id,
        @RequestParam(defaultValue = "50") final int maxFrames)
    {
        final String filePath =
            props.aeronDir() + "/aeron-media-driver/" + type + "/" + id + ".logbuffer";
        return LogBufferReader.read(filePath, maxFrames);
    }
}
