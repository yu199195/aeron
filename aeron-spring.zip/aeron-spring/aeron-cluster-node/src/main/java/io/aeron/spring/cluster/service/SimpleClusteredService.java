package io.aeron.spring.cluster.service;

import io.aeron.ExclusivePublication;
import io.aeron.Image;
import io.aeron.cluster.codecs.CloseReason;
import io.aeron.cluster.service.ClientSession;
import io.aeron.cluster.service.Cluster;
import io.aeron.spring.cluster.config.SnapshotProperties;
import io.aeron.spring.cluster.model.OrderRecord;
import io.aeron.spring.cluster.model.UserRecord;
import io.aeron.spring.cluster.sbe.MessageHeaderDecoder;
import io.aeron.spring.cluster.sbe.OrderDecoder;
import io.aeron.spring.cluster.sbe.UserDecoder;
import io.aeron.spring.cluster.snapshot.SnapshotService;
import io.aeron.spring.cluster.store.OrderStore;
import io.aeron.spring.cluster.store.UserStore;
import org.agrona.DirectBuffer;

import java.nio.charset.StandardCharsets;

/**
 * 集群服务实现：接收 Order/User SBE 消息，执行业务处理并持久化到快照。
 *
 * <h3>业务逻辑</h3>
 * <ul>
 *   <li>Order 消息 → 存入 {@link OrderStore}（按 orderId 幂等 upsert）</li>
 *   <li>User  消息 → 存入 {@link UserStore}（按 userId  幂等 upsert）</li>
 *   <li>纯文本 → Echo 回复</li>
 * </ul>
 *
 * <h3>快照机制</h3>
 * <ul>
 *   <li>{@link #onTakeSnapshot}：先调用基类写 globalCount/sessionCounts，
 *       再序列化 OrderStore → UserStore</li>
 *   <li>loadSnapshot：先调用基类读公共数据，再反序列化 OrderStore/UserStore</li>
 * </ul>
 *
 * 本类不是 Spring Bean（由 Aeron 内部线程管理），由 ClusterNodeService 实例化并注入。
 */
public class SimpleClusteredService extends AbstractSnapshotClusteredService
{
    // SBE 解码器 flyweight
    private final MessageHeaderDecoder headerDecoder = new MessageHeaderDecoder();
    private final OrderDecoder         orderDecoder  = new OrderDecoder();
    private final UserDecoder          userDecoder   = new UserDecoder();

    // 业务存储
    private final OrderStore orderStore = new OrderStore();
    private final UserStore  userStore  = new UserStore();

    public SimpleClusteredService(
        final SnapshotService snapshotService,
        final SnapshotProperties snapshotProps)
    {
        super(snapshotService, snapshotProps);
    }

    // ──────────────────────────────────────────────
    // 生命周期
    // ──────────────────────────────────────────────

    @Override
    public void onStart(final Cluster cluster, final Image snapshotImage)
    {
        this.cluster = cluster;

        if (snapshotImage != null)
        {
            loadSnapshot(snapshotImage);
            System.out.println("[Service] 快照恢复完成: globalCount=" + globalMessageCount
                + ", orders=" + orderStore.size()
                + ", users="  + userStore.size());
        }
        else
        {
            System.out.println("[Service] 首次启动，无快照");
        }
    }

    @Override
    public void onSessionOpen(final ClientSession session, final long timestamp)
    {
        System.out.println("[Service] 会话打开: sessionId=" + session.id());
        sessionMessageCounts.put(session.id(), 0L);
    }

    @Override
    public void onSessionClose(final ClientSession session, final long timestamp, final CloseReason closeReason)
    {
        System.out.println("[Service] 会话关闭: sessionId=" + session.id() + ", reason=" + closeReason);
        sessionMessageCounts.remove(session.id());
    }

    @Override
    public void onTimerEvent(final long correlationId, final long timestamp) {}

    @Override
    public void onRoleChange(final Cluster.Role newRole)
    {
        super.onRoleChange(newRole);
        System.out.println("[Service] 角色变更: " + newRole);
    }

    @Override
    public void onTerminate(final Cluster cluster)
    {
        System.out.println("[Service] 正在关闭");
    }

    @Override
    protected void onLeadershipTerm(final long leadershipTermId, final int leaderMemberId)
    {
        System.out.println("[Service] 新领导任期: termId=" + leadershipTermId + ", leaderId=" + leaderMemberId);
    }

    @Override
    public void onSessionMessage(
        final ClientSession session,
        final long timestamp,
        final DirectBuffer buffer,
        final int offset,
        final int length,
        final io.aeron.logbuffer.Header header)
    {
        globalMessageCount++;
        final long sessionCount = sessionMessageCounts.get(session.id()) + 1;
        sessionMessageCounts.put(session.id(), sessionCount);

        checkLogGrowthSnapshot();

        if (length >= MessageHeaderDecoder.ENCODED_LENGTH)
        {
            headerDecoder.wrap(buffer, offset);
            final int templateId = headerDecoder.templateId();

            if (templateId == OrderDecoder.TEMPLATE_ID)
            {
                handleOrder(session, buffer, offset, sessionCount);
                return;
            }
            else if (templateId == UserDecoder.TEMPLATE_ID)
            {
                handleUser(session, buffer, offset, sessionCount);
                return;
            }
        }

        final byte[] bytes = new byte[length];
        buffer.getBytes(offset, bytes);
        final String msg = new String(bytes, StandardCharsets.UTF_8);
        System.out.println("[Service] 文本消息 #" + globalMessageCount + ": " + msg);
        sendText(session, "[Echo #" + globalMessageCount + "] " + msg);
    }

    // ──────────────────────────────────────────────
    // 快照：写出
    // ──────────────────────────────────────────────

    /**
     * 快照序列化顺序（必须与 loadSnapshot 严格对应）：
     * <ol>
     *   <li>基类：globalMessageCount + sessionMessageCounts</li>
     *   <li>OrderStore</li>
     *   <li>UserStore</li>
     * </ol>
     */
    @Override
    public void onTakeSnapshot(final ExclusivePublication snapshotPublication)
    {
        System.out.println("[Service] 保存快照: globalCount=" + globalMessageCount
            + ", orders=" + orderStore.size()
            + ", users="  + userStore.size()
            + ", logPosition=" + cluster.logPosition());

        writeBaseSnapshot(snapshotPublication);
        orderStore.writeSnapshot(snapshotPublication, sharedBuf, cluster);
        userStore.writeSnapshot(snapshotPublication, sharedBuf, cluster);

        System.out.println("[Service] 快照保存完成");
    }
    

    // ──────────────────────────────────────────────
    // 私有方法
    // ──────────────────────────────────────────────

    private void loadSnapshot(final Image snapshotImage)
    {
        readBaseSnapshot(snapshotImage);
        orderStore.readSnapshot(snapshotImage, sharedBuf, cluster);
        userStore.readSnapshot(snapshotImage, sharedBuf, cluster);
    }

    private void handleOrder(
        final ClientSession session,
        final DirectBuffer buffer,
        final int offset,
        final long sessionCount)
    {
        orderDecoder.wrapAndApplyHeader(buffer, offset, headerDecoder);

        final long   orderId   = orderDecoder.orderId();
        final long   price     = orderDecoder.price();
        final int    quantity  = orderDecoder.quantity();
        final char   side      = (char) orderDecoder.side();
        final long   timestamp = orderDecoder.timestamp();

        final int symLen = orderDecoder.symbolLength();
        final byte[] symBytes = new byte[symLen];
        orderDecoder.getSymbol(symBytes, 0, symLen);
        final String symbol = new String(symBytes, StandardCharsets.UTF_8);

        final OrderRecord record = new OrderRecord(orderId, symbol, price, quantity, side, timestamp);
        final boolean isNew = orderStore.upsert(record);

        System.out.printf("[Service] Order #%d (%s): id=%d, symbol=%s, price=%.2f, qty=%d, side=%c, ts=%d%n",
            globalMessageCount, isNew ? "新增" : "更新",
            orderId, symbol, price / 100.0, quantity, side, timestamp);

        sendText(session, String.format(
            "[Order %s #%d] id=%d, symbol=%s, price=%.2f, qty=%d, side=%c | 库存总量: %d (global=%d, session=%d)",
            isNew ? "Saved" : "Updated",
            globalMessageCount, orderId, symbol, price / 100.0, quantity, side,
            orderStore.size(), globalMessageCount, sessionCount));
    }

    private void handleUser(
        final ClientSession session,
        final DirectBuffer buffer,
        final int offset,
        final long sessionCount)
    {
        userDecoder.wrapAndApplyHeader(buffer, offset, headerDecoder);

        final long    userId  = userDecoder.userId();
        final int     age     = userDecoder.age();
        final long    balance = userDecoder.balance();
        final boolean active  = userDecoder.isActive() != 0;

        final int unameLen = userDecoder.usernameLength();
        final byte[] unameBytes = new byte[unameLen];
        userDecoder.getUsername(unameBytes, 0, unameLen);
        final String username = new String(unameBytes, StandardCharsets.UTF_8);

        final int emailLen = userDecoder.emailLength();
        final byte[] emailBytes = new byte[emailLen];
        userDecoder.getEmail(emailBytes, 0, emailLen);
        final String email = new String(emailBytes, StandardCharsets.UTF_8);

        final UserRecord record = new UserRecord(userId, username, email, age, balance, active);
        final boolean isNew = userStore.upsert(record);

        System.out.printf("[Service] User #%d (%s): id=%d, name=%s, email=%s, age=%d, balance=%.2f, active=%s%n",
            globalMessageCount, isNew ? "新增" : "更新",
            userId, username, email, age, balance / 100.0, active);

        sendText(session, String.format(
            "[User %s #%d] id=%d, name=%s, email=%s, balance=%.2f | 库存总量: %d (global=%d, session=%d)",
            isNew ? "Saved" : "Updated",
            globalMessageCount, userId, username, email, balance / 100.0,
            userStore.size(), globalMessageCount, sessionCount));
    }

    private void sendText(final ClientSession session, final String message)
    {
        if (cluster.role() != Cluster.Role.LEADER)
        {
            return;
        }
        final byte[] bytes = message.getBytes(StandardCharsets.UTF_8);
        sharedBuf.putBytes(0, bytes);
        long result;
        int retries = 0;
        while ((result = session.offer(sharedBuf, 0, bytes.length)) < 0 && retries++ < 3)
        {
            cluster.idleStrategy().idle();
        }
        if (result <= 0)
        {
            System.err.println("[Service] 回复失败: " + result);
        }
    }
}
