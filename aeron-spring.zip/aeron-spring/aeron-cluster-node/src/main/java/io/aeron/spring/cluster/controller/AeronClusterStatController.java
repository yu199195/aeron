package io.aeron.spring.cluster.controller;

import io.aeron.CncFileDescriptor;
import io.aeron.cluster.ElectionState;
import io.aeron.cluster.NodeStateFile;
import io.aeron.cluster.RecordingLog;
import io.aeron.cluster.service.ClusterMarkFile;
import io.aeron.driver.reports.LossReportReader;
import io.aeron.driver.reports.LossReportUtil;
import io.aeron.spring.cluster.config.ClusterProperties;
import io.aeron.spring.cluster.util.ClusterDirs;
import org.agrona.IoUtil;
import org.agrona.concurrent.UnsafeBuffer;
import org.agrona.concurrent.errors.ErrorLogReader;
import org.agrona.concurrent.status.CountersReader;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 读取节点各诊断文件，提供多个观测接口。
 *
 * <pre>
 * GET /cluster/node/aeron-stat                              cnc.dat：驱动元数据 + 错误日志 + 所有计数器
 * GET /cluster/node/aeron-stat?includeLogBuffer=true        同上，附带各计数器对应的 logbuffer 帧
 * GET /cluster/node/loss-report                             loss-report.dat：丢包统计
 * GET /cluster/node/recording-log                           aeron-cluster/recording.log：任期/快照历史
 * GET /cluster/node/cluster-status                          cnc.dat + cluster-mark.dat：选举诊断
 * </pre>
 */
@RestController
@RequestMapping("/cluster/node")
public class AeronClusterStatController
{
    /** 从 label 中提取 correlationId 的正则 */
    private static final Pattern CORRELATION_ID_PATTERN =
        Pattern.compile("correlationId=(\\d+)");

    private final ClusterProperties props;

    public AeronClusterStatController(final ClusterProperties props)
    {
        this.props = props;
    }

    /**
     * 解析 cnc.dat 全部内容：驱动元数据、错误日志、所有计数器。
     *
     * @param aeronDir         节点根目录（不传则使用配置的默认值）
     * @param includeLogBuffer 是否同时嵌入每个计数器对应的 logbuffer 帧，默认 false
     * @param maxFrames        嵌入 logbuffer 时最多返回多少帧，默认 20
     */
    @GetMapping("/aeron-stat")
    public AeronStatResult aeronStat(
        @RequestParam(required = false)        final String  aeronDir,
        @RequestParam(defaultValue = "false")  final boolean includeLogBuffer,
        @RequestParam(defaultValue = "20")     final int     maxFrames)
    {
        final String mediaDriverDir = ClusterDirs.mediaDriverDir(resolveAeronDir(aeronDir));
        final File   cncFile        = new File(mediaDriverDir, CncFileDescriptor.CNC_FILE);

        if (!cncFile.exists())
        {
            return new AeronStatResult("cnc.dat not found: " + cncFile, null, List.of(), List.of());
        }

        CncMetadata          metadata = null;
        final List<CncError>  errors   = new ArrayList<>();
        final List<CounterEntry> counters = new ArrayList<>();

        try (FileChannel channel = FileChannel.open(cncFile.toPath(), StandardOpenOption.READ))
        {
            final MappedByteBuffer cncBuf  = channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size());
            final var              metaBuf = CncFileDescriptor.createMetaDataBuffer(cncBuf);
            CncFileDescriptor.checkVersion(metaBuf.getInt(CncFileDescriptor.cncVersionOffset(0)));

            // ── 元数据 ────────────────────────────────────────────────
            metadata = new CncMetadata(
                metaBuf.getInt(CncFileDescriptor.cncVersionOffset(0)),
                CncFileDescriptor.pid(metaBuf),
                Instant.ofEpochMilli(CncFileDescriptor.startTimestampMs(metaBuf)),
                CncFileDescriptor.clientLivenessTimeoutNs(metaBuf),
                metaBuf.getInt(CncFileDescriptor.toDriverBufferLengthOffset(0)),
                metaBuf.getInt(CncFileDescriptor.toClientsBufferLengthOffset(0)),
                metaBuf.getInt(CncFileDescriptor.countersMetaDataBufferLengthOffset(0)),
                metaBuf.getInt(CncFileDescriptor.countersValuesBufferLengthOffset(0)),
                metaBuf.getInt(CncFileDescriptor.errorLogBufferLengthOffset(0)));

            // ── 错误日志 ──────────────────────────────────────────────
            final var errorBuf = CncFileDescriptor.createErrorLogBuffer(cncBuf, metaBuf);
            ErrorLogReader.read(errorBuf, (count, firstTs, lastTs, ex) ->
                errors.add(new CncError(count,
                    Instant.ofEpochMilli(firstTs),
                    Instant.ofEpochMilli(lastTs),
                    ex.strip())));

            // ── 计数器 ────────────────────────────────────────────────
            final CountersReader cr = new CountersReader(
                CncFileDescriptor.createCountersMetaDataBuffer(cncBuf, metaBuf),
                CncFileDescriptor.createCountersValuesBuffer(cncBuf, metaBuf));

            cr.forEach((counterId, typeId, keyBuffer, label) ->
            {
                final TypeInfo info     = TypeInfo.of(typeId);
                final String   filePath = resolveFilePath(mediaDriverDir, typeId, label);

                final LogBufferReader.LogBufferResult logBuffer =
                    (includeLogBuffer && filePath != null)
                        ? LogBufferReader.read(filePath, maxFrames)
                        : null;

                counters.add(new CounterEntry(
                    counterId, typeId, info.typeName(), info.description(),
                    cr.getCounterValue(counterId), label, filePath, logBuffer));
            });

            IoUtil.unmap(cncBuf);
        }
        catch (final Exception e)
        {
            return new AeronStatResult("读取 cnc.dat 失败: " + e.getMessage(), null, List.of(), List.of());
        }

        return new AeronStatResult("ok", metadata, errors, counters);
    }

    // ──────────────────────────────────────────────────────────────────
    // 丢包统计接口
    // ──────────────────────────────────────────────────────────────────

    /**
     * 解析 loss-report.dat，返回所有丢包统计条目。
     *
     * <p>每个条目记录了在特定 channel/stream/session 上的累计丢包情况，
     * 包括首次/末次观测时间、累计丢失字节数、观测次数。
     * <pre>
     * GET /cluster/node/loss-report
     * </pre>
     */
    @GetMapping("/loss-report")
    public LossReportResult lossReport(
        @RequestParam(required = false) final String aeronDir)
    {
        final String mediaDriverDir = ClusterDirs.mediaDriverDir(resolveAeronDir(aeronDir));
        final File   lossFile       = LossReportUtil.file(mediaDriverDir);

        if (!lossFile.exists())
        {
            return new LossReportResult("loss-report.dat not found: " + lossFile, List.of());
        }

        final List<LossEntry> entries = new ArrayList<>();

        try
        {
            final MappedByteBuffer buf = LossReportUtil.mapLossReportReadOnly(mediaDriverDir);
            LossReportReader.read(
                new UnsafeBuffer(buf),
                (observationCount, totalBytesLost, firstObservationTimestamp, lastObservationTimestamp,
                 sessionId, streamId, channel, source) ->
                    entries.add(new LossEntry(
                        observationCount,
                        totalBytesLost,
                        Instant.ofEpochMilli(firstObservationTimestamp),
                        Instant.ofEpochMilli(lastObservationTimestamp),
                        sessionId,
                        streamId,
                        channel,
                        source)));
            IoUtil.unmap(buf);
        }
        catch (final Exception e)
        {
            return new LossReportResult("读取 loss-report.dat 失败: " + e.getMessage(), List.of());
        }

        return new LossReportResult("ok", entries);
    }

    // ──────────────────────────────────────────────────────────────────
    // 录制日志接口
    // ──────────────────────────────────────────────────────────────────

    /**
     * 解析集群目录下的 {@code recording.log}，返回所有任期/快照历史条目。
     *
     * <p>recording.log 记录了集群自启动以来每一个 Raft term 和快照的元数据，
     * 是诊断集群重启、快照恢复、日志追赶问题的关键文件。
     * <pre>
     * GET /cluster/node/recording-log
     * </pre>
     *
     * <p>条目类型说明：
     * <ul>
     *   <li>{@code TERM}             - 一个 Raft 任期的日志段</li>
     *   <li>{@code SNAPSHOT}         - 普通快照</li>
     *   <li>{@code STANDBY_SNAPSHOT} - 备节点快照（1.50+ 新增）</li>
     * </ul>
     */
    @GetMapping("/recording-log")
    public RecordingLogResult recordingLog(
        @RequestParam(required = false) final String aeronDir)
    {
        final File clusterDir = ClusterDirs.clusterDir(resolveAeronDir(aeronDir));
        final File logFile    = new File(clusterDir, RecordingLog.RECORDING_LOG_FILE_NAME);

        if (!logFile.exists())
        {
            return new RecordingLogResult("recording.log not found: " + logFile, List.of());
        }

        final List<RecordingEntry> entries = new ArrayList<>();

        try (RecordingLog log = new RecordingLog(clusterDir, false))
        {
            for (final RecordingLog.Entry e : log.entries())
            {
                final String typeName = switch (e.type & ~RecordingLog.ENTRY_TYPE_INVALID_FLAG)
                {
                    case RecordingLog.ENTRY_TYPE_TERM             -> "TERM";
                    case RecordingLog.ENTRY_TYPE_SNAPSHOT         -> "SNAPSHOT";
                    case RecordingLog.ENTRY_TYPE_STANDBY_SNAPSHOT -> "STANDBY_SNAPSHOT";
                    default                                        -> "UNKNOWN(" + e.type + ")";
                };

                entries.add(new RecordingEntry(
                    e.entryIndex,
                    typeName,
                    e.isValid,
                    e.recordingId,
                    e.leadershipTermId,
                    e.termBaseLogPosition,
                    e.logPosition,
                    e.timestamp > 0 ? Instant.ofEpochMilli(e.timestamp) : null,
                    e.serviceId,
                    e.archiveEndpoint));
            }
        }
        catch (final Exception e)
        {
            return new RecordingLogResult("读取 recording.log 失败: " + e.getMessage(), List.of());
        }

        return new RecordingLogResult("ok", entries);
    }

    // ──────────────────────────────────────────────────────────────────
    // 集群选举诊断端点
    // ──────────────────────────────────────────────────────────────────

    /**
     * 读取本节点 cnc.dat + cluster-mark.dat，返回人类可读的集群选举诊断信息。
     * <pre>
     * GET /cluster/node/cluster-status
     * </pre>
     *
     * <p>关键字段说明：
     * <ul>
     *   <li><b>nodeRole</b>：当前节点角色，正常应为 LEADER 或 FOLLOWER</li>
     *   <li><b>electionState</b>：选举阶段；选举完成后 Aeron 会释放该 counter，
     *       此时显示 "N/A (election completed)" — 集群稳定运行时这是正常的</li>
     *   <li><b>cmState</b>：ConsensusModule 状态，ACTIVE 才是正常工作状态</li>
     *   <li><b>commitPosition</b>：已提交日志位置，集群正常工作时应持续增长</li>
     *   <li><b>electionCount</b>：累计选举次数，一直为 0 表示选举从未完成</li>
     *   <li><b>leadershipTermId</b>：当前 term，-1 表示从未选出 Leader</li>
     *   <li><b>markFileErrors</b>：cluster-mark.dat 中记录的错误日志</li>
     * </ul>
     */
    @GetMapping("/cluster-status")
    public ClusterStatusResult clusterStatus(
        @RequestParam(required = false) final String aeronDir)
    {
        final String resolvedDir    = resolveAeronDir(aeronDir);
        final String mediaDriverDir = ClusterDirs.mediaDriverDir(resolvedDir);
        final File   cncFile        = new File(mediaDriverDir, CncFileDescriptor.CNC_FILE);
        final File   clusterDir     = ClusterDirs.clusterDir(resolvedDir);
        final File   markFile       = new File(clusterDir, ClusterMarkFile.FILENAME);

        // ── 1. 读 cnc.dat ─────────────────────────────────────────────
        ClusterCounters raw      = null;
        String          cncError = null;

        if (!cncFile.exists())
        {
            cncError = "cnc.dat not found: " + cncFile;
        }
        else
        {
            try (FileChannel ch = FileChannel.open(cncFile.toPath(), StandardOpenOption.READ))
            {
                final MappedByteBuffer buf  = ch.map(FileChannel.MapMode.READ_ONLY, 0, ch.size());
                final var              meta = CncFileDescriptor.createMetaDataBuffer(buf);
                CncFileDescriptor.checkVersion(meta.getInt(CncFileDescriptor.cncVersionOffset(0)));

                final CountersReader cr = new CountersReader(
                    CncFileDescriptor.createCountersMetaDataBuffer(buf, meta),
                    CncFileDescriptor.createCountersValuesBuffer(buf, meta));

                raw = ClusterCounters.read(cr);
                IoUtil.unmap(buf);
            }
            catch (final Exception e)
            {
                cncError = "读取 cnc.dat 失败: " + e.getMessage();
            }
        }

        // ── 2. 读 cluster-mark.dat ────────────────────────────────────
        final List<String> markErrors        = new ArrayList<>();
        String             markInfo          = null;
        long               markCandidateTerm = Long.MIN_VALUE; // Long.MIN_VALUE 表示未读到

        if (!markFile.exists())
        {
            markInfo = "cluster-mark.dat not found: " + markFile;
        }
        else
        {
            try (ClusterMarkFile cmf = new ClusterMarkFile(
                clusterDir, ClusterMarkFile.FILENAME, System::currentTimeMillis, 5_000, msg -> {}))
            {
                markCandidateTerm = cmf.candidateTermId();
                markInfo = "memberId=" + cmf.memberId()
                    + "  clusterId=" + cmf.clusterId()
                    + "  candidateTermId=" + markCandidateTerm
                    + "  activityTimestamp=" + Instant.ofEpochMilli(cmf.activityTimestampVolatile());

                ErrorLogReader.read(cmf.errorBuffer(), (count, firstTimestamp, lastTimestamp, ex) ->
                    markErrors.add("[" + count + "x " + Instant.ofEpochMilli(firstTimestamp) + "] " + ex));
            }
            catch (final Exception e)
            {
                markInfo = "读取 cluster-mark.dat 失败: " + e.getMessage();
            }
        }

        // ── 3. 读 node-state.dat ──────────────────────────────────────
        // node-state.dat 在每次选举尝试时都会更新 candidateTermId，
        // 而 cluster-mark.dat 的 candidateTermId 在失败选举中不一定更新，
        // 取两者较大值以准确判断是否存在未成功的选举尝试。
        long nodeStateCandidateTerm = Long.MIN_VALUE;
        final File nodeStateFile = new File(clusterDir, NodeStateFile.FILENAME);
        if (nodeStateFile.exists())
        {
            try (NodeStateFile nsf = new NodeStateFile(clusterDir, false, 0))
            {
                nodeStateCandidateTerm = nsf.candidateTerm().candidateTermId();
            }
            catch (final Exception ignored) {}
        }

        // 取两个来源中较大的 candidateTermId
        long effectiveCandidateTerm = Long.MIN_VALUE;
        if (markCandidateTerm != Long.MIN_VALUE)
        {
            effectiveCandidateTerm = markCandidateTerm;
        }
        if (nodeStateCandidateTerm != Long.MIN_VALUE)
        {
            effectiveCandidateTerm = effectiveCandidateTerm == Long.MIN_VALUE
                ? nodeStateCandidateTerm
                : Math.max(effectiveCandidateTerm, nodeStateCandidateTerm);
        }

        // ── 4. 格式化 + 诊断建议 + 健康状态 ──────────────────────────
        final Map<String, Object> display = raw != null ? raw.toDisplayMap() : Map.of();
        final List<String>        hints   = buildHints(raw, markErrors);
        final ClusterHealth       health  = buildHealth(raw, effectiveCandidateTerm);

        return new ClusterStatusResult(health, cncError, display, markInfo, markErrors, hints);
    }

    // ──────────────────────────────────────────────────────────────────
    // node-state.dat 接口
    // ──────────────────────────────────────────────────────────────────

    /**
     * 读取本节点集群目录下的 {@code node-state.dat}，返回候选任期信息。
     *
     * <pre>
     * GET /cluster/node/node-state
     * </pre>
     *
     * <p>{@code node-state.dat} 由 ConsensusModule 维护，记录节点参与过的最大候选 term，
     * 用于在重启后防止以旧 term 重复投票（Raft 持久化投票保证）。
     *
     * <p>关键字段说明：
     * <ul>
     *   <li><b>candidateTermId</b>：节点见过的最大候选 term ID，重启后不会回退</li>
     *   <li><b>logPosition</b>：产生该候选 term 时的 log position</li>
     *   <li><b>timestamp</b>：该候选 term 最后更新的时间戳（epoch ms）</li>
     * </ul>
     */
    @GetMapping("/node-state")
    public NodeStateResult nodeState(
        @RequestParam(required = false) final String aeronDir)
    {
        final File clusterDir    = ClusterDirs.clusterDir(resolveAeronDir(aeronDir));
        final File nodeStateFile = new File(clusterDir, NodeStateFile.FILENAME);

        if (!nodeStateFile.exists())
        {
            return new NodeStateResult("node-state.dat not found: " + nodeStateFile, null);
        }

        try (NodeStateFile nsf = new NodeStateFile(clusterDir, false, 0))
        {
            final NodeStateFile.CandidateTerm ct = nsf.candidateTerm();
            return new NodeStateResult("ok", new NodeStateCandidateTerm(
                ct.candidateTermId(),
                ct.logPosition(),
                ct.timestamp() > 0 ? Instant.ofEpochMilli(ct.timestamp()) : null));
        }
        catch (final Exception e)
        {
            return new NodeStateResult("读取 node-state.dat 失败: " + e.getMessage(), null);
        }
    }

    // ──────────────────────────────────────────────────────────────────
    // 原始 counter 值容器（避免 buildHints 通过字符串解析判断逻辑）
    // ──────────────────────────────────────────────────────────────────

    /**
     * 持有从 cnc.dat 读出的 7 个集群核心 counter 原始值。
     * 未分配的 counter 值为 {@code -1}。
     */
    private record ClusterCounters(
        long cmState,
        long nodeRole,
        long electionState,
        long electionCount,
        long leadershipTermId,
        long commitPosition,
        long cmErrorCount,
        long serviceErrorCount)
    {
        static ClusterCounters read(final CountersReader cr)
        {
            return new ClusterCounters(
                findCounter(cr, TypeInfo.CLUSTER_CM_STATE.typeId),
                findCounter(cr, TypeInfo.CLUSTER_NODE_ROLE.typeId),
                findCounter(cr, TypeInfo.CLUSTER_ELECTION_STATE.typeId),
                findCounter(cr, TypeInfo.CLUSTER_ELECTION_COUNT.typeId),
                findCounter(cr, TypeInfo.CLUSTER_LEADERSHIP_TERM_ID.typeId),
                findCounter(cr, TypeInfo.CLUSTER_COMMIT_POSITION.typeId),
                findCounter(cr, TypeInfo.CLUSTER_CM_ERROR_COUNT.typeId),
                findCounter(cr, TypeInfo.CLUSTER_SERVICE_ERROR_COUNT.typeId));
        }

        /** 将原始值转为人类可读的显示 Map（用于 JSON 输出）。 */
        Map<String, Object> toDisplayMap()
        {
            final Map<String, Object> m = new LinkedHashMap<>();
            m.put("cmState",          cmState        < 0 ? "N/A" : cmStateName((int) cmState)  + " (" + cmState + ")");
            m.put("nodeRole",         nodeRole        < 0 ? "N/A" : roleName((int) nodeRole)    + " (" + nodeRole + ")");
            // electionState counter 在选举完成后会被 Aeron 释放，-1 表示当前无进行中的选举
            m.put("electionState",    electionState   < 0 ? "N/A (election completed or not started)"
                                                          : ElectionState.get(electionState).name() + " (" + electionState + ")");
            m.put("electionCount",    electionCount   < 0 ? "N/A" : electionCount);
            m.put("leadershipTermId", leadershipTermId < 0 ? "N/A" : leadershipTermId);
            m.put("commitPosition",   commitPosition  < 0 ? "N/A" : commitPosition);
            m.put("cmErrorCount",     cmErrorCount    < 0 ? "N/A" : cmErrorCount);
            m.put("serviceErrorCount",serviceErrorCount < 0 ? "N/A" : serviceErrorCount);
            return m;
        }

        boolean isActive()       { return cmState == 1; }
        boolean neverElected()   { return electionCount == 0; }
        boolean electionOngoing(){ return electionState >= 0; }
    }

    /**
     * 从 CountersReader 中找到指定 typeId 的第一个 counter 值。
     * 返回 {@code -1} 表示该 counter 尚未分配（组件还未启动到相应阶段，或已被释放）。
     */
    private static long findCounter(final CountersReader cr, final int typeId)
    {
        final long[] result = {-1L};
        cr.forEach((counterId, tid, keyBuffer, label) ->
        {
            if (tid == typeId && result[0] == -1L)
            {
                result[0] = cr.getCounterValue(counterId);
            }
        });
        return result[0];
    }

    private static String cmStateName(final int v)
    {
        return switch (v)
        {
            case 0 -> "INIT";
            case 1 -> "ACTIVE";
            case 2 -> "SUSPENDED";
            case 3 -> "CLOSED";
            default -> "UNKNOWN";
        };
    }

    private static String roleName(final int v)
    {
        return switch (v)
        {
            case 0 -> "FOLLOWER";
            case 1 -> "CANDIDATE";
            case 2 -> "LEADER";
            case 3 -> "REPLAY";
            default -> "UNKNOWN";
        };
    }

    /**
     * 根据原始 counter 值生成诊断建议列表。
     *
     * <p>electionState counter 在选举完成后会被 Aeron 释放（值为 -1），
     * 因此当 cmState=ACTIVE 且 electionCount>0 时，electionState=-1 是正常现象，
     * 不应视为警告。
     */
    private static List<String> buildHints(
        final ClusterCounters raw,
        final List<String> markErrors)
    {
        final List<String> hints = new ArrayList<>();

        if (raw == null)
        {
            hints.add("WARNING: 无法读取 cnc.dat，所有状态未知");
            return hints;
        }

        // ── cmState ────────────────────────────────────────────────────
        if (!raw.isActive())
        {
            hints.add("WARNING: cmState=" + (raw.cmState < 0 ? "N/A" : cmStateName((int) raw.cmState))
                + "，ConsensusModule 未处于 ACTIVE 状态");
        }

        // ── 选举状态 ───────────────────────────────────────────────────
        if (raw.electionOngoing())
        {
            // 有正在进行的选举
            final ElectionState state = ElectionState.get(raw.electionState);
            if (state == ElectionState.CLOSED)
            {
                hints.add("INFO: 选举已完成（CLOSED），集群处于正常工作状态");
            }
            else if (state == ElectionState.CANVASS || state == ElectionState.NOMINATE)
            {
                hints.add("WARNING: 节点卡在 " + state.name() + " 阶段，无法获得多数票");
                hints.add("  可能原因 1：其他节点未启动或网络不通（检查 member-facing 端口）");
                hints.add("  可能原因 2：多个节点 node-id 相同（确认 --aeron.cluster.node-id 不重复）");
                hints.add("  可能原因 3：旧数据残留（尝试 delete-consensus-on-start: true 后重启）");
            }
        }
        else if (!raw.isActive())
        {
            // cmState 非 ACTIVE，无法判断选举状态
            hints.add("WARNING: electionState counter 未分配，且 ConsensusModule 非 ACTIVE，节点可能未完成启动");
        }

        // ── 节点角色 ───────────────────────────────────────────────────
        if (raw.nodeRole == 2)
        {
            hints.add("INFO: 本节点当前是 LEADER");
        }
        else if (raw.nodeRole == 0)
        {
            hints.add("INFO: 本节点当前是 FOLLOWER");
        }

        // ── 选举计数 ───────────────────────────────────────────────────
        if (raw.neverElected())
        {
            hints.add("WARNING: electionCount=0，选举从未成功完成过");
        }

        if (raw.leadershipTermId < 0)
        {
            hints.add("WARNING: leadershipTermId=-1，从未选出过 Leader");
        }

        // ── 错误计数 ───────────────────────────────────────────────────
        if (raw.cmErrorCount > 0)
        {
            hints.add("WARNING: cmErrorCount=" + raw.cmErrorCount + "，查看 markFileErrors 获取详情");
        }

        if (!markErrors.isEmpty())
        {
            hints.add("ERROR: cluster-mark.dat 中有 " + markErrors.size() + " 条错误记录，见 markFileErrors 字段");
        }

        return hints;
    }

    /**
     * 仅当集群选不出 leader 时返回 {@code UNHEALTHY}，其他情况均返回 {@code HEALTHY}。
     *
     * <p>选不出 leader 的判定条件（满足任一）：
     * <ul>
     *   <li>节点是 CANDIDATE（正在发起选举但尚未获得多数票）</li>
     *   <li>electionState counter 存在且不是 CLOSED（选举卡在 CANVASS / NOMINATE 等阶段）</li>
     *   <li>从未完成过选举（electionCount=0 或 leadershipTermId=-1）</li>
     *   <li>{@code candidateTermId > leadershipTermId}：mark 文件中的候选任期号超过已提交任期号，
     *       说明存在未成功完成的选举尝试（覆盖了 electionState counter 在重试间隙短暂为 -1 的窗口期）</li>
     * </ul>
     *
     * @param raw              从 cnc.dat 读取的 counter 快照，null 表示读取失败
     * @param markCandidateTerm 从 cluster-mark.dat 读取的 candidateTermId，
     *                          {@code Long.MIN_VALUE} 表示文件不存在或读取失败
     */
    private static ClusterHealth buildHealth(final ClusterCounters raw, final long markCandidateTerm)
    {
        if (raw == null)
        {
            return ClusterHealth.HEALTHY;
        }

        // 节点正在发起选举（CANDIDATE 角色）
        if (raw.nodeRole == 1)
        {
            return ClusterHealth.UNHEALTHY;
        }

        // 选举卡住：electionState counter 存在且未完成
        if (raw.electionOngoing() && ElectionState.get(raw.electionState) != ElectionState.CLOSED)
        {
            return ClusterHealth.UNHEALTHY;
        }

        // 从未完成过选举
        if (raw.neverElected() || raw.leadershipTermId < 0)
        {
            return ClusterHealth.UNHEALTHY;
        }

        // candidateTermId > leadershipTermId：有选举尝试未能成功提交
        // 覆盖 electionState counter 在两次重试之间短暂为 -1 的窗口期
        if (markCandidateTerm != Long.MIN_VALUE && markCandidateTerm > raw.leadershipTermId)
        {
            return ClusterHealth.UNHEALTHY;
        }

        return ClusterHealth.HEALTHY;
    }

    /**
     * 解析节点根目录：优先使用请求参数，未传则回退到配置值。
     *
     * @param aeronDir 请求参数（可为 null）
     * @return 实际使用的节点根目录路径
     */
    private String resolveAeronDir(final String aeronDir)
    {
        return (aeronDir != null && !aeronDir.isBlank()) ? aeronDir.strip() : props.aeronDir();
    }

    /**
     * 集群整体健康状态。
     *
     * <ul>
     *   <li>{@code HEALTHY}   – cmState=ACTIVE，已选出 Leader，无进行中的选举，无错误</li>
     *   <li>{@code DEGRADED}  – 集群仍可服务，但存在警告（如错误计数 >0 或首次启动尚未完成第一次选举）</li>
     *   <li>{@code UNHEALTHY} – 无法选出 Leader（选举卡住）、ConsensusModule 非 ACTIVE、或文件无法读取</li>
     * </ul>
     */
    public enum ClusterHealth { HEALTHY, DEGRADED, UNHEALTHY }

    public record ClusterStatusResult(
        ClusterHealth health,
        String readError,
        Map<String, Object> counters,
        String markFileInfo,
        List<String> markFileErrors,
        List<String> hints) {}

    /**
     * /node-state 响应：node-state.dat 内容。
     *
     * @param status        "ok" 或错误消息
     * @param candidateTerm 候选任期信息（文件不存在或读取失败时为 null）
     */
    public record NodeStateResult(
        String status,
        NodeStateCandidateTerm candidateTerm) {}

    /**
     * node-state.dat 中的候选任期记录（Raft 持久化投票保证）。
     *
     * @param candidateTermId 节点见过的最大候选 term ID
     * @param logPosition     产生该候选 term 时的 log position
     * @param timestamp       最后更新时间（若未记录则为 null）
     */
    public record NodeStateCandidateTerm(
        long candidateTermId,
        long logPosition,
        Instant timestamp) {}

    // ──────────────────────────────────────────────────────────────────
    // 文件路径解析
    // ──────────────────────────────────────────────────────────────────

    private static String resolveFilePath(
        final String mediaDriverDir, final int typeId, final String label)
    {
        final String subDir = TypeInfo.logbufferSubDir(typeId);
        if (subDir == null)
        {
            return null;
        }

        final Matcher m = CORRELATION_ID_PATTERN.matcher(label);
        if (!m.find())
        {
            return null;
        }

        return mediaDriverDir + "/" + subDir + "/" + m.group(1) + ".logbuffer";
    }

    // ──────────────────────────────────────────────────────────────────
    // typeId 元数据
    // ──────────────────────────────────────────────────────────────────

    /**
     * typeId → 名称、描述、对应 logbuffer 子目录。
     * 常量值来自 {@code io.aeron.AeronCounters}（1.44.1）。
     */
    enum TypeInfo
    {
        // ── Driver：Publication 侧 ──────────────────────────────────
        DRIVER_PUBLISHER_LIMIT      (1,  "publications", "Publication 发送上限（流控限制，发布者不能超过此位置）"),
        DRIVER_SENDER_POSITION      (2,  "publications", "Sender 已发送到网络的位置"),
        DRIVER_SENDER_LIMIT         (9,  "publications", "Sender 发送上限（接收窗口反压）"),
        DRIVER_PUBLISHER_POS        (11, "publications", "Publication 已确认写入的位置"),

        // ── Driver：Subscription / Image 侧 ────────────────────────
        DRIVER_RECEIVER_HWM         (3,  "images", "Image 接收高水位（已收到的最远位置）"),
        DRIVER_SUBSCRIBER_POSITION  (4,  "images", "Subscriber 消费位置（应用已 poll 到此）"),
        DRIVER_RECEIVER_POS         (5,  "images", "Receiver 实际接收位置"),
        DRIVER_PER_IMAGE            (10, "images", "每个 Image 的统计（每个发布者实例一个）"),

        // ── Driver：通道状态（无 logbuffer）────────────────────────
        DRIVER_SYSTEM_COUNTER       (0,  null, "MediaDriver 系统计数器（错误数、连接数等）"),
        DRIVER_SEND_CHANNEL_STATUS  (6,  null, "发送通道端点状态（ACTIVE / ERRORED）"),
        DRIVER_RECEIVE_CHANNEL_STATUS(7, null, "接收通道端点状态（ACTIVE / ERRORED）"),
        DRIVER_HEARTBEAT            (12, null, "MediaDriver 心跳时间戳"),
        DRIVER_SENDER_BPE           (13, null, "Sender back-pressure 事件计数"),
        DRIVER_LOCAL_SOCKET_ADDRESS (14, null, "本地 Socket 绑定地址"),
        FLOW_CONTROL_RECEIVERS      (17, null, "流控接收者数量"),
        MDC_DESTINATIONS            (18, null, "MDC（多目标）目标数量"),
        NAME_RESOLVER_NEIGHBORS     (15, null, "名称解析邻居数量"),
        NAME_RESOLVER_CACHE         (16, null, "名称解析缓存条目数"),

        // ── Archive（无独立 logbuffer，录制 Publication 在 publications/ 下）
        ARCHIVE_RECORDING_POSITION  (100, "publications", "Archive 录制写入位置（recordingId 在 label 中）"),
        ARCHIVE_ERROR_COUNT         (101, null, "Archive 错误计数"),
        ARCHIVE_CONTROL_SESSIONS    (102, null, "Archive 控制会话数"),
        ARCHIVE_MAX_CYCLE_TIME      (103, null, "Archive 最大 duty-cycle 时间（ns）"),
        ARCHIVE_CYCLE_EXCEEDED      (104, null, "Archive duty-cycle 超阈值次数"),
        ARCHIVE_RECORDER_MAX_WRITE  (105, null, "Archive Recorder 最大单次写时间（ns）"),
        ARCHIVE_RECORDER_TOTAL_BYTES(106, null, "Archive Recorder 累计写入字节数"),
        ARCHIVE_RECORDER_TOTAL_TIME (107, null, "Archive Recorder 累计写入时间（ns）"),
        ARCHIVE_REPLAYER_MAX_READ   (108, null, "Archive Replayer 最大单次读时间（ns）"),
        ARCHIVE_REPLAYER_TOTAL_BYTES(109, null, "Archive Replayer 累计读取字节数"),
        ARCHIVE_REPLAYER_TOTAL_TIME (110, null, "Archive Replayer 累计读取时间（ns）"),
        ARCHIVE_RECORDING_SESSIONS  (111, null, "当前活跃录制会话数"),
        ARCHIVE_REPLAY_SESSIONS     (112, null, "当前活跃回放会话数"),

        // ── Cluster：ConsensusModule ─────────────────────────────────
        CLUSTER_CM_STATE            (200, null, "ConsensusModule 状态（0=INIT 1=ACTIVE 2=SUSPENDED 3=CLOSED）"),
        CLUSTER_NODE_ROLE           (201, null, "节点角色（0=Follower 1=Candidate 2=Leader 3=Replay）"),
        CLUSTER_CONTROL_TOGGLE      (202, null, "集群控制开关（快照/挂起/恢复等命令写入此 counter）"),
        CLUSTER_COMMIT_POSITION     (203, null, "已提交日志位置（所有节点已确认的 Raft log position）"),
        CLUSTER_RECOVERY_STATE      (204, null, "恢复状态（leadershipTermId / logPosition / timestamp）"),
        CLUSTER_SNAPSHOT_COUNTER    (205, null, "累计快照次数"),
        CLUSTER_CM_ERROR_COUNT      (212, null, "ConsensusModule 错误计数"),
        CLUSTER_CLIENT_TIMEOUT      (213, null, "客户端超时次数"),
        CLUSTER_INVALID_REQUEST     (214, null, "无效请求计数"),
        CLUSTER_MAX_CYCLE_TIME      (216, null, "ConsensusModule 最大 duty-cycle 时间（ns）"),
        CLUSTER_CYCLE_EXCEEDED      (217, null, "ConsensusModule duty-cycle 超阈值次数"),
        CLUSTER_ELECTION_STATE      (232, null, "选举状态（0=INIT 1=CANVASS 2=NOMINATION ... 8=CLOSED）"),
        CLUSTER_ELECTION_COUNT      (238, null, "累计选举次数"),
        CLUSTER_LEADERSHIP_TERM_ID  (239, null, "当前 leadershipTermId"),

        // ── Cluster：ClusteredService ────────────────────────────────
        CLUSTER_SERVICE_ERROR_COUNT (215, null, "ClusteredService 错误计数"),
        CLUSTER_SERVICE_MAX_CYCLE   (218, null, "ClusteredService 最大 duty-cycle 时间（ns）"),
        CLUSTER_SERVICE_CYCLE_EXCEEDED(219, null, "ClusteredService duty-cycle 超阈值次数"),
        CLUSTER_SNAPSHOT_MAX_DURATION(233, null, "最大快照耗时（ns）"),
        CLUSTER_SNAPSHOT_DURATION_EXCEEDED(234, null, "快照耗时超阈值次数"),
        SERVICE_SNAPSHOT_MAX_DURATION(235, null, "Service 最大快照耗时（ns）"),
        SERVICE_SNAPSHOT_DURATION_EXCEEDED(236, null, "Service 快照耗时超阈值次数"),

        UNKNOWN(-1, null, "未知类型");

        private final int    typeId;
        private final String subDir;
        private final String description;

        TypeInfo(final int typeId, final String subDir, final String description)
        {
            this.typeId      = typeId;
            this.subDir      = subDir;
            this.description = description;
        }

        static TypeInfo of(final int typeId)
        {
            for (final TypeInfo t : values())
            {
                if (t.typeId == typeId) return t;
            }
            return UNKNOWN;
        }

        static String logbufferSubDir(final int typeId)
        {
            return of(typeId).subDir;
        }

        String typeName()    { return this == UNKNOWN ? "UNKNOWN(" + typeId + ")" : name(); }
        String description() { return description; }
    }

    // ──────────────────────────────────────────────────────────────────
    // 响应模型
    // ──────────────────────────────────────────────────────────────────

    /**
     * /aeron-stat 响应：cnc.dat 完整内容。
     *
     * @param status   "ok" 或错误消息
     * @param metadata cnc.dat 元数据（驱动 PID、启动时间等）
     * @param errors   错误日志条目列表
     * @param counters 所有计数器条目列表
     */
    public record AeronStatResult(
        String status,
        CncMetadata metadata,
        List<CncError> errors,
        List<CounterEntry> counters) {}

    /**
     * cnc.dat 驱动元数据。
     *
     * @param cncVersion                  CNC 文件版本号
     * @param pid                         MediaDriver 进程 PID
     * @param startTimestamp              MediaDriver 启动时间
     * @param clientLivenessTimeoutNs     客户端存活超时（纳秒）
     * @param toDriverBufferLength        Driver 命令环形缓冲区长度（字节）
     * @param toClientsBufferLength       Driver→客户端广播缓冲区长度（字节）
     * @param countersMetaDataBufferLength Counter 元数据缓冲区长度（字节）
     * @param countersValuesBufferLength  Counter 值缓冲区长度（字节）
     * @param errorLogBufferLength        错误日志缓冲区长度（字节）
     */
    public record CncMetadata(
        int cncVersion,
        long pid,
        Instant startTimestamp,
        long clientLivenessTimeoutNs,
        int toDriverBufferLength,
        int toClientsBufferLength,
        int countersMetaDataBufferLength,
        int countersValuesBufferLength,
        int errorLogBufferLength) {}

    /**
     * cnc.dat 错误日志条目。
     *
     * @param observationCount  该错误累计出现次数
     * @param firstObservation  首次出现时间
     * @param lastObservation   末次出现时间
     * @param description       错误描述（异常类型 + 消息）
     */
    public record CncError(
        int observationCount,
        Instant firstObservation,
        Instant lastObservation,
        String description) {}

    /**
     * @param counterId   counter 槽位索引
     * @param typeId      类型整数值（对应 AeronCounters 常量）
     * @param typeName    类型名称（如 DRIVER_PUBLISHER_LIMIT）
     * @param description 类型中文说明
     * @param value       当前值（position 以字节计，状态以枚举序号计）
     * @param label       原始 label（含 channel / streamId / correlationId）
     * @param filePath    对应的 logbuffer 文件绝对路径，无文件时为 null
     * @param logBuffer   logbuffer 内容（仅当 includeLogBuffer=true 且有对应文件时非 null）
     */
    public record CounterEntry(
        int counterId,
        int typeId,
        String typeName,
        String description,
        long value,
        String label,
        String filePath,
        LogBufferReader.LogBufferResult logBuffer) {}

    /**
     * /loss-report 响应：loss-report.dat 完整内容。
     *
     * @param status  "ok" 或错误消息
     * @param entries 丢包统计条目列表
     */
    public record LossReportResult(
        String status,
        List<LossEntry> entries) {}

    /**
     * 单条丢包统计记录。
     *
     * @param observationCount       累计观测次数
     * @param totalBytesLost         累计丢失字节数
     * @param firstObservation       首次观测时间
     * @param lastObservation        末次观测时间
     * @param sessionId              丢包发生的 Session ID
     * @param streamId               丢包发生的 Stream ID
     * @param channel                通道 URI（如 aeron:udp?endpoint=...）
     * @param source                 数据来源地址
     */
    public record LossEntry(
        long observationCount,
        long totalBytesLost,
        Instant firstObservation,
        Instant lastObservation,
        int sessionId,
        int streamId,
        String channel,
        String source) {}

    /**
     * /recording-log 响应：aeron-cluster/recording.log 完整内容。
     *
     * @param status  "ok" 或错误消息
     * @param entries 任期/快照历史条目列表
     */
    public record RecordingLogResult(
        String status,
        List<RecordingEntry> entries) {}

    /**
     * recording.log 单条条目。
     *
     * @param entryIndex          条目索引（在文件中的位置）
     * @param entryType           条目类型：TERM / SNAPSHOT / STANDBY_SNAPSHOT
     * @param isValid             是否为有效条目（无效条目已被标记删除）
     * @param recordingId         对应的 Archive 录制 ID
     * @param leadershipTermId    所属 Raft 任期 ID
     * @param termBaseLogPosition 任期起始 log position
     * @param logPosition         条目的 log position（快照则是快照时的位置）
     * @param timestamp           条目时间戳，无有效时间时为 null
     * @param serviceId           所属 ClusteredService ID（快照条目有效）
     * @param archiveEndpoint     Archive 端点地址（可为 null）
     */
    public record RecordingEntry(
        int entryIndex,
        String entryType,
        boolean isValid,
        long recordingId,
        long leadershipTermId,
        long termBaseLogPosition,
        long logPosition,
        Instant timestamp,
        int serviceId,
        String archiveEndpoint) {}
}
