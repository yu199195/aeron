package io.aeron.spring.cluster.controller;

import io.aeron.spring.cluster.startup.ClusterNodeService;
import io.aeron.spring.cluster.snapshot.SnapshotService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST 接口：查询本节点状态。
 */
@RestController
@RequestMapping("/cluster/node")
public class ClusterNodeController
{
    private final ClusterNodeService nodeService;
    private final SnapshotService    snapshotService;

    public ClusterNodeController(
        final ClusterNodeService nodeService,
        final SnapshotService snapshotService)
    {
        this.nodeService    = nodeService;
        this.snapshotService = snapshotService;
    }

    /**
     * GET /cluster/node/status
     * <p>
     * 返回示例：
     * <pre>
     * {
     *   "nodeId": 0,
     *   "mediaDriverRunning": true,
     *   "serviceContainerRunning": true
     * }
     * </pre>
     */
    @GetMapping("/status")
    public ClusterNodeService.NodeStatus status()
    {
        return nodeService.status();
    }

    /**
     * POST /cluster/node/snapshot
     * <p>
     * 手动触发集群快照。通过 {@link io.aeron.cluster.ClusterTool} 向本地
     * ConsensusModule 写入快照信号，无需网络连接。
     * <p>
     * 返回示例：
     * <pre>
     * {"triggered": true}
     * {"triggered": false}   ← ConsensusModule 未就绪
     * </pre>
     */
    @PostMapping("/snapshot")
    public ResponseEntity<SnapshotResult> snapshot()
    {
        final boolean triggered = snapshotService.triggerSnapshot();
        return triggered
            ? ResponseEntity.ok(new SnapshotResult(true))
            : ResponseEntity.internalServerError().body(new SnapshotResult(false));
    }

    public record SnapshotResult(boolean triggered) {}
}
