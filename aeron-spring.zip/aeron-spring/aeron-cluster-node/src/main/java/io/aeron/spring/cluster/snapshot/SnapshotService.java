package io.aeron.spring.cluster.snapshot;

import io.aeron.cluster.ClusterTool;
import io.aeron.spring.cluster.config.ClusterProperties;

import java.io.File;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 快照执行服务。
 *
 * <h3>职责</h3>
 * 封装实际的快照触发逻辑，供 {@link SnapshotScheduler} 定时调用，
 * 以及 REST 接口手动调用。
 *
 * <h3>防重叠</h3>
 * 使用 {@code snapshotInProgress} 标志确保同一时刻只有一个快照在进行中。
 *
 * <h3>阻塞说明</h3>
 * {@link ClusterTool#snapshot} 内部会轮询等待 ConsensusModule 确认（最多 5 秒），
 * 属阻塞调用，<b>不能在 Aeron service 线程上直接调用</b>。
 * 调用方须确保在独立线程中执行。
 */
public class SnapshotService
{
    private final File clusterDir;

    /** 防止快照重叠：上一次未完成时忽略新请求 */
    private final AtomicBoolean snapshotInProgress = new AtomicBoolean(false);

    /**
     * 当前节点是否为 leader。
     * <p>
     * 由 {@code AbstractSnapshotClusteredService} 在 {@code onRoleChange} 中维护。
     * 快照请求只有在 leader 节点上才有意义：
     * {@link ClusterTool#snapshot} 向 ConsensusModule 写入快照信号，
     * ConsensusModule 仅在 leader 状态下处理该信号；
     * 在 follower 上调用会白白等待 5 秒超时后返回 false。
     */
    private final AtomicBoolean isLeader = new AtomicBoolean(false);

    public SnapshotService(final ClusterProperties props)
    {
        this.clusterDir = new File(props.aeronDir(), "aeron-cluster");
    }

    /**
     * 由集群服务线程（{@code onRoleChange}）调用，同步更新 leader 状态。
     *
     * @param leader {@code true} 表示本节点已成为 leader
     */
    public void setLeader(final boolean leader)
    {
        isLeader.set(leader);
        System.out.println("[Snapshot] 节点角色变更: isLeader=" + leader);
    }

    /**
     * 异步触发快照（供 service 线程、REST 接口调用）。
     * <p>
     * 非 leader 节点直接跳过：只有 leader 的 ConsensusModule 才会处理快照信号。
     * 若上次快照仍在进行中则忽略本次请求，避免重叠。
     *
     * @param reason 触发原因，仅用于日志
     */
    public void requestSnapshotAsync(final String reason)
    {
        if (!isLeader.get())
        {
            System.out.println("[Snapshot] 非 leader 节点，跳过快照请求（reason=" + reason + "）");
            return;
        }

        if (!snapshotInProgress.compareAndSet(false, true))
        {
            System.out.println("[Snapshot] 上次快照仍在进行，忽略本次请求（reason=" + reason + "）");
            return;
        }

        try
        {
            doSnapshot(reason);
        }
        finally
        {
            snapshotInProgress.set(false);
        }
    }

    /**
     * 同步触发快照（供 REST 接口调用，调用方可等待结果）。
     * <p>
     * 非 leader 节点直接返回 {@code false}，不会阻塞等待 ConsensusModule。
     * 若 ConsensusModule 未就绪，{@link ClusterTool#snapshot} 会在 5 秒超时后返回 {@code false}。
     *
     * @return {@code true} 表示信号已成功写入 ConsensusModule；
     *         {@code false} 表示当前非 leader 或 ConsensusModule 未就绪
     */
    public boolean triggerSnapshot()
    {
        if (!isLeader.get())
        {
            System.out.println("[Snapshot] 非 leader 节点，拒绝手动快照请求");
            return false;
        }
        return doSnapshot("REST 手动触发");
    }

    // ──────────────────────────────────────────────────────────────────
    // 内部实现
    // ──────────────────────────────────────────────────────────────────

    private boolean doSnapshot(final String reason)
    {
        System.out.println("[Snapshot] 触发快照: reason=" + reason + ", clusterDir=" + clusterDir);

        final boolean result = ClusterTool.snapshot(clusterDir, System.out);
        if (result)
        {
            System.out.println("[Snapshot] 快照完成: reason=" + reason);
        }
        else
        {
            System.err.println("[Snapshot] 快照失败（ConsensusModule 可能未就绪）: reason=" + reason);
        }
        return result;
    }
}
