package io.aeron.spring.cluster.startup;

import io.aeron.cluster.ClusteredMediaDriver;
import io.aeron.cluster.service.ClusteredService;
import io.aeron.cluster.service.ClusteredServiceContainer;
import io.aeron.spring.cluster.config.ClusterProperties;
import io.aeron.spring.cluster.util.ClusterDirs;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.agrona.concurrent.ShutdownSignalBarrier;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.List;

/**
 * Spring Service：封装集群节点启动逻辑。
 * <p>
 * 节点在后台线程运行，Spring 容器关闭时触发优雅关闭。
 * <p>
 * 使用的 {@link ClusteredService} 实现由 {@code aeron.cluster.service.type} 配置决定，
 * 通过 Spring 条件注入（见 ClusterBeanConfig）。
 */
@Service
public class ClusterNodeService
{
    private final ClusterProperties props;
    private final ClusteredService  clusteredService;

    private ClusteredMediaDriver      clusteredMediaDriver;
    private ClusteredServiceContainer serviceContainer;
    private final ShutdownSignalBarrier barrier = new ShutdownSignalBarrier();
    private volatile boolean running = false;

    /** 缓存 resolveNodeId() 结果，避免在 stop()/status() 中重复解析 hostname */
    private int resolvedNodeId = -1;

    public ClusterNodeService(
        final ClusterProperties props,
        final ClusteredService clusteredService)
    {
        this.props            = props;
        this.clusteredService = clusteredService;
    }

    @PostConstruct
    public void start()
    {
        final int nodeId = props.resolveNodeId();
        resolvedNodeId = nodeId;
        final List<String> hostnames = props.hostnameList();
        final int portBase = props.getPortBase();

        final String nodeDir        = props.aeronDir();
        final String mediaDriverDir = ClusterDirs.mediaDriverDir(nodeDir);
        final File   archiveDir     = ClusterDirs.archiveDir(nodeDir);
        final File   clusterDir     = ClusterDirs.clusterDir(nodeDir);

        printBanner(nodeId, hostnames.get(nodeId), portBase, nodeDir, mediaDriverDir, archiveDir, clusterDir);

        final ClusterConfig clusterConfig =
            ClusterConfig.create(nodeId, hostnames, portBase, props, barrier, clusteredService);

        System.out.println("[Node " + nodeId + "] 启动 ClusteredMediaDriver...");
        clusteredMediaDriver = ClusteredMediaDriver.launch(
            clusterConfig.mediaDriverContext(),
            clusterConfig.archiveContext(),
            clusterConfig.consensusModuleContext());

        System.out.println("[Node " + nodeId + "] 启动 ClusteredServiceContainer...");
        serviceContainer = ClusteredServiceContainer.launch(clusterConfig.clusteredServiceContext());

        running = true;
        System.out.println("[Node " + nodeId + "] 所有组件启动完成，等待请求...");
    }

    @PreDestroy
    public void stop()
    {
        System.out.println("[Node " + resolvedNodeId + "] Spring 容器关闭，优雅停止集群节点...");
        barrier.signal();
        if (serviceContainer != null)
        {
            serviceContainer.close();
        }
        if (clusteredMediaDriver != null)
        {
            clusteredMediaDriver.close();
        }
        running = false;
        System.out.println("[Node " + resolvedNodeId + "] 已关闭");
    }

    /** 供 REST 接口查询当前节点状态 */
    public NodeStatus status()
    {
        return new NodeStatus(
            resolvedNodeId,
            running && clusteredMediaDriver != null,
            running && serviceContainer != null);
    }

    public record NodeStatus(int nodeId, boolean mediaDriverRunning, boolean serviceContainerRunning) {}

    // ──────────────────────────────────────────────────────────────────
    // 私有：启动 Banner
    // ──────────────────────────────────────────────────────────────────

    private void printBanner(
        final int nodeId,
        final String host,
        final int portBase,
        final String nodeDir,
        final String mediaDriverDir,
        final File archiveDir,
        final File clusterDir)
    {
        System.out.println();
        System.out.println("╔══════════════════════════════════════════════════════════╗");
        System.out.printf( "║  Aeron Cluster Node %-3d  (Spring Boot)                   ║%n", nodeId);
        System.out.println("╠══════════════════════════════════════════════════════════╣");
        System.out.printf( "║  %-20s  %s%n", "节点根目录:", nodeDir);
        System.out.printf( "║  %-20s  %s%n", "MediaDriver 目录:", mediaDriverDir);
        System.out.printf( "║  %-20s  %s%n", "Archive 目录:", archiveDir);
        System.out.printf( "║  %-20s  %s%n", "Cluster 目录:", clusterDir);
        System.out.printf( "║  %-20s  %s%n", "Service 类型:", props.getService().getType());
        System.out.printf( "║  %-20s  %s%n", "线程模型:", props.getMediaDriver().getThreadingMode());
        System.out.println("╠══════════════════════════════════════════════════════════╣");
        System.out.printf( "║  %-20s  %s:%-5d  （客户端 Ingress，Sender 连接此端口）%n",
            "客户端入口端口:", host, ClusterConfig.calculatePort(nodeId, portBase, ClusterConfig.CLIENT_FACING_PORT_OFFSET));
        System.out.printf( "║  %-20s  %s:%-5d  （Raft 投票 / 心跳）%n",
            "成员共识端口:", host, ClusterConfig.calculatePort(nodeId, portBase, ClusterConfig.MEMBER_FACING_PORT_OFFSET));
        System.out.printf( "║  %-20s  %s:%-5d  （日志复制）%n",
            "日志复制端口:", host, ClusterConfig.calculatePort(nodeId, portBase, ClusterConfig.LOG_PORT_OFFSET));
        System.out.printf( "║  %-20s  %s:%-5d  （快照文件传输）%n",
            "文件传输端口:", host, ClusterConfig.calculatePort(nodeId, portBase, ClusterConfig.TRANSFER_PORT_OFFSET));
        System.out.printf( "║  %-20s  %s:%-5d  （Archive 控制，内部 IPC）%n",
                "Archive 控制端口:", host, ClusterConfig.calculatePort(nodeId, portBase, ClusterConfig.ARCHIVE_CONTROL_PORT_OFFSET));
        System.out.printf( "║  %-20s  %s:%-5d  （日志追赶数据流，Archive Replay 回传）%n",
            "日志追赶端口:", host, ClusterConfig.calculatePort(nodeId, portBase, ClusterConfig.REPLICATION_PORT_OFFSET));
        System.out.printf( "║  %-20s  %s:%-5d  （Archive 控制应答，Replay 控制响应）%n",
            "Archive 应答端口:", host, ClusterConfig.calculatePort(nodeId, portBase, ClusterConfig.ARCHIVE_RESPONSE_PORT_OFFSET));
        System.out.println("╠══════════════════════════════════════════════════════════╣");
        System.out.printf( "║  %-20s  %d ms%n",
            "Session 超时:", props.getConsensus().getSessionTimeoutNs() / 1_000_000);
        System.out.printf( "║  %-20s  %d ms%n",
            "心跳超时:", props.getConsensus().getLeaderHeartbeatTimeoutNs() / 1_000_000);
        System.out.printf( "║  %-20s  %d ms%n",
            "心跳间隔:", props.getConsensus().getLeaderHeartbeatIntervalNs() / 1_000_000);
        System.out.printf( "║  %-20s  %d ms%n",
            "选举超时:", props.getConsensus().getElectionTimeoutNs() / 1_000_000);
        System.out.println("╚══════════════════════════════════════════════════════════╝");
        System.out.println();
    }
}
