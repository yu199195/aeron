package io.aeron.spring.cluster.configuration;

import io.aeron.cluster.service.ClusteredService;
import io.aeron.spring.cluster.config.ClusterProperties;
import io.aeron.spring.cluster.service.ForwardingClusteredService;
import io.aeron.spring.cluster.service.PubSubClusteredService;
import io.aeron.spring.cluster.service.SimpleClusteredService;
import io.aeron.spring.cluster.snapshot.SnapshotScheduler;
import io.aeron.spring.cluster.snapshot.SnapshotService;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 集群相关 Bean 配置。
 *
 * <h3>ClusteredService 选择</h3>
 * 通过 {@code aeron.cluster.service.type} 控制使用哪种服务实现，三选一：
 * <ul>
 *   <li>{@code simple}（默认）：存储 Order/User 业务数据，支持完整快照</li>
 *   <li>{@code forwarding}：将消息转发到外部 Aeron 订阅者</li>
 *   <li>{@code pubsub}：基于订阅命令的消息广播</li>
 * </ul>
 */
@Configuration
public class ClusterBeanConfig
{
    @Bean
    public SnapshotService snapshotService(final ClusterProperties clusterProperties)
    {
        return new SnapshotService(clusterProperties);
    }

    @Bean
    @ConditionalOnProperty(prefix = ClusterProperties.PREFIX + ".snapshot.scheduler", name = "enabled", havingValue = "true")
    public SnapshotScheduler snapshotScheduler(
        final SnapshotService snapshotService,
        final ClusterProperties clusterProperties)
    {
        return new SnapshotScheduler(snapshotService, clusterProperties.getSnapshot());
    }

    // ──────────────────────────────────────────────
    // ClusteredService：三选一
    // ──────────────────────────────────────────────

    @Bean
    @ConditionalOnProperty(prefix = ClusterProperties.PREFIX + ".service", name = "type",
        havingValue = "simple", matchIfMissing = true)
    public ClusteredService simpleClusteredService(
        final SnapshotService snapshotService,
        final ClusterProperties clusterProperties)
    {
        return new SimpleClusteredService(snapshotService, clusterProperties.getSnapshot());
    }

    @Bean
    @ConditionalOnProperty(prefix = ClusterProperties.PREFIX + ".service", name = "type",
        havingValue = "forwarding")
    public ClusteredService forwardingClusteredService(
        final SnapshotService snapshotService,
        final ClusterProperties clusterProperties)
    {
        return new ForwardingClusteredService(snapshotService, clusterProperties.getSnapshot());
    }

    @Bean
    @ConditionalOnProperty(prefix = ClusterProperties.PREFIX + ".service", name = "type",
        havingValue = "pubsub")
    public ClusteredService pubSubClusteredService(
        final SnapshotService snapshotService,
        final ClusterProperties clusterProperties)
    {
        return new PubSubClusteredService(snapshotService, clusterProperties.getSnapshot());
    }
}
