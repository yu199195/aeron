package io.aeron.spring.cluster.startup;

import io.aeron.CncFileDescriptor;
import io.aeron.cluster.ElectionState;
import io.aeron.cluster.service.ClusterMarkFile;
import io.aeron.spring.cluster.config.ClusterProperties;
import io.aeron.spring.cluster.config.DiagnosticProperties;
import io.aeron.spring.cluster.util.ClusterDirs;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import lombok.extern.slf4j.Slf4j;
import org.agrona.IoUtil;
import org.agrona.concurrent.errors.ErrorLogReader;
import org.agrona.concurrent.status.CountersReader;
import org.springframework.stereotype.Component;

import java.io.File;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 集群选举诊断日志组件。
 *
 * <p>节点启动后通过定时线程池周期性打印集群核心状态快照，
 * 便于在无 REST 客户端的情况下直接从日志文件观察选举进度。
 *
 * <p>行为可通过 {@code aeron.cluster.diagnostic.*} 配置：
 * <ul>
 *   <li>{@code enabled}：是否开启（默认 true）</li>
 *   <li>{@code interval-ms}：轮询间隔毫秒数（默认 2000）</li>
 *   <li>{@code stable-threshold}：连续稳定 N 次后降频（默认 5）</li>
 *   <li>{@code quiet-interval-multiplier}：稳定后每 N 次轮询才输出一行（默认 5）</li>
 * </ul>
 *
 * <p>输出格式示例：
 * <pre>
 * [ClusterDiag] cmState=INIT      role=N/A       election=N/A                   term=N/A commit=N/A    elections=N/A errors=N/A
 * [ClusterDiag] cmState=ACTIVE    role=LEADER    election=CLOSED(17)            term=1   commit=1024   elections=1   errors=0
 * </pre>
 *
 * <p>typeId 常量来自 Aeron 1.50.x {@code io.aeron.AeronCounters}：
 * <ul>
 *   <li>200 – ConsensusModule State</li>
 *   <li>201 – Node Role</li>
 *   <li>232 – Election State</li>
 *   <li>238 – Election Count</li>
 *   <li>239 – Leadership Term ID</li>
 *   <li>203 – Commit Position</li>
 *   <li>212 – ConsensusModule Error Count</li>
 * </ul>
 */
@Component
@Slf4j
public class ClusterDiagnosticLogger
{
    private static final int TYPE_CM_STATE       = 200;
    private static final int TYPE_NODE_ROLE      = 201;
    private static final int TYPE_ELECTION_STATE = 232;
    private static final int TYPE_ELECTION_COUNT = 238;
    private static final int TYPE_TERM_ID        = 239;
    private static final int TYPE_COMMIT_POS     = 203;
    private static final int TYPE_CM_ERRORS      = 212;

    private final ClusterProperties      props;
    private final DiagnosticProperties   diagCfg;
    private final AtomicInteger          stableCount        = new AtomicInteger(0);
    private final AtomicInteger          loopCount          = new AtomicInteger(0);
    private final AtomicInteger          lastMarkErrorCount = new AtomicInteger(0);
    private       ScheduledExecutorService scheduler;

    public ClusterDiagnosticLogger(final ClusterProperties props)
    {
        this.props   = props;
        this.diagCfg = props.getDiagnostic();
    }

    @PostConstruct
    public void start()
    {
        if (!diagCfg.isEnabled())
        {
            log.info("[ClusterDiag] 诊断日志已禁用（aeron.cluster.diagnostic.enabled=false）");
            return;
        }

        scheduler = Executors.newSingleThreadScheduledExecutor(r ->
        {
            final Thread t = new Thread(r, "cluster-diag-logger");
            t.setDaemon(true);
            return t;
        });

        scheduler.scheduleWithFixedDelay(
            this::tick,
            0,
            diagCfg.getIntervalMs(),
            TimeUnit.MILLISECONDS);

        log.info("[ClusterDiag] 诊断日志已启动（interval={}ms, stableThreshold={}, quietMultiplier={}）",
            diagCfg.getIntervalMs(), diagCfg.getStableThreshold(), diagCfg.getQuietIntervalMultiplier());
    }

    @PreDestroy
    public void stop()
    {
        if (scheduler != null)
        {
            scheduler.shutdownNow();
        }
    }

    // ──────────────────────────────────────────────────────────────────
    // 定时任务
    // ──────────────────────────────────────────────────────────────────

    private void tick()
    {
        try
        {
            pollCncDat();
            lastMarkErrorCount.set(pollMarkFileErrors(lastMarkErrorCount.get()));
        }
        catch (final Exception e)
        {
            log.warn("[ClusterDiag] 诊断轮询异常: {}", e.getMessage(), e);
        }
    }

    // ──────────────────────────────────────────────────────────────────
    // cnc.dat
    // ──────────────────────────────────────────────────────────────────

    private void pollCncDat()
    {
        final File cncFile = new File(
            ClusterDirs.mediaDriverDir(props.aeronDir()),
            CncFileDescriptor.CNC_FILE);

        if (!cncFile.exists())
        {
            log.info("[ClusterDiag] cnc.dat 尚未就绪: {}", cncFile);
            return;
        }

        try (FileChannel ch = FileChannel.open(cncFile.toPath(), StandardOpenOption.READ))
        {
            final MappedByteBuffer buf  = ch.map(FileChannel.MapMode.READ_ONLY, 0, ch.size());
            final var              meta = CncFileDescriptor.createMetaDataBuffer(buf);
            CncFileDescriptor.checkVersion(meta.getInt(CncFileDescriptor.cncVersionOffset(0)));

            final CountersReader cr = new CountersReader(
                CncFileDescriptor.createCountersMetaDataBuffer(buf, meta),
                CncFileDescriptor.createCountersValuesBuffer(buf, meta));

            final long cmStateVal    = readCounter(cr, TYPE_CM_STATE);
            final long roleVal       = readCounter(cr, TYPE_NODE_ROLE);
            final long electionVal   = readCounter(cr, TYPE_ELECTION_STATE);
            final long electionCount = readCounter(cr, TYPE_ELECTION_COUNT);
            final long termId        = readCounter(cr, TYPE_TERM_ID);
            final long commitPos     = readCounter(cr, TYPE_COMMIT_POS);
            final long cmErrors      = readCounter(cr, TYPE_CM_ERRORS);

            final String cmStateStr  = cmStateVal  < 0 ? "N/A" : cmStateName((int) cmStateVal);
            final String roleStr     = roleVal     < 0 ? "N/A" : roleName((int) roleVal);
            final String electionStr = electionVal < 0 ? "N/A"
                : ElectionState.get(electionVal).name() + "(" + electionVal + ")";

            final boolean isStable = "ACTIVE".equals(cmStateStr)
                && electionVal >= 0
                && ElectionState.get(electionVal) == ElectionState.CLOSED;

            final int sc = isStable ? stableCount.incrementAndGet() : stableCount.getAndSet(0);
            final int lc = loopCount.incrementAndGet();

            // 未稳定：每次都输出；已稳定：每 quietIntervalMultiplier 次输出一次
            final boolean shouldPrint = !isStable
                || sc <= diagCfg.getStableThreshold()
                || (lc % diagCfg.getQuietIntervalMultiplier() == 0);

            if (shouldPrint)
            {
                log.info("[ClusterDiag] cmState={} role={} election={} term={} commit={} elections={} errors={}",
                    String.format("%-9s", cmStateStr),
                    String.format("%-9s", roleStr),
                    String.format("%-25s", electionStr),
                    termId        < 0 ? "N/A" : termId,
                    commitPos     < 0 ? "N/A" : commitPos,
                    electionCount < 0 ? "N/A" : electionCount,
                    cmErrors      < 0 ? "N/A" : cmErrors);
            }

            IoUtil.unmap(buf);
        }
        catch (final Exception e)
        {
            log.warn("[ClusterDiag] 读取 cnc.dat 失败: {}", e.getMessage(), e);
        }
    }

    // ──────────────────────────────────────────────────────────────────
    // cluster-mark.dat
    // ──────────────────────────────────────────────────────────────────

    /**
     * 读取 cluster-mark.dat 的 errorBuffer，将上次检查后新增的条目用 log.warn 输出完整堆栈。
     *
     * <p>{@code ErrorLogReader} 每次读出 <em>全量</em> 已记录条目（按写入顺序排列），
     * 通过与 {@code prevCount} 比较，只输出新增部分，避免重复打印。
     *
     * @param prevCount 上次已打印的错误条数
     * @return 本次读取后的错误总条数（作为下一轮的 prevCount）
     */
    private int pollMarkFileErrors(final int prevCount)
    {
        final File clusterDir = ClusterDirs.clusterDir(props.aeronDir());
        final File markFile   = new File(clusterDir, ClusterMarkFile.FILENAME);

        if (!markFile.exists())
        {
            return prevCount;
        }

        final List<MarkError> allErrors = new ArrayList<>();

        try (ClusterMarkFile cmf = new ClusterMarkFile(
            clusterDir, ClusterMarkFile.FILENAME, System::currentTimeMillis, 5_000, msg -> {}))
        {
            ErrorLogReader.read(cmf.errorBuffer(), (count, firstTimestamp, lastTimestamp, ex) ->
                allErrors.add(new MarkError(count,
                    Instant.ofEpochMilli(firstTimestamp),
                    Instant.ofEpochMilli(lastTimestamp),
                    ex.strip())));
        }
        catch (final Exception e)
        {
            log.warn("[ClusterDiag] 读取 cluster-mark.dat 失败: {}", e.getMessage(), e);
            return prevCount;
        }

        // 仅打印上次之后新增的条目，完整堆栈放在 message 参数里直接输出
        for (int i = prevCount; i < allErrors.size(); i++)
        {
            final MarkError err = allErrors.get(i);
            log.warn("[ClusterDiag][MARK-ERROR] 出现 {}x  首次={}  末次={}\n{}",
                err.count(), err.firstTimestamp(), err.lastTimestamp(), err.stackTrace());
        }

        return allErrors.size();
    }

    private record MarkError(int count, Instant firstTimestamp, Instant lastTimestamp, String stackTrace) {}

    // ──────────────────────────────────────────────────────────────────
    // 工具方法
    // ──────────────────────────────────────────────────────────────────

    private static long readCounter(final CountersReader cr, final int typeId)
    {
        final long[] result = {-1L};
        cr.forEach((counterId, tid, keyBuffer, label) ->
        {
            if (tid == typeId && result[0] == -1L)
            {
                result[0] = cr.getCounterValue(counterId);
            }
        });
        return result[0];
    }

    private static String cmStateName(final int v)
    {
        return switch (v)
        {
            case 0 -> "INIT";
            case 1 -> "ACTIVE";
            case 2 -> "SUSPENDED";
            case 3 -> "CLOSED";
            default -> "UNKNOWN(" + v + ")";
        };
    }

    private static String roleName(final int v)
    {
        return switch (v)
        {
            case 0 -> "FOLLOWER";
            case 1 -> "CANDIDATE";
            case 2 -> "LEADER";
            case 3 -> "REPLAY";
            default -> "UNKNOWN(" + v + ")";
        };
    }
}
