package io.aeron.spring.cluster.config;

import io.aeron.spring.cluster.config.AeronContextProperties;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;

import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

import static io.aeron.spring.cluster.config.ClusterProperties.PREFIX;

/**
 * Aeron Cluster 配置属性，绑定 application.yml 中的 aeron.cluster.* 前缀。
 *
 * <h3>K8s StatefulSet 部署（推荐）</h3>
 * 无需手动指定 {@code node-id}。只需配置所有节点的 hostname 列表和数据目录基础路径：
 * <pre>
 * aeron:
 *   cluster:
 *     hostnames: node-0,node-1,node-2          # StatefulSet Pod name
 *     port-base: 9000
 *     aeron-dir-base: /data/aeron              # PVC 挂载根目录
 * </pre>
 * 运行时目录结构（所有节点挂载同一个 PVC，按 Pod hostname 自动建子目录）：
 * <pre>
 * /data/aeron/
 *   node-0/    ← Pod node-0 的数据
 *   node-1/    ← Pod node-1 的数据
 *   node-2/    ← Pod node-2 的数据
 * </pre>
 * K8s StatefulSet 为每个 Pod 分配固定 hostname（pod-name 部分），
 * {@link #resolveNodeId()} 自动匹配列表 index，{@link #aeronDir()} 自动追加 hostname 为子目录。
 *
 * <h3>本地多进程部署</h3>
 * hostname 相同（均为 localhost），需手动指定 {@code node-id}：
 * <pre>
 * java -jar cluster-node.jar --aeron.cluster.node-id=0 --server.port=8080
 * </pre>
 * 本地目录结构（{workDir}/node0、node1、node2）由 {@link #aeronDir()} 自动生成。
 */
@ConfigurationProperties(prefix = PREFIX)
@Data
public class ClusterProperties {

    public static final String PREFIX = "aeron.cluster";

    /**
     * 当前节点 ID（0-based）。
     * <ul>
     *   <li>-1（默认）：自动从 hostname 列表推断，适用于 K8s StatefulSet</li>
     *   <li>>=0：显式指定，适用于本地多进程部署</li>
     * </ul>
     */
    private int nodeId = -1;

    /** 集群主机列表（逗号分隔，顺序即 nodeId 顺序） */
    private String hostnames = "localhost,localhost,localhost";

    /** 端口基础值 */
    private int portBase = 9000;

    /**
     * 节点数据目录基础路径（不含节点子目录）。
     * <ul>
     *   <li>K8s 部署：配置为 PVC 挂载点，如 {@code /data/aeron}。
     *       {@link #aeronDir()} 会自动追加本机 hostname 作为子目录
     *       （如 {@code /data/aeron/node-0}），所有 Pod 可挂载同一个 PVC。</li>
     *   <li>本地部署：不配置（{@code null}），{@link #aeronDir()} 使用
     *       {@code {workDir}/node{nodeId}} 自动区分。</li>
     * </ul>
     */
    private String aeronDirBase = null;

    /** 启动时是否删除 Archive 旧数据 */
    private boolean deleteArchiveOnStart = false;

    /** 启动时是否删除 ConsensusModule 旧数据 */
    private boolean deleteConsensusOnStart = false;

    @NestedConfigurationProperty
    private SnapshotProperties snapshot = new SnapshotProperties();

    @NestedConfigurationProperty
    private ServiceProperties service = new ServiceProperties();

    /** MediaDriver 调优参数，对应 {@code aeron.cluster.media-driver.*} */
    @NestedConfigurationProperty
    private MediaDriverProperties mediaDriver = new MediaDriverProperties();

    /** Archive 调优参数，对应 {@code aeron.cluster.archive.*} */
    @NestedConfigurationProperty
    private ArchiveProperties archive = new ArchiveProperties();

    /** ConsensusModule 调优参数，对应 {@code aeron.cluster.consensus.*} */
    @NestedConfigurationProperty
    private ConsensusProperties consensus = new ConsensusProperties();

    /** Aeron 客户端配置，对应 {@code aeron.cluster.aeron.*} */
    @NestedConfigurationProperty
    private AeronContextProperties aeron = new AeronContextProperties();

    /** 集群诊断日志配置，对应 {@code aeron.cluster.diagnostic.*} */
    @NestedConfigurationProperty
    private DiagnosticProperties diagnostic = new DiagnosticProperties();

    // ──────────────────────────────────────────────────────────────────
    // 运行时缓存（非配置字段，不由 Spring 绑定）
    // ──────────────────────────────────────────────────────────────────

    /**
     * 缓存本机短 hostname（pod name，不含域名部分）。
     * <p>
     * 优先读 {@code /etc/hostname}（K8s 始终写入 pod name，如 {@code node-0}），
     * 避免 {@link InetAddress#getLocalHost()} 经 DNS 反查返回完整 FQDN
     * （{@code node-0.cluster-svc.default.svc.cluster.local}）导致目录名畸长。
     */
    private transient String cachedLocalHostname = null;

    // ──────────────────────────────────────────────────────────────────
    // 公共方法
    // ──────────────────────────────────────────────────────────────────

    /** 将逗号分隔的 hostnames 字符串转为 List */
    public List<String> hostnameList()
    {
        return Arrays.asList(hostnames.split(","));
    }

    /**
     * 获取本节点实际 nodeId。
     *
     * <h4>解析优先级</h4>
     * <ol>
     *   <li>{@code aeron.cluster.node-id >= 0}：显式配置，直接使用（最高优先级）。</li>
     *   <li>{@code HOSTNAME} 环境变量：在配置的 hostname 列表中查找匹配的 index。
     *       K8s Pod 里由容器运行时自动设置为 pod name；
     *       本地开发时在 IDE run configuration 里为每个进程单独设置（如 {@code HOSTNAME=node-0}）。</li>
     *   <li>系统 hostname：读 {@code /etc/hostname} 或 {@link InetAddress#getLocalHost()}，
     *       作为最终兜底。</li>
     * </ol>
     *
     * <h4>匹配规则</h4>
     * <ul>
     *   <li>精确匹配：{@code candidate.equals(configured)}，如 {@code node-0}</li>
     *   <li>前缀匹配：{@code candidate.startsWith(configured + ".")}，
     *       适用于 K8s FQDN（{@code node-0.svc.ns.svc.cluster.local}）
     *       而配置项只写短名（{@code node-0}）的场景</li>
     * </ul>
     *
     * @throws IllegalStateException 找不到匹配的 hostname 时抛出
     */
    public int resolveNodeId()
    {
        if (nodeId >= 0)
        {
            return nodeId;
        }

        final List<String> list = hostnameList();

        // 1. 优先用 HOSTNAME 环境变量匹配（K8s 自动注入，本地 IDE 手动设置）
        final String envHostname = System.getenv("HOSTNAME");
        if (envHostname != null && !envHostname.isBlank())
        {
            final int idx = findIndex(envHostname.strip(), list);
            if (idx >= 0)
            {
                System.out.println("[ClusterProperties] 自动推断 nodeId=" + idx
                    + "（HOSTNAME=" + envHostname.strip() + "）");
                return idx;
            }
        }

        // 2. 兜底：系统 hostname（/etc/hostname 或 InetAddress）
        final String local = localHostname();
        final int idx = findIndex(local, list);
        if (idx >= 0)
        {
            System.out.println("[ClusterProperties] 自动推断 nodeId=" + idx
                + "（localHostname=" + local + "）");
            return idx;
        }

        throw new IllegalStateException(
            "无法推断 nodeId。尝试过：HOSTNAME=" + envHostname + ", localHostname=" + local
                + ", hostnames=" + hostnames
                + "。请在 IDE run configuration 中设置环境变量 HOSTNAME=<节点名>，"
                + "或通过 --aeron.cluster.node-id=<n> 显式指定");
    }

    /**
     * 获取本节点数据根目录。
     *
     * <h4>K8s 部署（配置了 {@code aeron-dir-base}）</h4>
     * 返回 {@code aeronDirBase/localHostname}，例如：
     * <pre>
     * aeronDirBase=/data/aeron, Pod hostname=node-1 → /data/aeron/node-1
     * </pre>
     * 所有 Pod 可挂载同一个 PVC，各自使用 hostname 命名的子目录，数据互不干扰。
     *
     * <h4>本地部署（未配置 {@code aeron-dir-base}）</h4>
     * 返回 {@code {workDir}/node{nodeId}}，例如 {@code ./node0}、{@code ./node1}。
     */
    public String aeronDir()
    {
        if (aeronDirBase != null && !aeronDirBase.isBlank())
        {
            // 用节点名作为子目录，优先取 HOSTNAME 环境变量（短名），兜底取系统 hostname
            final String envHostname = System.getenv("HOSTNAME");
            final String dirName = (envHostname != null && !envHostname.isBlank())
                ? envHostname.strip()
                : localHostname();
            return aeronDirBase.stripTrailing() + "/" + dirName;
        }
        // 本地：用 nodeId 数字后缀区分多进程目录
        return System.getProperty("user.dir") + "/node" + resolveNodeId();
    }
    
    /** 在列表中查找与 candidate 匹配（精确或前缀）的 index，未找到返回 -1 */
    private static int findIndex(final String candidate, final List<String> list)
    {
        for (int i = 0; i < list.size(); i++)
        {
            final String configured = list.get(i).trim();
            if (candidate.equals(configured) || candidate.startsWith(configured + "."))
            {
                return i;
            }
        }
        return -1;
    }

    /**
     * 获取本机短 hostname（pod name，不含域名部分）。
     *
     * <h4>读取优先级</h4>
     * <ol>
     *   <li>{@code /etc/hostname}（Linux/K8s）：K8s 始终将 pod name 写入此文件，
     *       内容就是 {@code node-0}，不含 FQDN，最可靠。</li>
     *   <li>{@code InetAddress.getLocalHost().getHostName()}：跨平台兜底，
     *       可能返回完整 FQDN，因此取第一个 {@code .} 之前的短名部分。</li>
     * </ol>
     */
    private String localHostname()
    {
        if (cachedLocalHostname == null)
        {
            cachedLocalHostname = resolveLocalHostname();
        }
        return cachedLocalHostname;
    }

    private static String resolveLocalHostname()
    {
        // 1. 优先读 /etc/hostname（K8s 写入的就是 pod name，不含域名）
        try
        {
            final String fromFile = Files.readString(Path.of("/etc/hostname")).strip();
            if (!fromFile.isEmpty())
            {
                return fromFile;
            }
        }
        catch (final Exception ignored)
        {
            // 非 Linux 环境（如本地 macOS 开发）正常不存在，跳过
        }

        // 2. 兜底：InetAddress，取第一段（防止返回 FQDN）
        try
        {
            final String full = InetAddress.getLocalHost().getHostName();
            final int dotIdx = full.indexOf('.');
            return dotIdx > 0 ? full.substring(0, dotIdx) : full;
        }
        catch (final Exception e)
        {
            throw new IllegalStateException("无法获取本机 hostname，请手动指定 aeron.cluster.node-id", e);
        }
    }
}
