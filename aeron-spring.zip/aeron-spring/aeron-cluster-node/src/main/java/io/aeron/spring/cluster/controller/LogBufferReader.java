package io.aeron.spring.cluster.controller;

import io.aeron.logbuffer.FrameDescriptor;
import io.aeron.logbuffer.LogBufferDescriptor;
import io.aeron.protocol.DataHeaderFlyweight;
import io.aeron.protocol.HeaderFlyweight;
import org.agrona.BitUtil;
import org.agrona.concurrent.UnsafeBuffer;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;

/**
 * 解析 Aeron logbuffer 文件，提取 Meta Data 和帧列表。
 *
 * <p>被 {@link LogBufferController} 和 {@link AeronClusterStatController} 共用。
 */
public final class LogBufferReader
{
    private static final int HEADER_LENGTH  = DataHeaderFlyweight.HEADER_LENGTH; // 32
    private static final int FRAME_ALIGNMENT = FrameDescriptor.FRAME_ALIGNMENT;  // 32
    private static final int MAX_HEX_BYTES  = 64;

    private LogBufferReader() {}

    /**
     * 读取并解析一个 logbuffer 文件。
     *
     * @param filePath  文件绝对路径
     * @param maxFrames 最多返回多少帧
     * @return 解析结果；文件不存在或读取失败时 {@code error} 字段不为 null
     */
    public static LogBufferResult read(final String filePath, final int maxFrames)
    {
        final File file = new File(filePath);
        if (!file.exists())
        {
            return LogBufferResult.error("文件不存在: " + filePath);
        }

        try (RandomAccessFile raf = new RandomAccessFile(file, "r");
             FileChannel channel = raf.getChannel())
        {
            final MappedByteBuffer mapped =
                channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size());
            mapped.order(ByteOrder.LITTLE_ENDIAN);

            // ── 1. 解析 Meta Data（位于文件末尾） ──────────────────
            final long fileSize   = channel.size();
            final long metaOffset = fileSize - LogBufferDescriptor.LOG_META_DATA_LENGTH;
            final UnsafeBuffer metaBuf = new UnsafeBuffer(mapped, (int) metaOffset,
                LogBufferDescriptor.LOG_META_DATA_LENGTH);

            final int  termLength      = LogBufferDescriptor.termLength(metaBuf);
            final int  initialTermId   = LogBufferDescriptor.initialTermId(metaBuf);
            final int  mtu             = LogBufferDescriptor.mtuLength(metaBuf);
            final long corrId          = LogBufferDescriptor.correlationId(metaBuf);
            final int  activeTermCount = LogBufferDescriptor.activeTermCount(metaBuf);

            final int activeIndex  = LogBufferDescriptor.indexByTermCount(activeTermCount);
            final int activeTermId = initialTermId + activeTermCount;

            final long rawTail    = LogBufferDescriptor.rawTailVolatile(metaBuf, activeIndex);
            final int  tailTermId = LogBufferDescriptor.termId(rawTail);
            final int  tailOffset = LogBufferDescriptor.termOffset(rawTail, termLength);

            final LogMeta meta = new LogMeta(
                filePath, fileSize, termLength, initialTermId, mtu,
                corrId, activeTermCount, activeIndex, activeTermId,
                tailTermId, tailOffset);

            // ── 2. 扫描 active term 中的帧 ─────────────────────────
            final long   termStart = (long) activeIndex * termLength;
            final UnsafeBuffer termBuf =
                new UnsafeBuffer(mapped, (int) termStart, termLength);

            final List<FrameEntry> frames = new ArrayList<>();
            int offset = 0;

            while (offset < tailOffset && frames.size() < maxFrames)
            {
                final int frameLength = FrameDescriptor.frameLengthVolatile(termBuf, offset);
                if (frameLength <= 0)
                {
                    break;
                }

                final int alignedLength = BitUtil.align(frameLength, FRAME_ALIGNMENT);
                final int frameType     = termBuf.getShort(
                    offset + HeaderFlyweight.TYPE_FIELD_OFFSET, ByteOrder.LITTLE_ENDIAN) & 0xFFFF;
                final byte flags        = termBuf.getByte(offset + FrameDescriptor.FLAGS_OFFSET);

                int    sessionId   = 0;
                int    streamId    = 0;
                int    termId      = 0;
                int    termOff     = 0;
                String payloadHex  = null;
                String payloadText = null;

                if (frameType == HeaderFlyweight.HDR_TYPE_DATA
                    || frameType == HeaderFlyweight.HDR_TYPE_PAD)
                {
                    sessionId = DataHeaderFlyweight.sessionId(termBuf, offset);
                    streamId  = DataHeaderFlyweight.streamId(termBuf, offset);
                    termId    = DataHeaderFlyweight.termId(termBuf, offset);
                    termOff   = DataHeaderFlyweight.termOffset(termBuf, offset);

                    final int payloadLength = frameLength - HEADER_LENGTH;
                    if (payloadLength > 0 && frameType == HeaderFlyweight.HDR_TYPE_DATA)
                    {
                        final int hexLen = Math.min(payloadLength, MAX_HEX_BYTES);
                        final byte[] payloadBytes = new byte[hexLen];
                        termBuf.getBytes(offset + HEADER_LENGTH, payloadBytes);
                        payloadHex  = HexFormat.ofDelimiter(" ").formatHex(payloadBytes)
                            + (payloadLength > MAX_HEX_BYTES ? " ..." : "");
                        payloadText = tryDecodeUtf8(termBuf, offset + HEADER_LENGTH, payloadLength);
                    }
                }

                frames.add(new FrameEntry(
                    offset, frameLength, alignedLength,
                    frameTypeName(frameType), frameType,
                    flagsDescription(flags), sessionId, streamId, termId, termOff,
                    payloadHex, payloadText));

                offset += alignedLength;
            }

            return new LogBufferResult(null, meta, frames);
        }
        catch (final IOException e)
        {
            return LogBufferResult.error("读取失败: " + e.getMessage());
        }
    }

    // ──────────────────────────────────────────────────────────────────
    // 私有工具方法
    // ──────────────────────────────────────────────────────────────────

    private static String tryDecodeUtf8(
        final UnsafeBuffer buf, final int offset, final int length)
    {
        final int previewLen = Math.min(length, 128);
        final byte[] bytes   = new byte[previewLen];
        buf.getBytes(offset, bytes);

        int nonPrintable = 0;
        for (final byte b : bytes)
        {
            if (b < 0x20 && b != '\n' && b != '\r' && b != '\t') nonPrintable++;
        }
        if (nonPrintable * 100 / previewLen > 30) return null;

        return new String(bytes, StandardCharsets.UTF_8)
            + (length > previewLen ? "..." : "");
    }

    private static String frameTypeName(final int type)
    {
        return switch (type)
        {
            case HeaderFlyweight.HDR_TYPE_PAD   -> "PAD";
            case HeaderFlyweight.HDR_TYPE_DATA  -> "DATA";
            case HeaderFlyweight.HDR_TYPE_NAK   -> "NAK";
            case HeaderFlyweight.HDR_TYPE_SM    -> "SM(StatusMessage)";
            case HeaderFlyweight.HDR_TYPE_ERR   -> "ERR";
            case HeaderFlyweight.HDR_TYPE_SETUP -> "SETUP";
            case HeaderFlyweight.HDR_TYPE_RTTM  -> "RTTM";
            default -> "UNKNOWN(" + type + ")";
        };
    }

    private static String flagsDescription(final byte flags)
    {
        final StringBuilder sb = new StringBuilder();
        if ((flags & DataHeaderFlyweight.BEGIN_FLAG) != 0) sb.append("BEGIN ");
        if ((flags & DataHeaderFlyweight.END_FLAG)   != 0) sb.append("END ");
        if ((flags & DataHeaderFlyweight.EOS_FLAG)   != 0) sb.append("EOS ");
        return sb.isEmpty() ? "-" : sb.toString().trim();
    }

    // ──────────────────────────────────────────────────────────────────
    // 公共响应模型
    // ──────────────────────────────────────────────────────────────────

    public record LogBufferResult(String error, LogMeta meta, List<FrameEntry> frames)
    {
        static LogBufferResult error(final String msg)
        {
            return new LogBufferResult(msg, null, List.of());
        }
    }

    /**
     * logbuffer 文件的 meta data 段内容。
     */
    public record LogMeta(
        String filePath,
        long   fileSize,
        int    termLength,
        int    initialTermId,
        int    mtu,
        long   correlationId,
        int    activeTermCount,
        int    activeTermIndex,
        int    activeTermId,
        int    tailTermId,
        int    tailOffset) {}

    /**
     * 一条帧的解析结果。
     */
    public record FrameEntry(
        int    termOffset,
        int    frameLength,
        int    alignedLength,
        String frameType,
        int    frameTypeId,
        String flags,
        int    sessionId,
        int    streamId,
        int    termId,
        int    termOff,
        String payloadHex,
        String payloadText) {}
}
