/*
 * Copyright 2014-2025 Real Logic Limited.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.aeron.spring.cluster.service;

import io.aeron.Aeron;
import io.aeron.ExclusivePublication;
import io.aeron.Image;
import io.aeron.Publication;
import io.aeron.cluster.codecs.CloseReason;
import io.aeron.cluster.service.ClientSession;
import io.aeron.cluster.service.Cluster;
import io.aeron.logbuffer.Header;
import io.aeron.spring.cluster.config.SnapshotProperties;
import io.aeron.spring.cluster.sbe.MessageHeaderDecoder;
import io.aeron.spring.cluster.sbe.OrderDecoder;
import io.aeron.spring.cluster.sbe.UserDecoder;
import io.aeron.spring.cluster.snapshot.SnapshotService;
import org.agrona.CloseHelper;
import org.agrona.DirectBuffer;

import java.nio.charset.StandardCharsets;

/**
 * 转发集群服务：使用 SBE 解码消息并转发到外部订阅者。
 * <p>
 * <b>转发规则</b>：
 * <ul>
 *   <li>Order 消息（templateId=1） → streamId 100</li>
 *   <li>User  消息（templateId=2） → streamId 200</li>
 *   <li>纯文本消息 → 不转发，仅 Echo 回复</li>
 * </ul>
 * <p>
 * 快照：序列化 globalCount + sessionCounts（由基类处理），无额外业务状态。
 */
public class ForwardingClusteredService extends AbstractSnapshotClusteredService
{
    private static final String FORWARD_CHANNEL = "aeron:udp?endpoint=localhost:9010";
    private static final int ORDER_STREAM_ID = 100;
    private static final int USER_STREAM_ID  = 200;

    private Aeron aeron;
    private Publication orderPublication;
    private Publication userPublication;

    // SBE 解码器 flyweight
    private final MessageHeaderDecoder headerDecoder = new MessageHeaderDecoder();
    private final OrderDecoder orderDecoder = new OrderDecoder();
    private final UserDecoder userDecoder = new UserDecoder();

    public ForwardingClusteredService(
        final SnapshotService snapshotService,
        final SnapshotProperties snapshotProps)
    {
        super(snapshotService, snapshotProps);
    }

    @Override
    public void onStart(final Cluster cluster, final Image snapshotImage)
    {
        this.cluster = cluster;
        this.aeron = cluster.aeron();

        System.out.println("  [ForwardingService] 创建转发 Publications...");
        System.out.println("    Order → " + FORWARD_CHANNEL + " (streamId: " + ORDER_STREAM_ID + ")");
        System.out.println("    User  → " + FORWARD_CHANNEL + " (streamId: " + USER_STREAM_ID + ")");

        orderPublication = aeron.addPublication(FORWARD_CHANNEL, ORDER_STREAM_ID);
        userPublication  = aeron.addPublication(FORWARD_CHANNEL, USER_STREAM_ID);

        if (snapshotImage != null)
        {
            readBaseSnapshot(snapshotImage);
            System.out.println("  [ForwardingService] 从快照恢复完成: globalCount=" + globalMessageCount);
        }

        System.out.println("  [ForwardingService] 已启动");
    }

    @Override
    public void onSessionOpen(final ClientSession session, final long timestamp)
    {
        System.out.println("  [ForwardingService] 会话打开: sessionId=" + session.id());
        sessionMessageCounts.put(session.id(), 0L);
        sendText(session, "Welcome! sessionId=" + session.id());
    }

    @Override
    public void onSessionClose(final ClientSession session, final long timestamp, final CloseReason closeReason)
    {
        System.out.println("  [ForwardingService] 会话关闭: sessionId=" + session.id() + ", reason=" + closeReason);
        sessionMessageCounts.remove(session.id());
    }

    @Override
    public void onSessionMessage(
        final ClientSession session,
        final long timestamp,
        final DirectBuffer buffer,
        final int offset,
        final int length,
        final Header header)
    {
        globalMessageCount++;
        final long sessionCount = sessionMessageCounts.get(session.id()) + 1;
        sessionMessageCounts.put(session.id(), sessionCount);

        checkLogGrowthSnapshot();

        if (length >= MessageHeaderDecoder.ENCODED_LENGTH)
        {
            headerDecoder.wrap(buffer, offset);
            final int templateId = headerDecoder.templateId();

            if (templateId == OrderDecoder.TEMPLATE_ID)
            {
                handleOrder(session, buffer, offset, length, sessionCount);
                return;
            }
            else if (templateId == UserDecoder.TEMPLATE_ID)
            {
                handleUser(session, buffer, offset, length, sessionCount);
                return;
            }
        }

        final byte[] bytes = new byte[length];
        buffer.getBytes(offset, bytes);
        final String msg = new String(bytes, StandardCharsets.UTF_8);
        System.out.println("  [ForwardingService] 文本消息 #" + globalMessageCount + ": " + msg);
        sendText(session, "[Echo #" + globalMessageCount + "] " + msg);
    }

    @Override
    public void onTimerEvent(final long correlationId, final long timestamp) {}

    @Override
    public void onTakeSnapshot(final ExclusivePublication snapshotPublication)
    {
        System.out.println("  [ForwardingService] 保存快照: globalCount=" + globalMessageCount);
        writeBaseSnapshot(snapshotPublication);
    }

    @Override
    public void onRoleChange(final Cluster.Role newRole)
    {
        super.onRoleChange(newRole);
        System.out.println("  [ForwardingService] 角色变更: " + newRole);
    }

    @Override
    public void onTerminate(final Cluster cluster)
    {
        System.out.println("  [ForwardingService] 正在关闭...");
        CloseHelper.closeAll(orderPublication, userPublication);
    }

    @Override
    protected void onLeadershipTerm(final long leadershipTermId, final int leaderMemberId)
    {
        System.out.println("  [ForwardingService] 新领导任期: termId=" + leadershipTermId + ", leaderId=" + leaderMemberId);
    }

    // ──────────────────────────────────────────────
    // 私有方法
    // ──────────────────────────────────────────────

    private void handleOrder(
        final ClientSession session,
        final DirectBuffer buffer,
        final int offset,
        final int length,
        final long sessionCount)
    {
        orderDecoder.wrapAndApplyHeader(buffer, offset, headerDecoder);

        final long orderId   = orderDecoder.orderId();
        final double price   = orderDecoder.price() / 100.0;
        final int quantity   = orderDecoder.quantity();
        final char side      = (char) orderDecoder.side();
        final long timestamp = orderDecoder.timestamp();

        final int symLen = orderDecoder.symbolLength();
        final byte[] symBytes = new byte[symLen];
        orderDecoder.getSymbol(symBytes, 0, symLen);
        final String symbol = new String(symBytes, StandardCharsets.UTF_8);

        System.out.printf("  [ForwardingService] Order #%d: id=%d, symbol=%s, price=%.2f, qty=%d, side=%c, ts=%d%n",
            globalMessageCount, orderId, symbol, price, quantity, side, timestamp);

        forwardMessage(orderPublication, buffer, offset, length, "Order", ORDER_STREAM_ID);

        sendText(session, String.format(
            "[Order Forwarded #%d] orderId=%d, symbol=%s, price=%.2f, qty=%d, side=%c (global=%d, session=%d)",
            globalMessageCount, orderId, symbol, price, quantity, side, globalMessageCount, sessionCount));
    }

    private void handleUser(
        final ClientSession session,
        final DirectBuffer buffer,
        final int offset,
        final int length,
        final long sessionCount)
    {
        userDecoder.wrapAndApplyHeader(buffer, offset, headerDecoder);

        final long userId    = userDecoder.userId();
        final int age        = userDecoder.age();
        final double balance = userDecoder.balance() / 100.0;
        final boolean active = userDecoder.isActive() != 0;

        final int unameLen = userDecoder.usernameLength();
        final byte[] unameBytes = new byte[unameLen];
        userDecoder.getUsername(unameBytes, 0, unameLen);
        final String username = new String(unameBytes, StandardCharsets.UTF_8);

        final int emailLen = userDecoder.emailLength();
        final byte[] emailBytes = new byte[emailLen];
        userDecoder.getEmail(emailBytes, 0, emailLen);
        final String email = new String(emailBytes, StandardCharsets.UTF_8);

        System.out.printf("  [ForwardingService] User #%d: id=%d, username=%s, email=%s, age=%d, balance=%.2f, active=%s%n",
            globalMessageCount, userId, username, email, age, balance, active);

        forwardMessage(userPublication, buffer, offset, length, "User", USER_STREAM_ID);

        sendText(session, String.format(
            "[User Forwarded #%d] userId=%d, username=%s, email=%s (global=%d, session=%d)",
            globalMessageCount, userId, username, email, globalMessageCount, sessionCount));
    }

    private void forwardMessage(
        final Publication publication,
        final DirectBuffer buffer,
        final int offset,
        final int length,
        final String messageType,
        final int streamId)
    {
        long result;
        int attempts = 0;

        while ((result = publication.offer(buffer, offset, length)) < 0 && attempts++ < 3)
        {
            if (result == Publication.NOT_CONNECTED)
            {
                System.out.println("    [Forward] 没有 " + messageType + " 订阅者 (streamId: " + streamId + ")");
                return;
            }
            cluster.idleStrategy().idle();
        }

        if (result > 0)
        {
            System.out.println("    [Forward] " + messageType + " → streamId " + streamId + " (position: " + result + ")");
        }
        else
        {
            System.err.println("    [Forward] 转发 " + messageType + " 失败: " + result);
        }
    }

    private void sendText(final ClientSession session, final String message)
    {
        final byte[] bytes = message.getBytes(StandardCharsets.UTF_8);
        sharedBuf.putBytes(0, bytes);
        long result;
        int retries = 0;
        while ((result = session.offer(sharedBuf, 0, bytes.length)) < 0 && retries++ < 3)
        {
            cluster.idleStrategy().idle();
        }
        if (result <= 0)
        {
            System.err.println("    [ForwardingService] 回复失败: " + result);
        }
    }
}
