package io.aeron.spring.cluster.service;

import io.aeron.ExclusivePublication;
import io.aeron.Image;
import io.aeron.cluster.ClusterTool;
import io.aeron.cluster.service.Cluster;
import io.aeron.cluster.service.ClusteredService;
import io.aeron.spring.cluster.config.SnapshotProperties;
import io.aeron.spring.cluster.snapshot.SnapshotService;
import org.agrona.DirectBuffer;
import org.agrona.ExpandableArrayBuffer;
import org.agrona.MutableDirectBuffer;
import org.agrona.collections.Long2LongHashMap;

import java.util.concurrent.TimeUnit;

import static io.aeron.cluster.service.Cluster.Role.LEADER;

/**
 * 集群服务抽象基类，封装快照公共逻辑。
 *
 * <h3>提供的公共能力</h3>
 * <ul>
 *   <li>{@link #offerToSnapshot} / {@link #pollSnapshot}：快照 IO 工具方法</li>
 *   <li>{@link #writeBaseSnapshot} / {@link #readBaseSnapshot}：
 *       序列化/反序列化 globalMessageCount + sessionMessageCounts</li>
 *   <li>{@link #onNewLeadershipTermEvent}：Leader 选举时条件触发快照</li>
 *   <li>{@link #checkLogGrowthSnapshot}：消息处理时日志增长量条件触发快照</li>
 * </ul>
 *
 * <h3>子类约定</h3>
 * <ol>
 *   <li>{@link #onTakeSnapshot} 中先调用 {@code writeBaseSnapshot(pub)}，
 *       再写自己的额外业务状态。</li>
 *   <li> 中先调用 {@code readBaseSnapshot(image)}，
 *       再读自己的额外业务状态。</li>
 *   <li>{@link #onSessionMessage} 处理消息后调用
 *       {@code checkLogGrowthSnapshot()} 检查日志增长触发条件。</li>
 * </ol>
 */
public abstract class AbstractSnapshotClusteredService implements ClusteredService
{
    /** 全局消息计数，子类可直接访问 */
    protected long globalMessageCount = 0;

    /** 各会话消息计数，子类可直接访问 */
    protected final Long2LongHashMap sessionMessageCounts = new Long2LongHashMap(-1);

    /** 共享缓冲区，用于快照 IO；子类也可复用于其他小数据写出 */
    protected final ExpandableArrayBuffer sharedBuf = new ExpandableArrayBuffer();

    protected Cluster cluster;

    // 快照触发（可为 null 表示禁用）
    private final SnapshotService    snapshotService;
    private final SnapshotProperties snapshotProps;

    /** 上次快照时的 logPosition，用于计算日志增长量 */
    private long lastSnapshotLogPosition = 0;

    protected AbstractSnapshotClusteredService(
        final SnapshotService snapshotService,
        final SnapshotProperties snapshotProps)
    {
        this.snapshotService = snapshotService;
        this.snapshotProps   = snapshotProps;
    }

    // ──────────────────────────────────────────────
    // 角色变更：同步 leader 状态到 SnapshotService
    // ──────────────────────────────────────────────

    /**
     * 当节点角色变更时，将最新 leader 状态同步给 {@link SnapshotService}。
     * <p>
     * 快照请求（{@link ClusterTool#snapshot}）只有 leader 节点的 ConsensusModule
     * 才会处理；follower 上调用会白白阻塞 5 秒超时。
     * 在此处统一维护状态，避免每个触发点重复判断。
     * <p>
     * 子类覆盖此方法时<b>必须</b>先调用 {@code super.onRoleChange(newRole)}。
     */
    @Override
    public void onRoleChange(final Cluster.Role newRole)
    {
        if (snapshotService != null)
        {
            snapshotService.setLeader(newRole == LEADER);
        }
    }

    // ──────────────────────────────────────────────
    // 快照触发：onNewLeadershipTermEvent
    // ──────────────────────────────────────────────

    @Override
    public void onNewLeadershipTermEvent(
        final long leadershipTermId,
        final long logPosition,
        final long timestamp,
        final long termBaseLogPosition,
        final int leaderMemberId,
        final int logSessionId,
        final TimeUnit timeUnit,
        final int appVersion)
    {
        onLeadershipTerm(leadershipTermId, leaderMemberId);

        if (snapshotService != null
            && snapshotProps.isOnLeaderElection()
            && leaderMemberId == cluster.memberId())
        {
            snapshotService.requestSnapshotAsync("LeaderElection termId=" + leadershipTermId);
        }
    }

    /**
     * 子类可覆盖此方法处理 leader 任期变更事件（仅用于业务逻辑，快照触发已在基类处理）。
     * 默认实现为空。
     */
    protected void onLeadershipTerm(final long leadershipTermId, final int leaderMemberId) {}

    // ──────────────────────────────────────────────
    // 快照触发：日志增长量
    // ──────────────────────────────────────────────

    /**
     * 在 {@link #onSessionMessage} 中调用，检查日志增长量是否达到阈值。
     * 仅 Leader 节点触发，避免 replay 期间重复触发。
     */
    protected void checkLogGrowthSnapshot()
    {
        if (snapshotService != null
            && cluster.role() == Cluster.Role.LEADER
            && snapshotProps.getLogGrowthBytes() > 0
            && (cluster.logPosition() - lastSnapshotLogPosition) >= snapshotProps.getLogGrowthBytes())
        {
            snapshotService.requestSnapshotAsync(
                "LogGrowth logPosition=" + cluster.logPosition()
                    + " lastSnapshot=" + lastSnapshotLogPosition);
        }
    }

    // ──────────────────────────────────────────────
    // 快照序列化：公共部分（globalCount + sessionCounts）
    // ──────────────────────────────────────────────

    /**
     * 将 globalMessageCount 和 sessionMessageCounts 写入快照流。
     * 子类在 {@link #onTakeSnapshot} 中首先调用此方法。
     */
    protected void writeBaseSnapshot(final ExclusivePublication pub)
    {
        lastSnapshotLogPosition = cluster.logPosition();

        sharedBuf.putLong(0, globalMessageCount);
        offerToSnapshot(pub, sharedBuf, 0, Long.BYTES);

        sharedBuf.putInt(0, sessionMessageCounts.size());
        offerToSnapshot(pub, sharedBuf, 0, Integer.BYTES);

        sessionMessageCounts.forEach((sessionId, count) ->
        {
            sharedBuf.putLong(0, sessionId);
            sharedBuf.putLong(Long.BYTES, count);
            offerToSnapshot(pub, sharedBuf, 0, Long.BYTES * 2);
        });
    }

    /**
     * 从快照流恢复 globalMessageCount 和 sessionMessageCounts。
     * 子类在 中首先调用此方法。
     */
    protected void readBaseSnapshot(final Image snapshotImage)
    {
        final MutableDirectBuffer buf = new ExpandableArrayBuffer();

        pollSnapshot(snapshotImage, buf, Long.BYTES);
        globalMessageCount = buf.getLong(0);

        pollSnapshot(snapshotImage, buf, Integer.BYTES);
        final int count = buf.getInt(0);

        sessionMessageCounts.clear();
        for (int i = 0; i < count; i++)
        {
            pollSnapshot(snapshotImage, buf, Long.BYTES * 2);
            sessionMessageCounts.put(buf.getLong(0), buf.getLong(Long.BYTES));
        }
    }

    // ──────────────────────────────────────────────
    // 快照 IO 工具方法
    // ──────────────────────────────────────────────

    /**
     * 向快照 Publication 写出一段数据，失败时 idle 重试直到成功。
     */
    protected void offerToSnapshot(
        final ExclusivePublication publication,
        final DirectBuffer buffer,
        final int offset,
        final int length)
    {
        while (publication.offer(buffer, offset, length) < 0)
        {
            cluster.idleStrategy().idle();
        }
    }

    /**
     * 从快照 Image 读取指定长度的数据，不足时 idle 等待。
     */
    protected void pollSnapshot(
        final Image image,
        final MutableDirectBuffer buffer,
        final int expectedLength)
    {
        int bytesRead = 0;
        while (bytesRead < expectedLength)
        {
            final int fragments = image.poll(
                (buf, offset, length, header) -> buffer.putBytes(0, buf, offset, length), 1);

            if (fragments == 0)
            {
                if (image.isClosed() || image.isEndOfStream())
                {
                    throw new IllegalStateException("快照流意外关闭");
                }
                cluster.idleStrategy().idle();
            }
            else
            {
                bytesRead += expectedLength;
            }
        }
    }
}
