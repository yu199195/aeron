/*
 * Copyright 2014-2025 Real Logic Limited.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.aeron.spring.cluster.startup;

import io.aeron.CommonContext;
import io.aeron.archive.Archive;
import io.aeron.archive.client.AeronArchive;
import io.aeron.cluster.ConsensusModule;
import io.aeron.cluster.service.ClusteredService;
import io.aeron.cluster.service.ClusteredServiceContainer;
import io.aeron.driver.MediaDriver;
import io.aeron.spring.cluster.config.ArchiveProperties;
import io.aeron.spring.cluster.config.ClusterProperties;
import io.aeron.spring.cluster.config.ConsensusProperties;
import io.aeron.spring.cluster.config.ContextFactory;
import io.aeron.spring.cluster.config.MediaDriverProperties;
import io.aeron.spring.cluster.util.ClusterDirs;
import io.aeron.spring.cluster.util.ClusterPortConfig;
import org.agrona.ErrorHandler;
import org.agrona.concurrent.NoOpLock;
import org.agrona.concurrent.ShutdownSignalBarrier;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Wrapper class to simplify cluster configuration. This is sample code and is intended to show a mechanism for
 * managing the configuration of the components required for Aeron Cluster. This code may change between versions
 * and API compatibility is not guaranteed.
 */
public final class ClusterConfig
{
    /** @see ClusterPortConfig#PORTS_PER_NODE */
    public static final int PORTS_PER_NODE = ClusterPortConfig.PORTS_PER_NODE;

    /** @see ClusterPortConfig#ARCHIVE_CONTROL_PORT_OFFSET */
    public static final int ARCHIVE_CONTROL_PORT_OFFSET = ClusterPortConfig.ARCHIVE_CONTROL_PORT_OFFSET;

    /** @see ClusterPortConfig#CLIENT_FACING_PORT_OFFSET */
    public static final int CLIENT_FACING_PORT_OFFSET = ClusterPortConfig.CLIENT_FACING_PORT_OFFSET;

    /** @see ClusterPortConfig#MEMBER_FACING_PORT_OFFSET */
    public static final int MEMBER_FACING_PORT_OFFSET = ClusterPortConfig.MEMBER_FACING_PORT_OFFSET;

    /** @see ClusterPortConfig#LOG_PORT_OFFSET */
    public static final int LOG_PORT_OFFSET = ClusterPortConfig.LOG_PORT_OFFSET;

    /** @see ClusterPortConfig#TRANSFER_PORT_OFFSET */
    public static final int TRANSFER_PORT_OFFSET = ClusterPortConfig.TRANSFER_PORT_OFFSET;

    /** @see ClusterPortConfig#REPLICATION_PORT_OFFSET */
    public static final int REPLICATION_PORT_OFFSET = ClusterPortConfig.REPLICATION_PORT_OFFSET;

    /** @see ClusterPortConfig#ARCHIVE_RESPONSE_PORT_OFFSET */
    public static final int ARCHIVE_RESPONSE_PORT_OFFSET = ClusterPortConfig.ARCHIVE_RESPONSE_PORT_OFFSET;

    /**
     * Subdirectory into which archive files are stored.
     */
    public static final String ARCHIVE_SUB_DIR = "archive";

    /**
     * Subdirectory into which cluster files are stored.
     */
    public static final String CLUSTER_SUB_DIR = "cluster";

    private final int memberId;
    private final String ingressHostname;
    private final String clusterHostname;
    private final MediaDriver.Context mediaDriverContext;
    private final Archive.Context archiveContext;
    private final AeronArchive.Context aeronArchiveContext;
    private final ConsensusModule.Context consensusModuleContext;
    private final List<ClusteredServiceContainer.Context> clusteredServiceContexts;

    ClusterConfig(
        final int memberId,
        final String ingressHostname,
        final String clusterHostname,
        final MediaDriver.Context mediaDriverContext,
        final Archive.Context archiveContext,
        final AeronArchive.Context aeronArchiveContext,
        final ConsensusModule.Context consensusModuleContext,
        final List<ClusteredServiceContainer.Context> clusteredServiceContexts)
    {
        this.memberId = memberId;
        this.ingressHostname = ingressHostname;
        this.clusterHostname = clusterHostname;
        this.mediaDriverContext = mediaDriverContext;
        this.archiveContext = archiveContext;
        this.aeronArchiveContext = aeronArchiveContext;
        this.consensusModuleContext = consensusModuleContext;
        this.clusteredServiceContexts = clusteredServiceContexts;
    }

    /**
     * Create a new ClusterConfig. This call allows for 2 separate lists of hostnames, so that there can be 'external'
     * addresses for ingress requests and 'internal' addresses that will handle all the cluster replication and
     * control traffic.
     *
     * @param startingMemberId   id for the first member in the list of entries.
     * @param memberId           id for this node.
     * @param ingressHostnames   list of hostnames that will receive ingress request traffic.
     * @param clusterHostnames   list of hostnames that will receive cluster traffic.
     * @param portBase           base port to derive remaining ports from.
     * @param parentDir          directory under which the persistent directories will be created.
     * @param clusteredService   instance of the clustered service that will run with this configuration.
     * @param additionalServices instances of additional clustered services that will run with this configuration.
     * @return configuration that wraps all aeron service configuration.
     */
    public static ClusterConfig create(
        final int startingMemberId,
        final int memberId,
        final List<String> ingressHostnames,
        final List<String> clusterHostnames,
        final int portBase,
        final File parentDir,
        final ClusteredService clusteredService,
        final ClusteredService... additionalServices)
    {
        if (memberId < startingMemberId || (startingMemberId + ingressHostnames.size()) <= memberId)
        {
            throw new IllegalArgumentException(
                "memberId=" + memberId + " is invalid, should be " + startingMemberId +
                " <= memberId < " + startingMemberId + ingressHostnames.size());
        }

        final String clusterMembers = clusterMembers(startingMemberId, ingressHostnames, clusterHostnames, portBase);

        final String aeronDirName = CommonContext.getAeronDirectoryName() + "-" + memberId + "-driver";
        final File baseDir = new File(parentDir, "aeron-cluster-" + memberId);

        final String ingressHostname = ingressHostnames.get(memberId - startingMemberId);
        final String hostname = clusterHostnames.get(memberId - startingMemberId);

        final MediaDriver.Context mediaDriverContext = new MediaDriver.Context()
            .aeronDirectoryName(aeronDirName);

        // controlResponseChannel：Archive client 接收 replay 控制应答的固定端口（取代 :0）
        final AeronArchive.Context replicationArchiveContext = new AeronArchive.Context()
            .controlResponseChannel(udpChannel(memberId, hostname, portBase, ARCHIVE_RESPONSE_PORT_OFFSET));

        final Archive.Context archiveContext = new Archive.Context()
            .aeronDirectoryName(aeronDirName)
            .archiveDir(new File(baseDir, ARCHIVE_SUB_DIR))
            .controlChannel(udpChannel(memberId, hostname, portBase, ARCHIVE_CONTROL_PORT_OFFSET))
            .archiveClientContext(replicationArchiveContext)
            .localControlChannel("aeron:ipc?term-length=64k")
            // replicationChannel：Archive Replayer 回传日志数据流的固定端口（取代 :0）
            .replicationChannel(udpChannel(memberId, hostname, portBase, REPLICATION_PORT_OFFSET))
            .recordingEventsEnabled(false);

        final AeronArchive.Context aeronArchiveContext = new AeronArchive.Context()
            .lock(NoOpLock.INSTANCE)
            .controlRequestChannel(archiveContext.localControlChannel())
            .controlRequestStreamId(archiveContext.localControlStreamId())
            .controlResponseChannel(archiveContext.localControlChannel())
            .aeronDirectoryName(aeronDirName);

        final ConsensusModule.Context consensusModuleContext = new ConsensusModule.Context()
            .clusterMemberId(memberId)
            .clusterMembers(clusterMembers)
            .clusterDir(new File(baseDir, CLUSTER_SUB_DIR))
            .archiveContext(aeronArchiveContext.clone())
            .serviceCount(1 + additionalServices.length)
            .ingressChannel("aeron:udp")
            // replicationChannel：ConsensusModule 追赶日志时接收数据流的固定端口（取代 :0）
            .replicationChannel(udpChannel(memberId, hostname, portBase, REPLICATION_PORT_OFFSET));

        final List<ClusteredServiceContainer.Context> serviceContexts = new ArrayList<>();

        final ClusteredServiceContainer.Context clusteredServiceContext = new ClusteredServiceContainer.Context()
            .aeronDirectoryName(aeronDirName)
            .archiveContext(aeronArchiveContext.clone())
            .clusterDir(new File(baseDir, CLUSTER_SUB_DIR))
            .clusteredService(clusteredService)
            .serviceId(0);
        serviceContexts.add(clusteredServiceContext);

        for (int i = 0; i < additionalServices.length; i++)
        {
            final ClusteredServiceContainer.Context additionalServiceContext = new ClusteredServiceContainer.Context()
                .aeronDirectoryName(aeronDirName)
                .archiveContext(aeronArchiveContext.clone())
                .clusterDir(new File(baseDir, CLUSTER_SUB_DIR))
                .clusteredService(additionalServices[i])
                .serviceId(i + 1);
            serviceContexts.add(additionalServiceContext);
        }

        return new ClusterConfig(
            memberId,
            ingressHostname,
            hostname,
            mediaDriverContext,
            archiveContext,
            aeronArchiveContext,
            consensusModuleContext,
            serviceContexts);
    }

    /**
     * Create a new ClusterConfig. This call allows for 2 separate lists of hostnames, so that there can be 'external'
     * addresses for ingress requests and 'internal' addresses that will handle all the cluster replication and
     * control traffic.
     *
     * @param nodeId             id for this node.
     * @param ingressHostnames   list of hostnames that will receive ingress request traffic.
     * @param clusterHostnames   list of hostnames that will receive cluster traffic.
     * @param portBase           base port to derive remaining ports from.
     * @param clusteredService   instance of the clustered service that will run with this configuration.
     * @param additionalServices instances of additional clustered services that will run with this configuration.
     * @return configuration that wraps all aeron service configuration.
     */
    public static ClusterConfig create(
        final int nodeId,
        final List<String> ingressHostnames,
        final List<String> clusterHostnames,
        final int portBase,
        final ClusteredService clusteredService,
        final ClusteredService... additionalServices)
    {
        return create(
            0,
            nodeId,
            ingressHostnames,
            clusterHostnames,
            portBase,
            new File(System.getProperty("user.dir")),
            clusteredService,
            additionalServices);
    }

    /**
     * Create a new ClusterConfig. This only supports a single lists of hostnames.
     *
     * @param nodeId           id for this node.
     * @param hostnames        list of hostnames that will receive ingress request and cluster traffic.
     * @param portBase         base port to derive remaining ports from.
     * @param clusteredService instance of the clustered service that will run on this node.
     * @return configuration that wraps the detailed aeron service configuration.
     */
    public static ClusterConfig create(
        final int nodeId,
        final List<String> hostnames,
        final int portBase,
        final ClusteredService clusteredService)
    {
        return create(nodeId, hostnames, hostnames, portBase, clusteredService);
    }

    /**
     * Create a fully-configured ClusterConfig from {@link ClusterProperties}.
     * <p>
     * Applies MediaDriver, Archive, and ConsensusModule settings from {@code props},
     * sets up directories, and attaches the termination hook to {@code barrier}.
     *
     * @param nodeId           id for this node.
     * @param hostnames        list of hostnames.
     * @param portBase         base port.
     * @param props            Spring-bound cluster properties.
     * @param barrier          shutdown signal barrier used as termination hook.
     * @param clusteredService clustered service implementation.
     * @return fully configured {@link ClusterConfig}.
     */
    public static ClusterConfig create(
        final int nodeId,
        final List<String> hostnames,
        final int portBase,
        final ClusterProperties props,
        final ShutdownSignalBarrier barrier,
        final ClusteredService clusteredService)
    {
        final ClusterConfig clusterConfig = create(nodeId, hostnames, portBase, clusteredService);

        final String nodeDir        = props.aeronDir();
        final String mediaDriverDir = ClusterDirs.mediaDriverDir(nodeDir);
        final File   archiveDir     = ClusterDirs.archiveDir(nodeDir);
        final File   clusterDir     = ClusterDirs.clusterDir(nodeDir);

        // ── 目录 ─────────────────────────────────────────────────────────────
        clusterConfig.aeronDirectoryName(mediaDriverDir);
        clusterConfig.archiveContext().archiveDir(archiveDir);
        clusterConfig.consensusModuleContext().clusterDir(clusterDir);
        clusterConfig.clusteredServiceContext().clusterDir(clusterDir);

        // ── MediaDriver ───────────────────────────────────────────────────────
        applyMediaDriverConfig(clusterConfig, props.getMediaDriver(), barrier);

        // ── Archive ───────────────────────────────────────────────────────────
        applyArchiveConfig(clusterConfig, props.getArchive(), archiveDir, props.isDeleteArchiveOnStart());

        // ── ConsensusModule ───────────────────────────────────────────────────
        applyConsensusConfig(clusterConfig, props.getConsensus(), clusterDir,
            props.isDeleteConsensusOnStart(), barrier);

        return clusterConfig;
    }
    
    private static void applyMediaDriverConfig(
        final ClusterConfig clusterConfig,
        final MediaDriverProperties cfg,
        final ShutdownSignalBarrier barrier)
    {
        ContextFactory.applyMediaDriver(clusterConfig.mediaDriverContext(), cfg)
            .terminationHook(barrier::signalAll);
    }

    private static void applyArchiveConfig(
        final ClusterConfig clusterConfig,
        final ArchiveProperties cfg,
        final File archiveDir,
        final boolean deleteArchiveOnStart)
    {
        ContextFactory.applyArchive(clusterConfig.archiveContext(), cfg)
            .archiveDir(archiveDir)
            .deleteArchiveOnStart(deleteArchiveOnStart);
    }

    private static void applyConsensusConfig(
        final ClusterConfig clusterConfig,
        final ConsensusProperties cfg,
        final File clusterDir,
        final boolean deleteConsensusOnStart,
        final ShutdownSignalBarrier barrier)
    {
        clusterConfig.consensusModuleContext()
            .clusterDir(clusterDir)
            .clusterId(cfg.getClusterId())
            .appointedLeaderId(cfg.getAppointedLeaderId())
            .appVersion(cfg.getAppVersion())
            .sessionTimeoutNs(cfg.getSessionTimeoutNs())
            .maxConcurrentSessions(cfg.getMaxConcurrentSessions())
            .leaderHeartbeatTimeoutNs(cfg.getLeaderHeartbeatTimeoutNs())
            .leaderHeartbeatIntervalNs(cfg.getLeaderHeartbeatIntervalNs())
            .electionTimeoutNs(cfg.getElectionTimeoutNs())
            .electionStatusIntervalNs(cfg.getElectionStatusIntervalNs())
            .startupCanvassTimeoutNs(cfg.getStartupCanvassTimeoutNs())
            .terminationTimeoutNs(cfg.getTerminationTimeoutNs())
            .wheelTickResolutionNs(cfg.getWheelTickResolutionNs())
            .ticksPerWheel(cfg.getTicksPerWheel())
            .ingressFragmentLimit(cfg.getIngressFragmentLimit())
            .logFragmentLimit(cfg.getLogFragmentLimit())
            .cycleThresholdNs(cfg.getCycleThresholdNs())
            .totalSnapshotDurationThresholdNs(cfg.getTotalSnapshotDurationThresholdNs())
            .fileSyncLevel(cfg.getFileSyncLevel())
            .errorBufferLength(cfg.getErrorBufferLength())
            .terminationHook(barrier::signalAll)
            .deleteDirOnStart(deleteConsensusOnStart);
    }

    /**
     * Set the same error handler for all contexts.
     *
     * @param errorHandler to receive errors.
     */
    public void errorHandler(final ErrorHandler errorHandler)
    {
        this.mediaDriverContext.errorHandler(errorHandler);
        this.archiveContext.errorHandler(errorHandler);
        this.aeronArchiveContext.errorHandler(errorHandler);
        this.consensusModuleContext.errorHandler(errorHandler);
        this.clusteredServiceContexts.forEach((ctx) -> ctx.errorHandler(errorHandler));
    }

    /**
     * Set the aeron directory for all configuration contexts.
     *
     * @param aeronDir directory to use for aeron.
     */
    public void aeronDirectoryName(final String aeronDir)
    {
        this.mediaDriverContext.aeronDirectoryName(aeronDir);
        this.archiveContext.aeronDirectoryName(aeronDir);
        this.aeronArchiveContext.aeronDirectoryName(aeronDir);
        this.consensusModuleContext.aeronDirectoryName(aeronDir);
        this.clusteredServiceContexts.forEach(ctx -> ctx.aeronDirectoryName(aeronDir));
    }

    /**
     * Set the base directory for cluster and archive.
     *
     * @param baseDir parent directory to be used for archive and cluster stored data.
     */
    public void baseDir(final File baseDir)
    {
        this.archiveContext.archiveDir(new File(baseDir, ARCHIVE_SUB_DIR));
        this.consensusModuleContext.clusterDir(new File(baseDir, CLUSTER_SUB_DIR));
        this.clusteredServiceContexts.forEach((ctx) -> ctx.clusterDir(new File(baseDir, CLUSTER_SUB_DIR)));
    }

    /**
     * Gets the configuration's media driver context.
     *
     * @return configured {@link MediaDriver.Context}.
     */
    public MediaDriver.Context mediaDriverContext()
    {
        return mediaDriverContext;
    }
    

    /**
     * Gets the configuration's archive context.
     *
     * @return configured {@link Archive.Context}.
     */
    public Archive.Context archiveContext()
    {
        return archiveContext;
    }

    /**
     * Gets the configuration's aeron archive context.
     *
     * @return configured {@link AeronArchive.Context}.
     */
    public AeronArchive.Context aeronArchiveContext()
    {
        return aeronArchiveContext;
    }

    /**
     * Gets the configuration's consensus module context.
     *
     * @return configured {@link ConsensusModule.Context}.
     */
    public ConsensusModule.Context consensusModuleContext()
    {
        return consensusModuleContext;
    }

    /**
     * Gets the configuration's clustered service container context.
     *
     * @return configured {@link ClusteredServiceContainer.Context}.
     */
    public ClusteredServiceContainer.Context clusteredServiceContext()
    {
        return clusteredServiceContexts.get(0);
    }

    /**
     * Gets the configuration's list of clustered service container contexts.
     *
     * @return configured list of {@link ClusteredServiceContainer.Context}.
     */
    public List<ClusteredServiceContainer.Context> clusteredServiceContexts()
    {
        return clusteredServiceContexts;
    }

    /**
     * memberId of this node.
     *
     * @return memberId.
     */
    public int memberId()
    {
        return memberId;
    }

    /**
     * Hostname of this node that will receive ingress traffic.
     *
     * @return ingress hostname.
     */
    public String ingressHostname()
    {
        return ingressHostname;
    }

    /**
     * Hostname of this node that will receive cluster traffic.
     *
     * @return cluster hostname
     */
    public String clusterHostname()
    {
        return clusterHostname;
    }

    /**
     * String representing the cluster members configuration.
     */
    public static String clusterMembers(
        final List<String> ingressHostnames, final List<String> clusterHostnames, final int portBase)
    {
        return clusterMembers(0, ingressHostnames, clusterHostnames, portBase);
    }

    /**
     * String representing the cluster members configuration.
     */
    public static String clusterMembers(
        final int startingMemberId,
        final List<String> ingressHostnames,
        final List<String> clusterHostnames,
        final int portBase)
    {
        if (ingressHostnames.size() != clusterHostnames.size())
        {
            throw new IllegalArgumentException("ingressHostnames and clusterHostnames must be the same size");
        }

        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ingressHostnames.size(); i++)
        {
            final int memberId = i + startingMemberId;
            sb.append(memberId);
            sb.append(',').append(endpoint(memberId, ingressHostnames.get(i), portBase, CLIENT_FACING_PORT_OFFSET));
            sb.append(',').append(endpoint(memberId, clusterHostnames.get(i), portBase, MEMBER_FACING_PORT_OFFSET));
            sb.append(',').append(endpoint(memberId, clusterHostnames.get(i), portBase, LOG_PORT_OFFSET));
            sb.append(',').append(endpoint(memberId, clusterHostnames.get(i), portBase, TRANSFER_PORT_OFFSET));
            sb.append(',').append(endpoint(memberId, clusterHostnames.get(i), portBase, ARCHIVE_CONTROL_PORT_OFFSET));
            sb.append('|');
        }

        return sb.toString();
    }

    /**
     * Ingress endpoints generated from a list of hostnames.
     */
    public static String ingressEndpoints(
        final List<String> hostnames,
        final int portBase,
        final int clientFacingPortOffset)
    {
        return ingressEndpoints(0, hostnames, portBase, clientFacingPortOffset);
    }

    /**
     * Ingress endpoints generated from a list of hostnames.
     */
    public static String ingressEndpoints(
        final int startingMemberId,
        final List<String> hostnames,
        final int portBase,
        final int clientFacingPortOffset)
    {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < hostnames.size(); i++)
        {
            final int memberId = i + startingMemberId;
            sb.append(memberId).append('=');
            sb.append(hostnames.get(i)).append(':').append(calculatePort(memberId, portBase, clientFacingPortOffset));
            sb.append(',');
        }

        sb.setLength(sb.length() - 1);

        return sb.toString();
    }

    /**
     * Calculates a port for use with a node based on a specific offset.
     *
     * @see ClusterPortConfig#calculatePort(int, int, int)
     */
    public static int calculatePort(final int nodeId, final int portBase, final int offset)
    {
        return ClusterPortConfig.calculatePort(nodeId, portBase, offset);
    }

    private static String udpChannel(final int nodeId, final String hostname, final int portBase, final int portOffset)
    {
        final int port = calculatePort(nodeId, portBase, portOffset);
        return "aeron:udp?endpoint=" + hostname + ":" + port;
    }

    private static String endpoint(final int nodeId, final String hostname, final int portBase, final int portOffset)
    {
        return hostname + ":" + calculatePort(nodeId, portBase, portOffset);
    }
}
