package io.aeron.spring.cluster.store;

import io.aeron.ExclusivePublication;
import io.aeron.Image;
import io.aeron.cluster.service.Cluster;
import io.aeron.spring.cluster.model.UserRecord;
import io.aeron.spring.cluster.sbe.MessageHeaderDecoder;
import io.aeron.spring.cluster.sbe.MessageHeaderEncoder;
import io.aeron.spring.cluster.sbe.UserDecoder;
import io.aeron.spring.cluster.sbe.UserEncoder;
import org.agrona.ExpandableArrayBuffer;
import org.agrona.MutableDirectBuffer;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * User 业务存储。
 *
 * <h3>快照序列化（SBE）</h3>
 * 使用与网络传输完全相同的 {@link UserEncoder}/{@link UserDecoder}：
 * <pre>
 * Frame-0  : count (int32) ── 共多少条记录
 * Frame-1…N: SBE User 消息（MessageHeader + User body），每条一帧
 * </pre>
 */
public class UserStore
{
    private final Map<Long, UserRecord> store = new LinkedHashMap<>();

    // SBE 编解码器（快照 I/O 专用）
    private final MessageHeaderEncoder headerEncoder = new MessageHeaderEncoder();
    private final MessageHeaderDecoder headerDecoder = new MessageHeaderDecoder();
    private final UserEncoder          userEncoder   = new UserEncoder();
    private final UserDecoder          userDecoder   = new UserDecoder();

    // ──────────────────────────────────────────────
    // 业务操作
    // ──────────────────────────────────────────────

    /**
     * 插入或更新一条 User 记录（幂等）。
     *
     * @return true 表示新增；false 表示覆盖已有记录
     */
    public boolean upsert(final UserRecord record)
    {
        final boolean isNew = !store.containsKey(record.userId());
        store.put(record.userId(), record);
        return isNew;
    }

    public UserRecord get(final long userId)
    {
        return store.get(userId);
    }

    public List<UserRecord> all()
    {
        return Collections.unmodifiableList(new ArrayList<>(store.values()));
    }

    public int size()
    {
        return store.size();
    }

    public void clear()
    {
        store.clear();
    }

    // ──────────────────────────────────────────────
    // 快照：写出（SBE 编码）
    // ──────────────────────────────────────────────

    /**
     * 将全部 User 记录用 SBE 序列化到快照 Publication。
     *
     * <p><b>Frame-0</b>：4 字节 int32，存放记录数量。
     * <p><b>Frame-1…N</b>：每条记录编码为标准 SBE User 消息
     * （{@code MessageHeader(8字节) + userId + age + balance + isActive + username + email}）。
     */
    public void writeSnapshot(
        final ExclusivePublication publication,
        final ExpandableArrayBuffer buf,
        final Cluster cluster)
    {
        // ── Frame-0: 记录总数 ──
        buf.putInt(0, store.size());
        offerUntilDone(publication, buf, 0, Integer.BYTES, cluster);

        // ── Frame-1…N: 每条 User 用 SBE 编码 ──
        for (final UserRecord r : store.values())
        {
            final byte[] unameBytes = r.username().getBytes(StandardCharsets.UTF_8);
            final byte[] emailBytes = r.email().getBytes(StandardCharsets.UTF_8);

            // wrapAndApplyHeader 填好 header 并定位 encoder 到 body 起始
            userEncoder.wrapAndApplyHeader(buf, 0, headerEncoder)
                .userId(r.userId())
                .age(r.age())
                .balance(r.balance())
                .isActive((short)(r.active() ? 1 : 0))
                .putUsername(unameBytes, 0, unameBytes.length)
                .putEmail(emailBytes, 0, emailBytes.length);

            // 总长度 = header + block + username变长段 + email变长段
            // 每个变长段 = 4字节长度前缀(uint32) + 数据字节
            final int encodedLength = MessageHeaderEncoder.ENCODED_LENGTH
                + UserEncoder.BLOCK_LENGTH
                + Integer.BYTES + unameBytes.length   // username
                + Integer.BYTES + emailBytes.length;  // email

            offerUntilDone(publication, buf, 0, encodedLength, cluster);
        }

        System.out.println("  [UserStore] 快照写出: " + store.size() + " 条 User 记录 (SBE)");
    }

    // ──────────────────────────────────────────────
    // 快照：读入（SBE 解码）
    // ──────────────────────────────────────────────

    /**
     * 从快照 Image 用 SBE 解码并还原全部 User 记录。
     *
     * <p>每次 poll 得到一个完整帧，对应 {@link #writeSnapshot} 的一次 offer。
     */
    public void readSnapshot(
        final Image snapshotImage,
        final ExpandableArrayBuffer buf,
        final Cluster cluster)
    {
        store.clear();

        // ── Frame-0: 记录总数 ──
        pollUntilDone(snapshotImage, buf, cluster);
        final int count = buf.getInt(0);

        // ── Frame-1…N: 每条 User ──
        for (int i = 0; i < count; i++)
        {
            pollUntilDone(snapshotImage, buf, cluster);

            // wrapAndApplyHeader 读取 header，定位 decoder 到 body 起始
            userDecoder.wrapAndApplyHeader(buf, 0, headerDecoder);

            final long    userId  = userDecoder.userId();
            final int     age     = userDecoder.age();
            final long    balance = userDecoder.balance();
            final boolean active  = userDecoder.isActive() != 0;

            final int unameLen = userDecoder.usernameLength();
            final byte[] unameBytes = new byte[unameLen];
            userDecoder.getUsername(unameBytes, 0, unameLen);
            final String username = new String(unameBytes, StandardCharsets.UTF_8);

            final int emailLen = userDecoder.emailLength();
            final byte[] emailBytes = new byte[emailLen];
            userDecoder.getEmail(emailBytes, 0, emailLen);
            final String email = new String(emailBytes, StandardCharsets.UTF_8);

            store.put(userId, new UserRecord(userId, username, email, age, balance, active));
        }

        System.out.println("  [UserStore] 快照恢复: " + store.size() + " 条 User 记录 (SBE)");
    }

    // ──────────────────────────────────────────────
    // 工具
    // ──────────────────────────────────────────────

    private static void offerUntilDone(
        final ExclusivePublication pub,
        final MutableDirectBuffer buf,
        final int offset,
        final int length,
        final Cluster cluster)
    {
        while (pub.offer(buf, offset, length) < 0)
        {
            cluster.idleStrategy().idle();
        }
    }

    /**
     * 轮询快照流，直到收到一个完整帧，将帧内容写入 buf[0..)。
     */
    private static void pollUntilDone(
        final Image image,
        final MutableDirectBuffer buf,
        final Cluster cluster)
    {
        while (true)
        {
            final int[] written = {0};
            final int fragments = image.poll(
                (srcBuf, offset, length, header) ->
                {
                    buf.putBytes(0, srcBuf, offset, length);
                    written[0] = length;
                }, 1);

            if (fragments > 0)
            {
                return;
            }
            else if (image.isClosed() || image.isEndOfStream())
            {
                throw new IllegalStateException("[UserStore] 快照流意外关闭");
            }
            else
            {
                cluster.idleStrategy().idle();
            }
        }
    }
}
