/*
 * Copyright 2014-2025 Real Logic Limited.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.aeron.spring.cluster.service;

import io.aeron.ExclusivePublication;
import io.aeron.Image;
import io.aeron.cluster.codecs.CloseReason;
import io.aeron.cluster.service.ClientSession;
import io.aeron.cluster.service.Cluster;
import io.aeron.logbuffer.Header;
import io.aeron.spring.cluster.config.SnapshotProperties;
import io.aeron.spring.cluster.sbe.MessageHeaderDecoder;
import io.aeron.spring.cluster.sbe.OrderDecoder;
import io.aeron.spring.cluster.sbe.UserDecoder;
import io.aeron.spring.cluster.snapshot.SnapshotService;
import org.agrona.DirectBuffer;
import org.agrona.collections.Long2ObjectHashMap;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * 发布-订阅集群服务：客户端通过文本命令订阅特定类型的 SBE 消息。
 * <p>
 * <b>消息协议</b>：
 * <pre>
 * SUBSCRIBE ORDER    - 订阅 Order 消息
 * SUBSCRIBE USER     - 订阅 User 消息
 * UNSUBSCRIBE ORDER  - 取消订阅
 * UNSUBSCRIBE USER
 * </pre>
 * 快照：序列化 globalCount + sessionCounts（由基类处理），无额外业务状态。
 */
public class PubSubClusteredService extends AbstractSnapshotClusteredService
{
    private static final int SUB_TYPE_ORDER = OrderDecoder.TEMPLATE_ID;
    private static final int SUB_TYPE_USER  = UserDecoder.TEMPLATE_ID;

    /** sessionId → 订阅的 templateId 列表 */
    private final Long2ObjectHashMap<List<Integer>> subscriptions = new Long2ObjectHashMap<>();

    // SBE 解码器 flyweight
    private final MessageHeaderDecoder headerDecoder = new MessageHeaderDecoder();
    private final OrderDecoder orderDecoder = new OrderDecoder();
    private final UserDecoder userDecoder = new UserDecoder();

    public PubSubClusteredService(
        final SnapshotService snapshotService,
        final SnapshotProperties snapshotProps)
    {
        super(snapshotService, snapshotProps);
    }

    @Override
    public void onStart(final Cluster cluster, final Image snapshotImage)
    {
        this.cluster = cluster;

        if (snapshotImage != null)
        {
            readBaseSnapshot(snapshotImage);
            System.out.println("  [PubSubService] 从快照恢复完成: globalCount=" + globalMessageCount);
        }

        System.out.println("  [PubSubService] 已启动");
        System.out.println("  [PubSubService] 支持命令: SUBSCRIBE ORDER / SUBSCRIBE USER / UNSUBSCRIBE ORDER / UNSUBSCRIBE USER");
    }

    @Override
    public void onSessionOpen(final ClientSession session, final long timestamp)
    {
        System.out.println("  [PubSubService] 会话打开: sessionId=" + session.id());
        sessionMessageCounts.put(session.id(), 0L);
        subscriptions.put(session.id(), new ArrayList<>());
        sendText(session, "Welcome! sessionId=" + session.id() +
            "\n命令: SUBSCRIBE ORDER | SUBSCRIBE USER | UNSUBSCRIBE ORDER | UNSUBSCRIBE USER");
    }

    @Override
    public void onSessionClose(final ClientSession session, final long timestamp, final CloseReason closeReason)
    {
        System.out.println("  [PubSubService] 会话关闭: sessionId=" + session.id() + ", reason=" + closeReason);
        sessionMessageCounts.remove(session.id());
        subscriptions.remove(session.id());
    }

    @Override
    public void onSessionMessage(
        final ClientSession session,
        final long timestamp,
        final DirectBuffer buffer,
        final int offset,
        final int length,
        final Header header)
    {
        globalMessageCount++;
        final long sessionCount = sessionMessageCounts.get(session.id()) + 1;
        sessionMessageCounts.put(session.id(), sessionCount);

        checkLogGrowthSnapshot();

        if (length >= MessageHeaderDecoder.ENCODED_LENGTH)
        {
            headerDecoder.wrap(buffer, offset);
            final int templateId = headerDecoder.templateId();

            if (templateId == OrderDecoder.TEMPLATE_ID)
            {
                handleOrder(session, buffer, offset, length, sessionCount);
                return;
            }
            else if (templateId == UserDecoder.TEMPLATE_ID)
            {
                handleUser(session, buffer, offset, length, sessionCount);
                return;
            }
        }

        final byte[] bytes = new byte[length];
        buffer.getBytes(offset, bytes);
        final String command = new String(bytes, StandardCharsets.UTF_8).trim();

        if (!handleCommand(session, command))
        {
            sendText(session, "[Echo] " + command);
        }
    }

    @Override
    public void onTimerEvent(final long correlationId, final long timestamp) {}

    @Override
    public void onTakeSnapshot(final ExclusivePublication snapshotPublication)
    {
        System.out.println("  [PubSubService] 保存快照: globalCount=" + globalMessageCount);
        writeBaseSnapshot(snapshotPublication);
    }

    @Override
    public void onRoleChange(final Cluster.Role newRole)
    {
        super.onRoleChange(newRole);
        System.out.println("  [PubSubService] 角色变更: " + newRole);
    }

    @Override
    public void onTerminate(final Cluster cluster)
    {
        System.out.println("  [PubSubService] 正在关闭");
    }

    @Override
    protected void onLeadershipTerm(final long leadershipTermId, final int leaderMemberId)
    {
        System.out.println("  [PubSubService] 新领导任期: termId=" + leadershipTermId + ", leaderId=" + leaderMemberId);
    }

    // ──────────────────────────────────────────────
    // 私有方法
    // ──────────────────────────────────────────────

    private void handleOrder(
        final ClientSession session,
        final DirectBuffer buffer,
        final int offset,
        final int length,
        final long sessionCount)
    {
        orderDecoder.wrapAndApplyHeader(buffer, offset, headerDecoder);

        final long orderId   = orderDecoder.orderId();
        final double price   = orderDecoder.price() / 100.0;
        final int quantity   = orderDecoder.quantity();
        final char side      = (char) orderDecoder.side();

        final int symLen = orderDecoder.symbolLength();
        final byte[] symBytes = new byte[symLen];
        orderDecoder.getSymbol(symBytes, 0, symLen);
        final String symbol = new String(symBytes, StandardCharsets.UTF_8);

        System.out.printf("  [PubSubService] Order #%d: id=%d, symbol=%s, price=%.2f, qty=%d, side=%c%n",
            globalMessageCount, orderId, symbol, price, quantity, side);

        broadcastToSubscribers(SUB_TYPE_ORDER, buffer, offset, length, "Order");

        sendText(session, String.format(
            "[Order Published #%d] orderId=%d, symbol=%s, subscribers=%d",
            globalMessageCount, orderId, symbol, countSubscribers(SUB_TYPE_ORDER)));
    }

    private void handleUser(
        final ClientSession session,
        final DirectBuffer buffer,
        final int offset,
        final int length,
        final long sessionCount)
    {
        userDecoder.wrapAndApplyHeader(buffer, offset, headerDecoder);

        final long userId    = userDecoder.userId();
        final int age        = userDecoder.age();
        final double balance = userDecoder.balance() / 100.0;

        final int unameLen = userDecoder.usernameLength();
        final byte[] unameBytes = new byte[unameLen];
        userDecoder.getUsername(unameBytes, 0, unameLen);
        final String username = new String(unameBytes, StandardCharsets.UTF_8);

        System.out.printf("  [PubSubService] User #%d: id=%d, username=%s, age=%d, balance=%.2f%n",
            globalMessageCount, userId, username, age, balance);

        broadcastToSubscribers(SUB_TYPE_USER, buffer, offset, length, "User");

        sendText(session, String.format(
            "[User Published #%d] userId=%d, username=%s, subscribers=%d",
            globalMessageCount, userId, username, countSubscribers(SUB_TYPE_USER)));
    }

    private boolean handleCommand(final ClientSession session, final String command)
    {
        if (command.startsWith("SUBSCRIBE "))
        {
            return subscribe(session, command.substring(10).trim());
        }
        else if (command.startsWith("UNSUBSCRIBE "))
        {
            return unsubscribe(session, command.substring(12).trim());
        }
        return false;
    }

    private boolean subscribe(final ClientSession session, final String type)
    {
        final int subType = resolveSubType(type);
        if (subType < 0) return false;

        final List<Integer> subs = subscriptions.get(session.id());
        if (!subs.contains(subType))
        {
            subs.add(subType);
            System.out.println("  [PubSubService] 会话 " + session.id() + " 订阅 " + type);
            sendText(session, "[OK] 已订阅 " + type);
        }
        else
        {
            sendText(session, "[WARN] 已经订阅了 " + type);
        }
        return true;
    }

    private boolean unsubscribe(final ClientSession session, final String type)
    {
        final int subType = resolveSubType(type);
        if (subType < 0) return false;

        subscriptions.get(session.id()).remove(Integer.valueOf(subType));
        System.out.println("  [PubSubService] 会话 " + session.id() + " 取消订阅 " + type);
        sendText(session, "[OK] 已取消订阅 " + type);
        return true;
    }

    private int resolveSubType(final String type)
    {
        if ("ORDER".equalsIgnoreCase(type)) return SUB_TYPE_ORDER;
        if ("USER".equalsIgnoreCase(type))  return SUB_TYPE_USER;
        return -1;
    }

    private void broadcastToSubscribers(
        final int subType,
        final DirectBuffer buffer,
        final int offset,
        final int length,
        final String messageType)
    {
        int delivered = 0;
        for (final ClientSession s : cluster.clientSessions())
        {
            final List<Integer> subs = subscriptions.get(s.id());
            if (subs != null && subs.contains(subType))
            {
                long result;
                int attempts = 0;
                while ((result = s.offer(buffer, offset, length)) < 0 && attempts++ < 3)
                {
                    cluster.idleStrategy().idle();
                }
                if (result > 0) delivered++;
            }
        }
        System.out.println("    [Broadcast] " + messageType + " 已推送给 " + delivered + " 个订阅者");
    }

    private int countSubscribers(final int subType)
    {
        int count = 0;
        for (final List<Integer> subs : subscriptions.values())
        {
            if (subs.contains(subType)) count++;
        }
        return count;
    }

    private void sendText(final ClientSession session, final String message)
    {
        final byte[] bytes = message.getBytes(StandardCharsets.UTF_8);
        sharedBuf.putBytes(0, bytes);
        long result;
        int retries = 0;
        while ((result = session.offer(sharedBuf, 0, bytes.length)) < 0 && retries++ < 3)
        {
            cluster.idleStrategy().idle();
        }
        if (result <= 0)
        {
            System.err.println("    [PubSubService] 回复失败: " + result);
        }
    }
}
