package io.aeron.spring.cluster.model;

/**
 * 业务实体：集群内已处理的 Order 记录。
 * <p>
 * 不可变，用于只读查询和快照序列化。
 */
public final class OrderRecord
{
    private final long   orderId;
    private final String symbol;
    private final long   price;      // 原始 SBE 整数（单位：分）
    private final int    quantity;
    private final char   side;
    private final long   timestamp;

    public OrderRecord(
        final long orderId,
        final String symbol,
        final long price,
        final int quantity,
        final char side,
        final long timestamp)
    {
        this.orderId   = orderId;
        this.symbol    = symbol;
        this.price     = price;
        this.quantity  = quantity;
        this.side      = side;
        this.timestamp = timestamp;
    }

    public long   orderId()   { return orderId; }
    public String symbol()    { return symbol; }
    /** 价格（原始分单位），转为元：price / 100.0 */
    public long   price()     { return price; }
    public int    quantity()  { return quantity; }
    public char   side()      { return side; }
    public long   timestamp() { return timestamp; }

    @Override
    public String toString()
    {
        return String.format("Order{id=%d, symbol=%s, price=%.2f, qty=%d, side=%c, ts=%d}",
            orderId, symbol, price / 100.0, quantity, side, timestamp);
    }
}
