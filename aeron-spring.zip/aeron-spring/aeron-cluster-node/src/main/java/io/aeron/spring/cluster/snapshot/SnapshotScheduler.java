package io.aeron.spring.cluster.snapshot;

import io.aeron.spring.cluster.config.SnapshotProperties;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * 节点侧定时快照调度器。
 *
 * <h3>职责</h3>
 * 仅负责按配置的时间间隔周期性地触发快照请求，
 * 实际快照逻辑委托给 {@link SnapshotService}。
 *
 * <h3>异步设计</h3>
 * {@link io.aeron.cluster.ClusterTool#snapshot} 内部会轮询等待 ConsensusModule 确认（最多 5 秒），
 * 属阻塞调用，<b>不能在 Aeron service 线程上直接调用</b>（会阻塞消息处理）。
 * 因此使用独立单线程池执行，并由 {@link SnapshotService} 负责防止重叠触发。
 */
public class SnapshotScheduler
{
    private final SnapshotService     snapshotService;
    private final SnapshotProperties  snapshotProps;

    /**
     * 单线程调度器：负责定时触发快照任务。
     * ClusterTool.snapshot() 是阻塞调用（最多等待 5 秒），隔离到此线程避免阻塞业务线程。
     */
    private final ScheduledExecutorService scheduler =
        Executors.newSingleThreadScheduledExecutor(r ->
        {
            final Thread t = new Thread(r, "snapshot-scheduler");
            t.setDaemon(true);
            return t;
        });

    public SnapshotScheduler(
        final SnapshotService snapshotService,
        final SnapshotProperties snapshotProps)
    {
        this.snapshotService = snapshotService;
        this.snapshotProps   = snapshotProps;
    }

    @PostConstruct
    public void start()
    {
        final long intervalMs = snapshotProps.getScheduler().getIntervalMs();
        System.out.println("[Snapshot] 定时快照已启用，间隔 " + intervalMs + " ms");

        scheduler.scheduleWithFixedDelay(
            () -> snapshotService.requestSnapshotAsync("定时任务"),
            intervalMs,
            intervalMs,
            TimeUnit.MILLISECONDS);
    }

    @PreDestroy
    public void shutdown()
    {
        scheduler.shutdown();
    }
}
