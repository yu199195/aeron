package io.aeron.spring.cluster.model;

/**
 * 业务实体：集群内已处理的 User 记录。
 * <p>
 * 不可变，用于只读查询和快照序列化。
 */
public final class UserRecord
{
    private final long    userId;
    private final String  username;
    private final String  email;
    private final int     age;
    private final long    balance;   // 原始 SBE 整数（单位：分）
    private final boolean active;

    public UserRecord(
        final long userId,
        final String username,
        final String email,
        final int age,
        final long balance,
        final boolean active)
    {
        this.userId   = userId;
        this.username = username;
        this.email    = email;
        this.age      = age;
        this.balance  = balance;
        this.active   = active;
    }

    public long   userId()   { return userId; }
    public String username() { return username; }
    public String email()    { return email; }
    public int    age()      { return age; }
    /** 余额（原始分单位），转为元：balance / 100.0 */
    public long   balance()  { return balance; }
    public boolean active()  { return active; }

    @Override
    public String toString()
    {
        return String.format("User{id=%d, name=%s, email=%s, age=%d, balance=%.2f, active=%s}",
            userId, username, email, age, balance / 100.0, active);
    }
}
