package io.aeron.spring.cluster.config;

import lombok.Data;

/**
 * ConsensusModule 调优配置，绑定 {@code aeron.cluster.consensus.*}。
 *
 * <h3>ConsensusModule 的职责</h3>
 * ConsensusModule 实现 Raft 共识协议，负责：
 * <ul>
 *   <li>Leader 选举（选举超时 + 投票轮次）</li>
 *   <li>接收 Ingress 消息并写入集群日志（仅 Leader 执行）</li>
 *   <li>向 Follower 同步日志（心跳 + 日志复制）</li>
 *   <li>管理客户端 Session 生命周期（超时断开）</li>
 *   <li>触发并协调快照</li>
 * </ul>
 *
 * <h3>超时参数关系</h3>
 * <pre>
 * leaderHeartbeatTimeout   ← 心跳间隔（Leader 发，Follower 收不到则超时）
 * leaderHeartbeatInterval  ← Leader 发心跳的频率（应 << leaderHeartbeatTimeout）
 * electionTimeout          ← Follower 超过此时间未收到心跳则发起选举
 * sessionTimeout           ← 客户端超过此时间未发任何消息则被断开
 * startupCanvassTimeout    ← 冷启动探测时间，必须是 leaderHeartbeatTimeout 的整数倍
 * </pre>
 * 建议关系：{@code sessionTimeout > leaderHeartbeatTimeout > electionTimeout > leaderHeartbeatInterval}
 * <p>
 * <b>Aeron 1.50.x 强制约束：</b>
 * {@code startupCanvassTimeoutNs % leaderHeartbeatTimeoutNs == 0}，违反则抛出 {@code ClusterException}。
 */
@Data
public class ConsensusProperties
{
    // ── 集群身份 ─────────────────────────────────────────────────────────────

    /**
     * 集群 ID（整数）。
     * <p>
     * 用于区分同一网络中的多个独立集群，防止消息串扰。默认 0。
     */
    private int clusterId = 0;

    /**
     * 预置 Leader 节点 ID。
     * <p>
     * 指定首次启动时优先成为 Leader 的节点。
     * {@code -1} = 不指定（由选举算法决定）。默认 -1。
     */
    private int appointedLeaderId = -1;

    /**
     * 应用版本号（用于滚动升级兼容性校验）。
     * <p>
     * 集群会拒绝与当前版本不兼容的节点加入。默认 0（不校验）。
     */
    private int appVersion = 0;

    // ── Session 与并发 ────────────────────────────────────────────────────────

    /**
     * 客户端 Session 超时时间（纳秒）。
     * <p>
     * 客户端（Sender）若超过此时间未向集群发送任何消息（包括 keep-alive），
     * ConsensusModule 将主动关闭其 Session。
     * <p>
     * cluster-sender 默认每 1 秒发送一次 keep-alive，
     * 因此此值应显著大于 1 秒（keep-alive 间隔）。
     * <ul>
     *   <li>默认：{@code 5000000000}（5 秒）</li>
     *   <li>生产建议：{@code 10000000000}（10 秒）</li>
     * </ul>
     */
    private long sessionTimeoutNs = 5_000_000_000L;

    /**
     * 最大并发客户端 Session 数。
     * <p>
     * 超过此限制后新连接请求将被拒绝。默认 10。
     */
    private int maxConcurrentSessions = 10;

    // ── 心跳与选举 ────────────────────────────────────────────────────────────

    /**
     * Leader 心跳超时时间（纳秒）。
     * <p>
     * Follower 超过此时间未收到 Leader 心跳，则认为 Leader 已失效，
     * 触发新一轮选举。此值是集群感知 Leader 宕机的核心延迟指标。
     * <ul>
     *   <li>默认：{@code 10000000000}（10 秒）</li>
     *   <li>快速故障转移：{@code 2000000000}（2 秒），但会增加误判风险</li>
     * </ul>
     */
    private long leaderHeartbeatTimeoutNs = 10_000_000_000L;

    /**
     * Leader 发送心跳的间隔（纳秒）。
     * <p>
     * Leader 定期向所有 Follower 发送心跳消息，
     * 以阻止 Follower 触发选举超时。
     * 此值应远小于 {@link #leaderHeartbeatTimeoutNs}，建议为其 1/5 到 1/10。
     * <ul>
     *   <li>默认：{@code 200000000}（200 毫秒）</li>
     *   <li>推荐范围：200ms ～ 2s</li>
     * </ul>
     */
    private long leaderHeartbeatIntervalNs = 200_000_000L;

    /**
     * 选举超时时间（纳秒）。
     * <p>
     * 节点在成为候选人（Candidate）后等待投票的最长时间。
     * 超时后放弃本轮，递增 term 后重试。
     * 为避免多节点同时选举形成活锁，实现中会在此基础上加随机抖动。
     * <ul>
     *   <li>默认：{@code 1000000000}（1 秒）</li>
     *   <li>网络延迟较高时可适当调大（如 3 秒）</li>
     * </ul>
     */
    private long electionTimeoutNs = 1_000_000_000L;

    /**
     * 选举状态机状态变更超时（纳秒）。
     * <p>
     * 在选举各阶段（NOMINATE → CANDIDATE_BALLOT → FOLLOWER_REPLAY 等）
     * 等待状态变更的最大时间，超时则回退重试。
     * <ul>
     *   <li>默认：{@code 1000000000}（1 秒）</li>
     * </ul>
     */
    private long electionStatusIntervalNs = 1_000_000_000L;

    /**
     * 启动时集群成员探测超时（纳秒）。
     * <p>
     * 节点启动后在正式参与选举前，先广播探测现有集群成员的等待时间。
     * 若超时后仍未发现足够多的成员，则以已发现的成员组成集群继续启动。
     * 适当调大可降低多节点同时冷启动时因时序差异导致的选举抖动。
     * <p>
     * <b>约束（Aeron 1.50.x）：</b>
     * {@code startupCanvassTimeoutNs} 必须是 {@link #leaderHeartbeatTimeoutNs} 的整数倍：
     * {@code startupCanvassTimeoutNs % leaderHeartbeatTimeoutNs == 0}。
     * 默认值 {@code 20_000_000_000}（20 秒）= 2 × 默认 leaderHeartbeatTimeoutNs（10 秒）。
     * <p>
     * 调整 leaderHeartbeatTimeoutNs 时须同步调整此值。
     */
    private long startupCanvassTimeoutNs = 20_000_000_000L;

    /**
     * 优雅关闭超时时间（纳秒）。
     * <p>
     * 节点收到 {@code terminationHook} 信号后，等待所有在途消息提交完成的最长时间。
     * 超时后强制关闭。默认：{@code 5000000000}（5 秒）。
     */
    private long terminationTimeoutNs = 5_000_000_000L;

    // ── 定时器轮 ─────────────────────────────────────────────────────────────

    /**
     * 定时器轮（Timer Wheel）的 tick 分辨率（纳秒）。
     * <p>
     * 决定了集群内部定时器（如 Session 超时、心跳）的最小精度。
     * 越小精度越高，但 CPU 开销越大。默认 8ms（8_000_000）。
     */
    private long wheelTickResolutionNs = 8_000_000L;

    /**
     * 定时器轮每圈的 tick 数（槽数）。
     * <p>
     * 定时器轮的总时间范围 = {@link #wheelTickResolutionNs} × ticksPerWheel。
     * 必须是 2 的幂次。默认 128（总范围约 1 秒）。
     */
    private int ticksPerWheel = 128;

    // ── 消息处理 ─────────────────────────────────────────────────────────────

    /**
     * 每次 duty-cycle 从 Ingress 通道读取的最大消息片段数。
     * <p>
     * 控制每轮处理的 Ingress 消息量，避免单次处理占用过长时间。默认 50。
     */
    private int ingressFragmentLimit = 50;

    /**
     * 每次 duty-cycle 从日志（Log）通道读取的最大消息片段数。
     * <p>
     * 控制日志复制时每轮处理的消息量。默认 100。
     */
    private int logFragmentLimit = 100;

    // ── Duty Cycle 监控 ───────────────────────────────────────────────────────

    /**
     * ConsensusModule duty-cycle 超过此时间（纳秒）则记录告警。
     * <p>
     * 用于检测 GC 停顿或其他导致 ConsensusModule 线程阻塞的问题。默认 1 秒。
     */
    private long cycleThresholdNs = 1_000_000_000L;

    /**
     * 单次快照操作总时长超过此阈值（纳秒）时记录告警。
     * <p>
     * 帮助识别快照操作过慢的问题（可能影响集群可用性）。默认 1 秒。
     */
    private long totalSnapshotDurationThresholdNs = 1_000_000_000L;

    // ── 持久化 ───────────────────────────────────────────────────────────────

    /**
     * 集群元数据文件（recording log、mark file）的磁盘同步级别。
     * <ul>
     *   <li>{@code 0} - 异步刷盘（默认）</li>
     *   <li>{@code 1} - fdatasync</li>
     *   <li>{@code 2} - fsync（最安全）</li>
     * </ul>
     */
    private int fileSyncLevel = 0;

    // ── 错误缓冲区 ────────────────────────────────────────────────────────────

    /**
     * 错误日志缓冲区大小（字节）。
     * <p>
     * ConsensusModule 内部记录错误事件的环形缓冲区（{@link org.agrona.concurrent.ringbuffer.ManyToOneRingBuffer}）。
     * agrona 2.x 中 TRAILER_LENGTH = 768，要求容量为 {@code 2^n + 768}，如 1_049_344、2_097_920。
     */
    private int errorBufferLength = 1_049_344; // 2^20 + 768
}
