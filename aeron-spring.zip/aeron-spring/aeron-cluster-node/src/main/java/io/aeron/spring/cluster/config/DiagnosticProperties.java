package io.aeron.spring.cluster.config;

import lombok.Data;

/**
 * 集群诊断日志配置，绑定 {@code aeron.cluster.diagnostic.*}。
 *
 * <p>控制 {@link io.aeron.spring.cluster.startup.ClusterDiagnosticLogger} 的行为：
 * 是否启用后台日志线程、输出频率、稳定后的降频倍数。
 */
@Data
public class DiagnosticProperties
{
    /**
     * 是否启用集群诊断日志后台线程。
     * <p>
     * {@code true}（默认）：节点启动后自动开启后台线程，周期性打印选举状态到控制台。
     * {@code false}：完全关闭，不占用任何资源。
     */
    private boolean enabled = true;

    /**
     * 轮询间隔（毫秒）。
     * <p>
     * 后台线程每隔此时间读取一次 cnc.dat 并输出诊断行。默认（100 秒）。
     */
    private long intervalMs = 100_000L;

    /**
     * 稳定判定阈值（连续次数）。
     * <p>
     * 当连续 N 次都满足"稳定条件"（{@code cmState=ACTIVE} 且 {@code electionState=CLOSED}）
     * 后，输出频率降为每 {@link #quietIntervalMultiplier} × {@link #intervalMs} 一次，
     * 避免集群正常运行时产生过多日志。默认 5 次。
     */
    private int stableThreshold = 5;

    /**
     * 稳定后的输出降频倍数。
     * <p>
     * 达到稳定阈值后，每 N 次轮询才输出一行（实际间隔 = intervalMs × quietIntervalMultiplier）。
     * 默认 5（即稳定后约每 10 秒输出一次）。
     */
    private int quietIntervalMultiplier = 5;
}
