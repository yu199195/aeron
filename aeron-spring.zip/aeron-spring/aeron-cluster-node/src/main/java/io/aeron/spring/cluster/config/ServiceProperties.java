package io.aeron.spring.cluster.config;

import lombok.Data;

/**
 * 集群服务类型配置，绑定 aeron.cluster.service.* 前缀。
 */
@Data
public class ServiceProperties
{
    /**
     * 集群服务实现类型。
     * <ul>
     *   <li>{@code simple}（默认）：存储 Order/User 业务数据，支持完整快照</li>
     *   <li>{@code forwarding}：将消息转发到外部 Aeron 订阅者</li>
     *   <li>{@code pubsub}：基于订阅命令的消息广播</li>
     * </ul>
     * 对应 application.yml 中 {@code aeron.cluster.service.type}。
     */
    private String type = "simple";
}
