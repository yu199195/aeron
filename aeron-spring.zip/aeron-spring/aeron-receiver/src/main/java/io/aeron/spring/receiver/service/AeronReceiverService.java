package io.aeron.spring.receiver.service;

import io.aeron.Aeron;
import io.aeron.Subscription;
import io.aeron.driver.MediaDriver;
import io.aeron.logbuffer.FragmentHandler;
import io.aeron.spring.cluster.config.ContextFactory;
import io.aeron.spring.receiver.config.AeronReceiverProperties;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.agrona.CloseHelper;
import org.agrona.concurrent.SleepingIdleStrategy;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.BiConsumer;

/**
 * Spring Service：封装 Aeron Subscription 的持续接收逻辑。
 *
 * <h3>线程模型</h3>
 * <p>与 DemoReceiver 一致：启动一个独立的 <em>poll 线程</em>持续调用
 * {@link Subscription#poll(FragmentHandler, int)}，将收到的 fragment 以回调形式
 * 通知注册的监听器（{@link #addListener}）。
 * 应用层可通过监听器接口消费消息，也可通过 {@link #getRecentMessages} 查询最近收到的消息。
 *
 * <h3>模式切换</h3>
 * <p>通过 {@code aeron.receiver.mode=udp|ipc} 配置项选择传输模式：
 * <ul>
 *   <li><b>udp</b> — {@code aeron:udp?endpoint=host:port}，监听本地端口</li>
 *   <li><b>ipc</b> — {@code aeron:ipc}，同机共享内存订阅</li>
 * </ul>
 */
@Service
public class AeronReceiverService
{
    /** 内存中保留的最近消息条数上限 */
    private static final int RECENT_MESSAGE_LIMIT = 100;

    private final AeronReceiverProperties props;

    private MediaDriver  mediaDriver;
    private Aeron        aeron;
    private Subscription subscription;

    private Thread           pollThread;
    private volatile boolean running = false;

    private final AtomicLong receivedCount = new AtomicLong(0);

    /** 线程安全的消息监听器列表，便于外部注册回调 */
    private final CopyOnWriteArrayList<BiConsumer<String, byte[]>> listeners = new CopyOnWriteArrayList<>();

    /** 最近收到的消息（循环队列语义，最多 RECENT_MESSAGE_LIMIT 条） */
    private final CopyOnWriteArrayList<ReceivedMessage> recentMessages = new CopyOnWriteArrayList<>();

    public AeronReceiverService(final AeronReceiverProperties props)
    {
        this.props = props;
    }

    // ──────────────────────────────────────────────
    // 生命周期
    // ──────────────────────────────────────────────

    @PostConstruct
    public void start()
    {
        final String channel  = props.resolveChannel();
        final int    streamId = props.resolveStreamId();

        System.out.println("[AeronReceiver] mode=" + props.getMode()
            + "  channel=" + channel + "  streamId=" + streamId);

        mediaDriver  = MediaDriver.launch(ContextFactory.mediaDriverContext(props.getMediaDriver()));
        aeron        = Aeron.connect(ContextFactory.aeronContext(props.getAeron(), mediaDriver.aeronDirectoryName()));
        subscription = aeron.addSubscription(channel, streamId);

        System.out.println("[AeronReceiver] Subscription created, channel=" + channel);
        startPollThread();
    }

    @PreDestroy
    public void stop()
    {
        System.out.println("[AeronReceiver] Stopping...");
        running = false;
        if (pollThread != null)
        {
            pollThread.interrupt();
        }
        CloseHelper.closeAll(subscription, aeron, mediaDriver);
    }

    // ──────────────────────────────────────────────
    // 公开接口
    // ──────────────────────────────────────────────

    /**
     * 注册消息监听器。
     *
     * @param listener {@code (text, rawBytes) -> ...}，在 poll 线程中调用
     */
    public void addListener(final BiConsumer<String, byte[]> listener)
    {
        listeners.add(listener);
    }

    /** 返回最近收到的消息列表（最多 {@value #RECENT_MESSAGE_LIMIT} 条） */
    public List<ReceivedMessage> getRecentMessages()
    {
        return new ArrayList<>(recentMessages);
    }

    /** 返回当前状态快照 */
    public ReceiverStatus status()
    {
        final Subscription sub = subscription;
        if (sub == null || sub.isClosed())
        {
            return new ReceiverStatus(false, props.getMode(), props.resolveChannel(),
                props.resolveStreamId(), 0, receivedCount.get());
        }
        return new ReceiverStatus(true, props.getMode(), props.resolveChannel(),
            props.resolveStreamId(), sub.imageCount(), receivedCount.get());
    }

    // ──────────────────────────────────────────────
    // poll 线程
    // ──────────────────────────────────────────────

    private void startPollThread()
    {
        running    = true;
        pollThread = new Thread(this::pollLoop, "aeron-receiver-poll");
        pollThread.setDaemon(true);
        pollThread.start();
        System.out.println("[AeronReceiver] Poll thread started");
    }

    /**
     * Poll 主循环，与 DemoReceiver 逻辑一致：
     * <ol>
     *   <li>调用 {@link Subscription#poll} 拉取 fragment</li>
     *   <li>通过 FragmentHandler 回调解码消息，通知监听器</li>
     *   <li>空闲时 SleepingIdleStrategy 休眠 1ms 节省 CPU</li>
     * </ol>
     */
    private void pollLoop()
    {
        /*
         * SleepingIdleStrategy(1ms)：fragment 数为 0 时休眠 1ms。
         * 演示配置，低延迟场景可换 BusySpinIdleStrategy 或 BackoffIdleStrategy。
         */
        final SleepingIdleStrategy idle = new SleepingIdleStrategy(TimeUnit.MILLISECONDS.toNanos(1));

        final FragmentHandler handler = (buffer, offset, length, header) ->
        {
            /*
             * fragment 回调：buffer 是 termBuffer 视图，offset 跳过 32 字节帧头。
             * 这里简单 copy 为 byte[]，生产环境应复用 buffer 避免分配。
             */
            final byte[] bytes   = new byte[length];
            buffer.getBytes(offset, bytes);
            final String text = new String(bytes, StandardCharsets.UTF_8);

            receivedCount.incrementAndGet();
            System.out.println("[AeronReceiver] Received: " + text);

            // 保留最近消息（超出上限时移除最旧的）
            if (recentMessages.size() >= RECENT_MESSAGE_LIMIT)
            {
                recentMessages.remove(0);
            }
            recentMessages.add(new ReceivedMessage(text, bytes, System.currentTimeMillis()));

            // 通知所有注册的监听器
            for (final BiConsumer<String, byte[]> listener : listeners)
            {
                try
                {
                    listener.accept(text, bytes);
                }
                catch (final Exception e)
                {
                    System.err.println("[AeronReceiver] Listener error: " + e.getMessage());
                }
            }
        };

        while (running && !Thread.currentThread().isInterrupted())
        {
            final int fragmentsRead = subscription.poll(handler, props.getFragmentLimit());
            idle.idle(fragmentsRead);
        }
    }

    // ──────────────────────────────────────────────
    // 内部类型
    // ──────────────────────────────────────────────

    public record ReceivedMessage(String text, byte[] rawBytes, long timestampMs) {}

    public record ReceiverStatus(
        boolean connected,
        String  mode,
        String  channel,
        int     streamId,
        int     imageCount,
        long    receivedCount) {}
}
