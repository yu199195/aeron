package io.aeron.spring.receiver.config;

import io.aeron.spring.cluster.config.AeronContextProperties;
import io.aeron.spring.cluster.config.MediaDriverProperties;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.stereotype.Component;

/**
 * aeron.receiver.* 配置映射。
 *
 * <p>支持两种模式：
 * <ul>
 *   <li>{@code udp} — UDP 单播订阅，需配置本地监听 endpoint（host:port）</li>
 *   <li>{@code ipc} — 进程内共享内存订阅，无需网络</li>
 * </ul>
 */
@Data
@Component
@ConfigurationProperties(prefix = "aeron.receiver")
public class AeronReceiverProperties
{
    /** 传输模式，取值 "udp" 或 "ipc" */
    private String mode = "udp";

    private Udp udp          = new Udp();
    private Ipc ipc          = new Ipc();
    private int fragmentLimit = 10;

    @NestedConfigurationProperty
    private MediaDriverProperties mediaDriver = new MediaDriverProperties();

    @NestedConfigurationProperty
    private AeronContextProperties aeron = new AeronContextProperties();

    /** 根据当前模式返回 Aeron channel 字符串 */
    public String resolveChannel()
    {
        if ("ipc".equalsIgnoreCase(mode))
        {
            return "aeron:ipc";
        }
        return "aeron:udp?endpoint=" + udp.getEndpoint();
    }

    /** 根据当前模式返回 streamId */
    public int resolveStreamId()
    {
        if ("ipc".equalsIgnoreCase(mode))
        {
            return ipc.getStreamId();
        }
        return udp.getStreamId();
    }

    // ── 内嵌配置类 ──────────────────────────────────────────────────────────

    @Data
    public static class Udp
    {
        private String endpoint = "localhost:40123";
        private int    streamId = 10;
    }

    @Data
    public static class Ipc
    {
        private int streamId = 20;
    }
}
