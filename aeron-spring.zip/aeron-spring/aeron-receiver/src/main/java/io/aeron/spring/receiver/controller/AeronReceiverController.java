package io.aeron.spring.receiver.controller;

import io.aeron.spring.receiver.service.AeronReceiverService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * REST API：查询 Aeron Subscription 状态和最近收到的消息。
 *
 * <pre>
 * GET /status    查询 Subscription 状态（模式、channel、已收消息数等）
 * GET /messages  查询最近收到的消息列表（最多 100 条）
 * </pre>
 */
@RestController
public class AeronReceiverController
{
    private final AeronReceiverService receiverService;

    public AeronReceiverController(final AeronReceiverService receiverService)
    {
        this.receiverService = receiverService;
    }

    /**
     * 查询 Subscription 状态。
     *
     * <p>请求示例：
     * <pre>
     * curl http://localhost:7081/status
     * </pre>
     */
    @GetMapping("/status")
    public ResponseEntity<AeronReceiverService.ReceiverStatus> status()
    {
        return ResponseEntity.ok(receiverService.status());
    }

    /**
     * 查询最近收到的消息列表。
     *
     * <p>请求示例：
     * <pre>
     * curl http://localhost:7081/messages
     * </pre>
     */
    @GetMapping("/messages")
    public ResponseEntity<List<AeronReceiverService.ReceivedMessage>> messages()
    {
        return ResponseEntity.ok(receiverService.getRecentMessages());
    }
}
