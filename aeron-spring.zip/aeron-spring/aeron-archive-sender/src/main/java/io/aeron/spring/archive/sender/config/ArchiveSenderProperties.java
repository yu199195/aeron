package io.aeron.spring.archive.sender.config;

import io.aeron.spring.cluster.config.AeronContextProperties;
import io.aeron.spring.cluster.config.ArchiveProperties;
import io.aeron.spring.cluster.config.MediaDriverProperties;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.stereotype.Component;

/**
 * {@code aeron.archive.sender.*} 配置映射。
 *
 * <p>核心参数说明：
 * <ul>
 *   <li>{@code channel} / {@code streamId} — 业务 Publication 的 UDP 通道和流 ID，
 *       Archive 通过 spy 方式录制同一条流。</li>
 *   <li>{@code controlRequestChannel} — Archive 服务监听的控制端口，
 *       {@link io.aeron.archive.receiver.service.ArchiveReceiverService} 通过此地址连接。</li>
 *   <li>{@code archiveDir} — 录制数据落盘目录；空字符串时使用
 *       {@code java.io.tmpdir/aeron-archive-sender}。</li>
 * </ul>
 */
@Data
@Component
@ConfigurationProperties(prefix = "aeron.archive.sender")
public class ArchiveSenderProperties
{
    private String channel               = "aeron:udp?endpoint=localhost:40456";
    private int    streamId              = 10;
    private String controlRequestChannel  = "aeron:udp?endpoint=localhost:8010";
    private String controlResponseChannel = "aeron:udp?endpoint=localhost:0";
    private String replicationChannel    = "aeron:udp?endpoint=localhost:0";
    private String archiveDir            = "";

    @NestedConfigurationProperty
    private MediaDriverProperties mediaDriver = new MediaDriverProperties();

    @NestedConfigurationProperty
    private ArchiveProperties archive = new ArchiveProperties();

    @NestedConfigurationProperty
    private AeronContextProperties aeron = new AeronContextProperties();
}
