package io.aeron.spring.archive.sender;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

/**
 * Aeron Archive Sender Spring Boot 启动类。
 *
 * <p>启动后：
 * <ul>
 *   <li>内嵌 {@link io.aeron.archive.ArchivingMediaDriver}（MediaDriver + Archive）</li>
 *   <li>通过 REST {@code POST /send} 发送消息，Archive 自动 spy 录制到本地磁盘</li>
 *   <li>Archive 控制端口持续对外开放，供 {@code aeron-archive-receiver} 连接回放</li>
 * </ul>
 */
@SpringBootApplication
@EnableConfigurationProperties
public class AeronArchiveSenderApplication
{
    public static void main(final String[] args)
    {
        SpringApplication.run(AeronArchiveSenderApplication.class, args);
    }
}
