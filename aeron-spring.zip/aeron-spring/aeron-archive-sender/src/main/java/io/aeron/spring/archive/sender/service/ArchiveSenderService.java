package io.aeron.spring.archive.sender.service;

import io.aeron.Aeron;
import io.aeron.Publication;
import io.aeron.archive.ArchivingMediaDriver;
import io.aeron.archive.client.AeronArchive;
import io.aeron.archive.codecs.SourceLocation;
import io.aeron.archive.status.RecordingPos;
import io.aeron.spring.archive.sender.config.ArchiveSenderProperties;
import io.aeron.spring.cluster.config.ContextFactory;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.agrona.BitUtil;
import org.agrona.BufferUtil;
import org.agrona.CloseHelper;
import org.agrona.concurrent.BackoffIdleStrategy;
import org.agrona.concurrent.UnsafeBuffer;
import org.agrona.concurrent.status.CountersReader;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Spring Service：封装带 Archive 录制功能的 Aeron Publication。
 *
 * <h3>启动流程（对应 ArchiveSender demo）</h3>
 * <ol>
 *   <li>启动 {@link ArchivingMediaDriver}（MediaDriver + Archive 一体化）</li>
 *   <li>通过 {@link AeronArchive} 客户端连接本地 Archive，调用
 *       {@code startRecording(channel, streamId, LOCAL)} 注册 spy 录制</li>
 *   <li>创建 {@link Publication}，等待 {@link RecordingPos} 计数器出现，确认 Archive 已开始录盘</li>
 *   <li>启动 duty-cycle 线程，消费 HTTP 线程提交的待发消息</li>
 * </ol>
 *
 * <h3>线程模型</h3>
 * <p>与 DemoSender / ClusterSenderService 一致：duty-cycle 线程独占访问 Publication，
 * HTTP 线程通过 {@link LinkedBlockingQueue} + {@link CompletableFuture} 提交消息并等待结果。
 *
 * <h3>录制说明</h3>
 * <p>{@code SourceLocation.LOCAL} spy 方式：Archive 在同一进程内直接读取 term buffer，
 * 不经过网络，需配合 {@code driverCtx.spiesSimulateConnection(true)} 使 Publication 不会
 * 长期处于 {@code NOT_CONNECTED} 状态。
 */
@Service
public class ArchiveSenderService
{
    private static final int  MAX_MESSAGE_BYTES = 4096;
    private static final long SEND_TIMEOUT_SEC  = 5;

    private final ArchiveSenderProperties props;

    private ArchivingMediaDriver archivingDriver;
    private Aeron                aeron;
    private AeronArchive         aeronArchive;
    private Publication          publication;

    private volatile long    recordingId  = -1;
    private final AtomicLong sentCount    = new AtomicLong(0);

    private Thread           dutyCycleThread;
    private volatile boolean running = false;

    private final LinkedBlockingQueue<PendingMessage> sendQueue = new LinkedBlockingQueue<>();

    public ArchiveSenderService(final ArchiveSenderProperties props)
    {
        this.props = props;
    }

    // ──────────────────────────────────────────────
    // 生命周期
    // ──────────────────────────────────────────────

    @PostConstruct
    public void start()
    {
        System.out.println("[ArchiveSender] channel=" + props.getChannel()
            + "  streamId=" + props.getStreamId());
        System.out.println("[ArchiveSender] controlRequestChannel=" + props.getControlRequestChannel());

        final String dir = props.getArchiveDir() == null || props.getArchiveDir().isBlank()
            ? new java.io.File(System.getProperty("java.io.tmpdir"), "aeron-archive-sender").getAbsolutePath()
            : props.getArchiveDir();

        // 1. 启动 ArchivingMediaDriver（MediaDriver + Archive 一体）
        archivingDriver = ArchivingMediaDriver.launch(
            ContextFactory.mediaDriverContext(props.getMediaDriver())
                .spiesSimulateConnection(true)
                .errorHandler(Throwable::printStackTrace),
            ContextFactory.archiveContext(props.getArchive())
                .archiveDir(new java.io.File(dir))
                .controlChannel(props.getControlRequestChannel())
                .replicationChannel(props.getReplicationChannel())
                .recordingEventsEnabled(false)
                .deleteArchiveOnStart(true));

        // 2. 连接 Aeron Client + AeronArchive Client（同进程，通过 IPC 交互）
        aeron = Aeron.connect(ContextFactory.aeronContext(
            props.getAeron(), archivingDriver.mediaDriver().aeronDirectoryName()));

        aeronArchive = AeronArchive.connect(new AeronArchive.Context()
            .controlRequestChannel(props.getControlRequestChannel())
            .controlResponseChannel(props.getControlResponseChannel())
            .aeron(aeron));

        // 3. 注册 spy 录制：Archive 会在 publication 建立后自动开始写盘
        aeronArchive.startRecording(props.getChannel(), props.getStreamId(), SourceLocation.LOCAL);

        // 4. 创建 Publication，等待 RecordingPos 计数器出现（确认 Archive 录制已激活）
        publication = aeron.addPublication(props.getChannel(), props.getStreamId());
        waitForRecordingStart();

        System.out.println("[ArchiveSender] Recording started: recordingId=" + recordingId);
        startDutyCycle();
    }

    @PreDestroy
    public void stop()
    {
        System.out.println("[ArchiveSender] Stopping...");
        running = false;
        if (dutyCycleThread != null)
        {
            dutyCycleThread.interrupt();
        }

        // 等待 Archive 追上 publication position，再停止录制
        if (publication != null && !publication.isClosed() && aeronArchive != null)
        {
            try
            {
                drainRecording();
                aeronArchive.stopRecording(props.getChannel(), props.getStreamId());
                System.out.println("[ArchiveSender] Recording stopped: recordingId=" + recordingId);
            }
            catch (final Exception e)
            {
                System.err.println("[ArchiveSender] stopRecording error: " + e.getMessage());
            }
        }

        CloseHelper.closeAll(publication, aeronArchive, aeron, archivingDriver);
    }

    // ──────────────────────────────────────────────
    // 公开接口（HTTP 线程调用）
    // ──────────────────────────────────────────────

    /**
     * 发送文本消息（UTF-8），同时由 Archive spy 录制到磁盘。
     *
     * @param text 消息内容
     * @return publication position（正数）
     */
    public long send(final String text)
    {
        final byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        if (bytes.length > MAX_MESSAGE_BYTES)
        {
            throw new IllegalArgumentException(
                "Message too large: " + bytes.length + " > " + MAX_MESSAGE_BYTES + " bytes");
        }
        final long pos = submitAndWait(bytes);
        sentCount.incrementAndGet();
        return pos;
    }

    /** 查询当前状态（HTTP 线程安全） */
    public SenderStatus status()
    {
        final Publication pub = publication;
        return new SenderStatus(
            pub != null && !pub.isClosed(),
            props.getChannel(),
            props.getStreamId(),
            recordingId,
            sentCount.get(),
            pub != null ? pub.sessionId() : -1,
            pub != null && pub.isConnected());
    }

    // ──────────────────────────────────────────────
    // duty-cycle 线程
    // ──────────────────────────────────────────────

    private void startDutyCycle()
    {
        running         = true;
        dutyCycleThread = new Thread(this::dutyCycle, "aeron-archive-sender-duty-cycle");
        dutyCycleThread.setDaemon(true);
        dutyCycleThread.start();
        System.out.println("[ArchiveSender] DutyCycle thread started");
    }

    /**
     * Duty-cycle 主循环：独占访问 {@link Publication}，逻辑与 ArchiveSender demo 一致。
     *
     * <p>offer 结果处理：
     * <ul>
     *   <li>正数 — 成功写入 term buffer，Archive spy 会异步录盘</li>
     *   <li>{@link Publication#BACK_PRESSURED} — 流控限制，idle 后重试</li>
     *   <li>{@link Publication#NOT_CONNECTED}  — 等待订阅者就绪（spy 已由 spiesSimulateConnection 模拟）</li>
     *   <li>{@link Publication#ADMIN_ACTION}   — Driver 内部管理动作，下轮重试</li>
     *   <li>{@link Publication#CLOSED} / {@link Publication#MAX_POSITION_EXCEEDED} — 异常通知调用方</li>
     * </ul>
     */
    private void dutyCycle()
    {
        final BackoffIdleStrategy idle   = new BackoffIdleStrategy();
        final UnsafeBuffer         buffer = new UnsafeBuffer(
            BufferUtil.allocateDirectAligned(MAX_MESSAGE_BYTES, BitUtil.CACHE_LINE_LENGTH));

        while (running && !Thread.currentThread().isInterrupted())
        {
            int workCount = 0;

            final PendingMessage msg = sendQueue.peek();
            if (msg != null)
            {
                buffer.putBytes(0, msg.bytes());
                final long result = publication.offer(buffer, 0, msg.bytes().length);

                if (result > 0)
                {
                    sendQueue.poll();
                    msg.future().complete(result);
                    workCount++;
                }
                else if (result == Publication.CLOSED || result == Publication.MAX_POSITION_EXCEEDED)
                {
                    sendQueue.poll();
                    msg.future().completeExceptionally(
                        new IllegalStateException("[ArchiveSender] offer failed: code=" + result));
                }
                // BACK_PRESSURED / NOT_CONNECTED / ADMIN_ACTION：留队列，下次循环重试
            }

            idle.idle(workCount);
        }
    }

    // ──────────────────────────────────────────────
    // 私有工具
    // ──────────────────────────────────────────────

    /**
     * 等待 Archive RecordingPos 计数器出现，确认 spy 录制已激活（对应 ArchiveSender demo 的轮询逻辑）。
     * RecordingPos 计数器由 ArchiveConductor 在 AvailableImageHandler 回调中创建，
     * 需要 Publication 建立后才会触发。
     */
    private void waitForRecordingStart()
    {
        final CountersReader counters = aeron.countersReader();
        final long           archiveId = aeronArchive.archiveId();
        int counterId;

        while (CountersReader.NULL_COUNTER_ID ==
            (counterId = RecordingPos.findCounterIdBySession(counters, publication.sessionId(), archiveId)))
        {
            Thread.yield();
        }

        recordingId = RecordingPos.getRecordingId(counters, counterId);
    }

    /**
     * 关闭前等待 Archive 计数器追上 publication.position()，确保数据已全部落盘。
     * 逻辑与 ArchiveSender demo 的"等待写入完成"段一致。
     */
    private void drainRecording()
    {
        if (recordingId < 0)
        {
            return;
        }
        final CountersReader counters  = aeron.countersReader();
        final long           archiveId = aeronArchive.archiveId();
        final int            counterId = RecordingPos.findCounterIdBySession(
            counters, publication.sessionId(), archiveId);

        if (counterId == CountersReader.NULL_COUNTER_ID)
        {
            return;
        }

        final long targetPosition = publication.position();
        while (counters.getCounterValue(counterId) < targetPosition)
        {
            if (!RecordingPos.isActive(counters, counterId, recordingId))
            {
                break;
            }
            Thread.yield();
        }
    }

    private long submitAndWait(final byte[] bytes)
    {
        final CompletableFuture<Long> future = new CompletableFuture<>();
        sendQueue.offer(new PendingMessage(bytes, future));
        try
        {
            return future.get(SEND_TIMEOUT_SEC, TimeUnit.SECONDS);
        }
        catch (final Exception e)
        {
            future.cancel(false);
            throw new IllegalStateException("[ArchiveSender] Send timed out or interrupted", e);
        }
    }

    // ──────────────────────────────────────────────
    // 内部类型
    // ──────────────────────────────────────────────

    private record PendingMessage(byte[] bytes, CompletableFuture<Long> future) {}

    public record SenderStatus(
        boolean connected,
        String  channel,
        int     streamId,
        long    recordingId,
        long    sentCount,
        int     sessionId,
        boolean isConnected) {}
}
