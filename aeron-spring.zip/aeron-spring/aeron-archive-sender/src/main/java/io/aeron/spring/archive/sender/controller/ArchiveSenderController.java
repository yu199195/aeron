package io.aeron.spring.archive.sender.controller;

import io.aeron.spring.archive.sender.service.ArchiveSenderService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * REST API：向 Aeron Archive 发送并录制消息。
 *
 * <pre>
 * POST /send     body: { "text": "hello" }   发送消息（同时由 Archive spy 录制）
 * GET  /status                                查询 Publication 和录制状态
 * </pre>
 */
@RestController
public class ArchiveSenderController
{
    private final ArchiveSenderService senderService;

    public ArchiveSenderController(final ArchiveSenderService senderService)
    {
        this.senderService = senderService;
    }

    /**
     * 发送并录制文本消息。
     *
     * <p>请求示例：
     * <pre>
     * curl -X POST http://localhost:7082/send \
     *      -H 'Content-Type: application/json' \
     *      -d '{"text":"hello archive"}'
     * </pre>
     */
    @PostMapping("/send")
    public ResponseEntity<Map<String, Object>> send(@RequestBody final Map<String, String> body)
    {
        final String text = body.get("text");
        if (text == null || text.isBlank())
        {
            return ResponseEntity.badRequest().body(Map.of("error", "field 'text' is required"));
        }

        try
        {
            final long position = senderService.send(text);
            return ResponseEntity.ok(Map.of(
                "success",  true,
                "position", position,
                "bytes",    text.getBytes(StandardCharsets.UTF_8).length
            ));
        }
        catch (final IllegalArgumentException e)
        {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
        catch (final IllegalStateException e)
        {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * 查询 Publication 和 Archive 录制状态。
     *
     * <p>请求示例：
     * <pre>
     * curl http://localhost:7082/status
     * </pre>
     */
    @GetMapping("/status")
    public ResponseEntity<ArchiveSenderService.SenderStatus> status()
    {
        return ResponseEntity.ok(senderService.status());
    }
}
