package io.aeron.spring.sender.controller;

import io.aeron.spring.sender.service.AeronSenderService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * REST API：向 Aeron Publication 发送消息。
 *
 * <pre>
 * POST /send          body: { "text": "hello" }    发送文本消息
 * GET  /status                                      查询 Publication 状态
 * </pre>
 */
@RestController
public class AeronSenderController
{
    private final AeronSenderService senderService;

    public AeronSenderController(final AeronSenderService senderService)
    {
        this.senderService = senderService;
    }

    /**
     * 发送文本消息。
     *
     * <p>请求示例：
     * <pre>
     * curl -X POST http://localhost:7080/send \
     *      -H 'Content-Type: application/json' \
     *      -d '{"text":"hello aeron"}'
     * </pre>
     */
    @PostMapping("/send")
    public ResponseEntity<Map<String, Object>> send(@RequestBody final Map<String, String> body)
    {
        final String text = body.get("text");
        if (text == null || text.isBlank())
        {
            return ResponseEntity.badRequest().body(Map.of("error", "field 'text' is required"));
        }

        try
        {
            final long position = senderService.send(text);
            return ResponseEntity.ok(Map.of(
                "success",  true,
                "position", position,
                "bytes",    text.getBytes(java.nio.charset.StandardCharsets.UTF_8).length
            ));
        }
        catch (final IllegalArgumentException e)
        {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
        catch (final IllegalStateException e)
        {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * 查询当前 Publication 连接状态。
     *
     * <p>请求示例：
     * <pre>
     * curl http://localhost:7080/status
     * </pre>
     */
    @GetMapping("/status")
    public ResponseEntity<AeronSenderService.SenderStatus> status()
    {
        return ResponseEntity.ok(senderService.status());
    }
}
