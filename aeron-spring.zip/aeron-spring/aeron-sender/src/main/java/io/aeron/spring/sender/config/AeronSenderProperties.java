package io.aeron.spring.sender.config;

import io.aeron.spring.cluster.config.AeronContextProperties;
import io.aeron.spring.cluster.config.MediaDriverProperties;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.stereotype.Component;

/**
 * aeron.sender.* 配置映射。
 *
 * <p>支持两种模式：
 * <ul>
 *   <li>{@code udp}  — 通过 UDP 单播发送，需配置 endpoint（host:port）和 streamId</li>
 *   <li>{@code ipc}  — 进程内共享内存传输，无需网络，需配置 streamId</li>
 * </ul>
 */
@Data
@Component
@ConfigurationProperties(prefix = "aeron.sender")
public class AeronSenderProperties
{
    /** 传输模式，取值 "udp" 或 "ipc" */
    private String mode = "udp";

    private Udp udp = new Udp();
    private Ipc ipc = new Ipc();

    @NestedConfigurationProperty
    private MediaDriverProperties mediaDriver = new MediaDriverProperties();

    @NestedConfigurationProperty
    private AeronContextProperties aeron = new AeronContextProperties();

    /** 根据当前模式返回 Aeron channel 字符串 */
    public String resolveChannel()
    {
        if ("ipc".equalsIgnoreCase(mode))
        {
            return "aeron:ipc";
        }
        return "aeron:udp?endpoint=" + udp.getEndpoint();
    }

    /** 根据当前模式返回 streamId */
    public int resolveStreamId()
    {
        if ("ipc".equalsIgnoreCase(mode))
        {
            return ipc.getStreamId();
        }
        return udp.getStreamId();
    }

    // ── 内嵌配置类 ──────────────────────────────────────────────────────────

    @Data
    public static class Udp
    {
        private String endpoint = "localhost:40123";
        private int    streamId = 10;
    }

    @Data
    public static class Ipc
    {
        private int streamId = 20;
    }
}
