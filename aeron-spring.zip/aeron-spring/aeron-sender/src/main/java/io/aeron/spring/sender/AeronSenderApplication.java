package io.aeron.spring.sender;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

/**
 * Aeron Sender Spring Boot 启动类。
 *
 * <p>通过 {@code application.yml} 中的 {@code aeron.sender.mode} 选择传输模式：
 * <ul>
 *   <li>{@code udp} — UDP 单播，跨进程/跨机器</li>
 *   <li>{@code ipc} — 共享内存，同机进程间</li>
 * </ul>
 */
@SpringBootApplication
@EnableConfigurationProperties
public class AeronSenderApplication
{
    public static void main(final String[] args)
    {
        SpringApplication.run(AeronSenderApplication.class, args);
    }
}
