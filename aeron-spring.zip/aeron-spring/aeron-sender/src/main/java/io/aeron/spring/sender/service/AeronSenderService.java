package io.aeron.spring.sender.service;

import io.aeron.Aeron;
import io.aeron.Publication;
import io.aeron.driver.MediaDriver;
import io.aeron.spring.cluster.config.ContextFactory;
import io.aeron.spring.sender.config.AeronSenderProperties;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.agrona.BitUtil;
import org.agrona.BufferUtil;
import org.agrona.CloseHelper;
import org.agrona.concurrent.BackoffIdleStrategy;
import org.agrona.concurrent.UnsafeBuffer;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Spring Service：封装 Aeron Publication 的发送逻辑。
 *
 * <h3>线程模型</h3>
 * <p>与官方 demo 保持一致：维护一个独立的 <em>duty-cycle</em> 线程独占访问
 * {@link Publication}，HTTP 线程只负责把消息提交到 {@link LinkedBlockingQueue}
 * 并通过 {@link CompletableFuture} 等待结果。这样无需对 Publication 加锁。
 *
 * <h3>模式切换</h3>
 * <p>通过 {@code aeron.sender.mode=udp|ipc} 配置项选择传输模式：
 * <ul>
 *   <li><b>udp</b>  — {@code aeron:udp?endpoint=host:port}，需要 Receiver 进程监听对应端口</li>
 *   <li><b>ipc</b>  — {@code aeron:ipc}，同机共享内存，延迟更低，不跨网络</li>
 * </ul>
 */
@Service
public class AeronSenderService
{
    private static final int MAX_MESSAGE_BYTES  = 4096;
    private static final long SEND_TIMEOUT_SEC  = 5;

    private final AeronSenderProperties props;

    private MediaDriver  mediaDriver;
    private Aeron        aeron;
    private Publication  publication;

    private Thread           dutyCycleThread;
    private volatile boolean running = false;

    private final LinkedBlockingQueue<PendingMessage> sendQueue = new LinkedBlockingQueue<>();

    public AeronSenderService(final AeronSenderProperties props)
    {
        this.props = props;
    }

    // ──────────────────────────────────────────────
    // 生命周期
    // ──────────────────────────────────────────────

    @PostConstruct
    public void start()
    {
        final String channel  = props.resolveChannel();
        final int    streamId = props.resolveStreamId();

        System.out.println("[AeronSender] mode=" + props.getMode()
            + "  channel=" + channel + "  streamId=" + streamId);

        mediaDriver = MediaDriver.launch(ContextFactory.mediaDriverContext(props.getMediaDriver()));
        aeron       = Aeron.connect(ContextFactory.aeronContext(props.getAeron(), mediaDriver.aeronDirectoryName()));
        publication = aeron.addPublication(channel, streamId);

        System.out.println("[AeronSender] Publication created, sessionId=" + publication.sessionId());
        startDutyCycle();
    }

    @PreDestroy
    public void stop()
    {
        System.out.println("[AeronSender] Stopping...");
        running = false;
        if (dutyCycleThread != null)
        {
            dutyCycleThread.interrupt();
        }
        CloseHelper.closeAll(publication, aeron, mediaDriver);
    }

    // ──────────────────────────────────────────────
    // 公开发送接口（HTTP 线程调用）
    // ──────────────────────────────────────────────

    /**
     * 发送一条文本消息（UTF-8 编码）。
     *
     * @param text 消息内容
     * @return 成功时返回 publication position（正数）
     * @throws IllegalArgumentException 消息超过最大字节限制
     * @throws IllegalStateException    发送超时或 Publication 已关闭
     */
    public long send(final String text)
    {
        final byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        if (bytes.length > MAX_MESSAGE_BYTES)
        {
            throw new IllegalArgumentException(
                "Message too large: " + bytes.length + " > " + MAX_MESSAGE_BYTES + " bytes");
        }
        return submitAndWait(bytes);
    }

    /**
     * 发送原始字节消息。
     *
     * @param bytes 消息字节数组
     * @return 成功时返回 publication position（正数）
     */
    public long send(final byte[] bytes)
    {
        if (bytes.length > MAX_MESSAGE_BYTES)
        {
            throw new IllegalArgumentException(
                "Message too large: " + bytes.length + " > " + MAX_MESSAGE_BYTES + " bytes");
        }
        return submitAndWait(bytes);
    }

    /** 返回当前状态快照（HTTP 线程安全，publication 引用 volatile-读） */
    public SenderStatus status()
    {
        final Publication pub = publication;
        if (pub == null || pub.isClosed())
        {
            return new SenderStatus(false, props.getMode(), props.resolveChannel(),
                props.resolveStreamId(), -1, false);
        }
        return new SenderStatus(true, props.getMode(), props.resolveChannel(),
            props.resolveStreamId(), pub.sessionId(), pub.isConnected());
    }

    // ──────────────────────────────────────────────
    // duty-cycle 线程
    // ──────────────────────────────────────────────

    private void startDutyCycle()
    {
        running         = true;
        dutyCycleThread = new Thread(this::dutyCycle, "aeron-sender-duty-cycle");
        dutyCycleThread.setDaemon(true);
        dutyCycleThread.start();
        System.out.println("[AeronSender] DutyCycle thread started");
    }

    /**
     * Duty-cycle 主循环：独占访问 {@link Publication}，消费发送队列。
     *
     * <p>offer 语义（与 DemoSender 逻辑一致）：
     * <ul>
     *   <li>正数   — 成功，返回 position</li>
     *   <li>{@link Publication#BACK_PRESSURED}  — 流控限制，短暂 idle 后重试</li>
     *   <li>{@link Publication#NOT_CONNECTED}   — 尚无订阅者连接，稍长 idle 后重试</li>
     *   <li>{@link Publication#ADMIN_ACTION}    — Driver 内部管理动作，下轮重试</li>
     *   <li>{@link Publication#CLOSED}          — Publication 已关闭，异常通知调用方</li>
     *   <li>{@link Publication#MAX_POSITION_EXCEEDED} — 超出最大 position，异常通知调用方</li>
     * </ul>
     */
    private void dutyCycle()
    {
        final BackoffIdleStrategy idle   = new BackoffIdleStrategy();
        final UnsafeBuffer         buffer = new UnsafeBuffer(
            BufferUtil.allocateDirectAligned(MAX_MESSAGE_BYTES, BitUtil.CACHE_LINE_LENGTH));

        while (running && !Thread.currentThread().isInterrupted())
        {
            int workCount = 0;

            final PendingMessage msg = sendQueue.peek();
            if (msg != null)
            {
                buffer.putBytes(0, msg.bytes());
                final long result = publication.offer(buffer, 0, msg.bytes().length);

                if (result > 0)
                {
                    sendQueue.poll();
                    msg.future().complete(result);
                    workCount++;
                }
                else if (result == Publication.CLOSED || result == Publication.MAX_POSITION_EXCEEDED)
                {
                    sendQueue.poll();
                    msg.future().completeExceptionally(
                        new IllegalStateException("[AeronSender] offer failed: code=" + result));
                }
                // BACK_PRESSURED / NOT_CONNECTED / ADMIN_ACTION：留队列，下次循环重试
            }

            idle.idle(workCount);
        }
    }

    // ──────────────────────────────────────────────
    // 私有工具
    // ──────────────────────────────────────────────

    private long submitAndWait(final byte[] bytes)
    {
        final CompletableFuture<Long> future = new CompletableFuture<>();
        sendQueue.offer(new PendingMessage(bytes, future));
        try
        {
            return future.get(SEND_TIMEOUT_SEC, TimeUnit.SECONDS);
        }
        catch (final Exception e)
        {
            future.cancel(false);
            throw new IllegalStateException("[AeronSender] Send timed out or interrupted", e);
        }
    }

    // ──────────────────────────────────────────────
    // 内部类型
    // ──────────────────────────────────────────────

    private record PendingMessage(byte[] bytes, CompletableFuture<Long> future) {}

    public record SenderStatus(
        boolean connected,
        String  mode,
        String  channel,
        int     streamId,
        int     sessionId,
        boolean isConnected) {}
}
