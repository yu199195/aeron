package io.aeron.spring.agent;

import io.prometheus.client.CollectorRegistry;
import io.prometheus.client.exporter.HTTPServer;
import io.prometheus.client.hotspot.DefaultExports;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.logging.Logger;

/**
 * Thin wrapper around the Prometheus simple-client embedded
 * {@link HTTPServer} that serves the {@code /metrics} endpoint.
 *
 * <p>The server listens on {@code 0.0.0.0:<port>} so that Prometheus can
 * reach it from any interface.  The port defaults to
 * {@link AeronPrometheusAgent#PROMETHEUS_PORT_DEFAULT} (9095) and can be
 * overridden via the {@link AeronPrometheusAgent#PROMETHEUS_PORT_PROP}
 * system property.
 *
 * <p>In addition to Aeron-specific counters this server also exposes the
 * standard JVM metrics registered by {@link DefaultExports}:
 * <ul>
 *   <li>JVM memory pools</li>
 *   <li>Garbage-collection stats</li>
 *   <li>Thread counts and states</li>
 *   <li>File descriptor usage</li>
 *   <li>Class-loading stats</li>
 *   <li>CPU and process metrics</li>
 * </ul>
 */
public final class PrometheusHttpServer {

    private static final Logger LOG = Logger.getLogger(PrometheusHttpServer.class.getName());

    private final int port;
    private HTTPServer server;

    public PrometheusHttpServer(final int port) {
        this.port = port;
    }

    /**
     * Starts the HTTP server and registers default JVM exports.
     * Logs a warning but does not throw if the port is unavailable.
     */
    public void start() {
        // Register JVM / OS / GC metrics automatically
        DefaultExports.initialize();

        try {
            server = new HTTPServer(new InetSocketAddress(port),
                                    CollectorRegistry.defaultRegistry,
                                    true /* daemon */);
            LOG.info("[PrometheusHttpServer] listening on http://0.0.0.0:" + port + "/metrics");
        } catch (final IOException e) {
            LOG.warning("[PrometheusHttpServer] failed to start on port " + port + ": " + e.getMessage());
        }
    }

    /** Stops the embedded HTTP server if it is running. */
    public void stop() {
        if (server != null) {
            server.close();
            server = null;
            LOG.info("[PrometheusHttpServer] stopped");
        }
    }
}
