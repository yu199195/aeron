package io.aeron.spring.agent;

import io.aeron.agent.EventLogAgent;
import io.aeron.spring.agent.metrics.AeronMetrics;

import java.lang.instrument.Instrumentation;
import java.util.logging.Logger;

/**
 * Java agent entry-point.
 *
 * <p>Extends the standard {@code aeron-agent} by replacing the default text-log
 * reader with {@link PrometheusEventReaderAgent}, which exposes every Aeron event
 * as a Prometheus counter.
 *
 * <p>Startup flow:
 * <pre>
 *   premain
 *     1. Set default event-log system properties (driver/archive/cluster = "all")
 *     2. Set aeron.event.log.reader.classname = PrometheusEventReaderAgent
 *     3. AeronMetrics.init()  – register all 130 Prometheus counters
 *     4. PrometheusHttpServer.start()  – expose /metrics on port 9095
 *     5. EventLogAgent.premain()
 *          └─ installs ByteBuddy interceptors
 *          └─ starts PrometheusEventReaderAgent (via classname property)
 * </pre>
 *
 * <p>Attach with:
 * <pre>
 *   -javaagent:aeron-agent-1.0.0-SNAPSHOT-all.jar
 * </pre>
 *
 * <p>Optional system properties:
 * <pre>
 *   aeron.prometheus.port           HTTP port for /metrics (default 9095)
 *   aeron.event.log                 driver events  (default "all")
 *   aeron.event.archive.log         archive events (default "all")
 *   aeron.event.cluster.log         cluster events (default "all")
 *   aeron.event.log.disable         comma-separated driver events to disable
 *   aeron.event.archive.log.disable comma-separated archive events to disable
 *   aeron.event.cluster.log.disable comma-separated cluster events to disable
 * </pre>
 */
public final class AeronPrometheusAgent {

    private static final Logger LOG = Logger.getLogger(AeronPrometheusAgent.class.getName());

    public static final String PROMETHEUS_PORT_PROP    = "aeron.prometheus.port";
    public static final int    PROMETHEUS_PORT_DEFAULT = 9095;

    private static volatile PrometheusHttpServer httpServer;

    private AeronPrometheusAgent() {}

    public static void premain(final String agentArgs, final Instrumentation instrumentation) {
        start(agentArgs, instrumentation);
    }

    public static void agentmain(final String agentArgs, final Instrumentation instrumentation) {
        if ("stop".equalsIgnoreCase(agentArgs)) {
            stop();
        } else {
            start(agentArgs, instrumentation);
        }
    }

    private static synchronized void start(final String agentArgs, final Instrumentation instrumentation) {
        if (httpServer != null) {
            LOG.warning("[AeronPrometheusAgent] already started");
            return;
        }

        // 1. Apply default event-log properties so aeron-agent captures all events
        setIfAbsent("aeron.event.log",         "all");
        setIfAbsent("aeron.event.archive.log", "all");
        setIfAbsent("aeron.event.cluster.log", "all");

        // 2. Inject our Prometheus reader so EventLogAgent starts it instead of the text logger
        System.setProperty(EventLogAgent.READER_CLASSNAME_PROP_NAME,
                           PrometheusEventReaderAgent.class.getName());

        // 3. Register all 130 Prometheus counters (Driver + Archive + Cluster)
        AeronMetrics.init();

        // 4. Start embedded HTTP /metrics endpoint
        final int port = Integer.getInteger(PROMETHEUS_PORT_PROP, PROMETHEUS_PORT_DEFAULT);
        httpServer = new PrometheusHttpServer(port);
        httpServer.start();

        // 5. Delegate ByteBuddy instrumentation to aeron-agent's EventLogAgent
        EventLogAgent.premain(agentArgs, instrumentation);

        // 6. Install custom interceptors (write directly to Prometheus, bypass ring-buffer)
        CustomMetricsInstaller.install(instrumentation);

        LOG.info("[AeronPrometheusAgent] started – metrics on http://localhost:" + port + "/metrics");
    }

    static synchronized void stop() {
        EventLogAgent.stopLogging();
        if (httpServer != null) {
            httpServer.stop();
            httpServer = null;
        }
        LOG.info("[AeronPrometheusAgent] stopped");
    }

    private static void setIfAbsent(final String key, final String value) {
        if (System.getProperty(key) == null) {
            System.setProperty(key, value);
        }
    }
}
