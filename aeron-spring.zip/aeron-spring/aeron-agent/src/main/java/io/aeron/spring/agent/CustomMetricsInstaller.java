package io.aeron.spring.agent;

import net.bytebuddy.agent.builder.AgentBuilder;
import net.bytebuddy.asm.Advice;
import net.bytebuddy.matcher.ElementMatchers;

import java.lang.instrument.Instrumentation;
import java.util.logging.Logger;

/**
 * Installs custom ByteBuddy interceptors that write directly to Prometheus counters.
 *
 * <p>This installer is independent of Aeron's own {@code EventLogAgent} / ring-buffer
 * pipeline.  Each transformer wires an {@link Advice} class from {@link CustomInterceptors}
 * onto a target class/method via {@link AgentBuilder}.
 *
 * <p>Called from {@link AeronPrometheusAgent#start(String, Instrumentation)} after
 * {@code EventLogAgent.premain()} so both instrumentation passes share the same
 * {@link Instrumentation} handle.
 *
 * <h3>How to add a new custom interceptor</h3>
 * <pre>
 *   1. Add an Advice class in {@link CustomInterceptors} with @Advice.OnMethodEnter/Exit.
 *   2. Register the matching counter in AeronMetrics.registerCustomMetrics().
 *   3. Add a new {@code builder.type(…).transform(…)} block below.
 * </pre>
 */
public final class CustomMetricsInstaller {

    private static final Logger LOG = Logger.getLogger(CustomMetricsInstaller.class.getName());

    private CustomMetricsInstaller() {}

    /**
     * Installs all custom transformers onto the supplied {@link Instrumentation}.
     *
     * <p>{@link AgentBuilder.RedefinitionStrategy#RETRANSFORMATION} is used so that
     * classes already loaded by the JVM (e.g. if the agent is attached dynamically)
     * are also instrumented.  {@code disableClassFormatChanges()} is required when
     * retransformation is in use.
     */
    public static void install(final Instrumentation instrumentation) {
        new AgentBuilder.Default()
            .disableClassFormatChanges()
            .with(AgentBuilder.RedefinitionStrategy.RETRANSFORMATION)
            .with(AgentBuilder.RedefinitionStrategy.Listener.StreamWriting.toSystemError())
            // ── suppress "class not found" noise for unrelated classes ──
            .with(AgentBuilder.Listener.StreamWriting.toSystemError().withTransformationsOnly())

            // ── Publication.offer(*) ─────────────────────────────────────────
            .type(ElementMatchers.named("io.aeron.Publication"))
            .transform((builder, typeDescription, classLoader, module, protectionDomain) ->
                builder.visit(
                    Advice.to(CustomInterceptors.PublicationOfferReturn.class)
                          .on(ElementMatchers.named("offer")
                              .and(ElementMatchers.returns(long.class)))
                )
            )

            // ── ExclusivePublication.offer(*) ────────────────────────────────
            .type(ElementMatchers.named("io.aeron.ExclusivePublication"))
            .transform((builder, typeDescription, classLoader, module, protectionDomain) ->
                builder.visit(
                    Advice.to(CustomInterceptors.ExclusivePublicationOfferReturn.class)
                          .on(ElementMatchers.named("offer")
                              .and(ElementMatchers.returns(long.class)))
                )
            )

            .installOn(instrumentation);

        LOG.info("[CustomMetricsInstaller] installed interceptors: Publication.offer, ExclusivePublication.offer");
    }
}
