package io.aeron.spring.agent.metrics;

import io.prometheus.client.Counter;
import io.prometheus.client.CollectorRegistry;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Central registry for ALL Aeron Prometheus metrics.
 *
 * <p>This class pre-registers a {@link Counter} for every event code defined
 * across Driver (60), Archive (45) and Cluster (25) subsystems – 130 counters
 * in total.  The counters use a consistent naming convention:
 *
 * <pre>
 *   aeron_{component}_{event_name_lower}_total
 * </pre>
 *
 * For example:
 * <ul>
 *   <li>{@code aeron_driver_frame_in_total}</li>
 *   <li>{@code aeron_archive_recording_session_state_change_total}</li>
 *   <li>{@code aeron_cluster_election_state_change_total}</li>
 * </ul>
 *
 * <p>Call {@link #init()} once at agent startup.  Subsequently call
 * {@link #increment(int)} from the reader thread with the ring-buffer
 * {@code msgTypeId}.
 */
public final class AeronMetrics {

    private static final String NAMESPACE = "aeron";

    /** Maps msgTypeId (typeCode<<16 | eventCode) → Counter */
    private static final ConcurrentMap<Integer, Counter> REGISTRY = new ConcurrentHashMap<>(256);

    private static volatile boolean initialised = false;

    private AeronMetrics() {}

    // ─────────────────────────────────────────────────────────────────────────
    // Public API
    // ─────────────────────────────────────────────────────────────────────────

    /** Initialises all counters exactly once (idempotent). */
    public static synchronized void init() {
        if (initialised) return;
        registerDriverMetrics();
        registerArchiveMetrics();
        registerClusterMetrics();
        registerCustomMetrics();
        initialised = true;
    }

    /**
     * Increments the counter corresponding to a ring-buffer {@code msgTypeId}.
     * Unknown IDs are silently ignored (no counter created at runtime to avoid
     * unbounded growth).
     */
    public static void increment(final int msgTypeId) {
        final Counter c = REGISTRY.get(msgTypeId);
        if (c != null) {
            c.inc();
        }
    }

    /**
     * Increments the counter with an additional label value.
     * Only relevant for metrics that carry a state/role label.
     */
    public static void increment(final int msgTypeId, final String labelValue) {
        final Counter c = REGISTRY.get(msgTypeId);
        if (c != null) {
            try {
                c.labels(labelValue).inc();
            } catch (final Exception e) {
                // label not registered – fall back to no-label counter
                c.inc();
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Driver metrics  (typeCode = 0, 60 events)
    // ─────────────────────────────────────────────────────────────────────────

    private static void registerDriverMetrics() {
        // typeCode = 0  → msgTypeId = (0 << 16) | eventId = eventId
        final int TC = 0;

        // ── Network I/O ──────────────────────────────────────────────────────
        reg(TC,  1, "driver", "frame_in",                  "Incoming UDP frames received by the driver");
        reg(TC,  2, "driver", "frame_out",                 "Outgoing UDP frames sent by the driver");
        reg(TC, 54, "driver", "nak_sent",                  "NAK (negative acknowledgement) messages sent (request for retransmit)");
        reg(TC, 58, "driver", "nak_received",              "NAK messages received by the sender");
        reg(TC, 55, "driver", "resend",                    "Data segments resent in response to NAK");

        // ── Publication lifecycle ────────────────────────────────────────────
        reg(TC,  3, "driver", "cmd_in_add_publication",           "Client requested a new publication");
        reg(TC, 32, "driver", "cmd_in_add_exclusive_publication",  "Client requested an exclusive publication");
        reg(TC,  4, "driver", "cmd_in_remove_publication",        "Client requested removal of a publication");
        reg(TC,  7, "driver", "cmd_out_publication_ready",        "Driver notified client that publication is ready");
        reg(TC, 33, "driver", "cmd_out_exclusive_publication_ready", "Driver notified client that exclusive publication is ready");
        reg(TC, 14, "driver", "remove_publication_cleanup",       "Driver cleaned up a publication");
        reg(TC, 59, "driver", "publication_revoke",               "A publication was revoked");
        reg(TC, 60, "driver", "publication_image_revoke",         "A publication image was revoked");

        // ── Subscription & Image lifecycle ───────────────────────────────────
        reg(TC,  5, "driver", "cmd_in_add_subscription",         "Client requested a new subscription");
        reg(TC,  6, "driver", "cmd_in_remove_subscription",      "Client requested removal of a subscription");
        reg(TC, 37, "driver", "cmd_out_subscription_ready",      "Driver notified client that subscription is ready");
        reg(TC,  8, "driver", "cmd_out_available_image",         "New image became available (new publisher connected)");
        reg(TC, 17, "driver", "cmd_out_on_unavailable_image",    "Image became unavailable (publisher disconnected)");
        reg(TC, 16, "driver", "remove_image_cleanup",            "Driver cleaned up an image");
        reg(TC, 15, "driver", "remove_subscription_cleanup",     "Driver cleaned up a subscription");
        reg(TC, 45, "driver", "untethered_subscription_state_change", "Untethered subscription changed state");
        reg(TC, 57, "driver", "cmd_in_reject_image",             "Client requested image rejection");

        // ── Channels ─────────────────────────────────────────────────────────
        reg(TC, 23, "driver", "send_channel_creation",    "Send channel created");
        reg(TC, 24, "driver", "receive_channel_creation", "Receive channel created");
        reg(TC, 25, "driver", "send_channel_close",       "Send channel closed");
        reg(TC, 26, "driver", "receive_channel_close",    "Receive channel closed");

        // ── Destination (multi-destination / MDC) ────────────────────────────
        reg(TC, 30, "driver", "cmd_in_add_destination",           "Client added a destination");
        reg(TC, 31, "driver", "cmd_in_remove_destination",        "Client removed a destination");
        reg(TC, 41, "driver", "cmd_in_add_rcv_destination",       "Client added a receive destination");
        reg(TC, 42, "driver", "cmd_in_remove_rcv_destination",    "Client removed a receive destination");
        reg(TC, 56, "driver", "cmd_in_remove_destination_by_id",  "Client removed a destination by ID");

        // ── Counter management ───────────────────────────────────────────────
        reg(TC, 35, "driver", "cmd_in_add_counter",              "Client requested a new counter");
        reg(TC, 36, "driver", "cmd_in_remove_counter",           "Client requested counter removal");
        reg(TC, 38, "driver", "cmd_out_counter_ready",           "Driver notified client that counter is ready");
        reg(TC, 39, "driver", "cmd_out_on_unavailable_counter",  "A counter became unavailable");

        // ── Client management ────────────────────────────────────────────────
        reg(TC, 13, "driver", "cmd_in_keepalive_client",   "Client keepalive heartbeat received");
        reg(TC, 40, "driver", "cmd_in_client_close",       "Client close command received");
        reg(TC, 43, "driver", "cmd_out_on_client_timeout", "Client timed out");
        reg(TC, 44, "driver", "cmd_in_terminate_driver",   "Driver terminate command received");

        // ── Name resolution ──────────────────────────────────────────────────
        reg(TC, 46, "driver", "name_resolution_neighbor_added",   "New name-resolution neighbour discovered");
        reg(TC, 47, "driver", "name_resolution_neighbor_removed", "Name-resolution neighbour removed");
        reg(TC, 50, "driver", "name_resolution_resolve",          "Name resolved (DNS lookup)");
        reg(TC, 52, "driver", "name_resolution_lookup",           "Name lookup performed");
        reg(TC, 53, "driver", "name_resolution_host_name",        "Hostname lookup performed");

        // ── Flow control ─────────────────────────────────────────────────────
        reg(TC, 48, "driver", "flow_control_receiver_added",   "Flow control receiver added");
        reg(TC, 49, "driver", "flow_control_receiver_removed", "Flow control receiver removed");

        // ── Miscellaneous ────────────────────────────────────────────────────
        reg(TC, 12, "driver", "cmd_out_on_operation_success", "Command completed successfully");
        reg(TC, 34, "driver", "cmd_out_error",                "Driver returned an error response");
        reg(TC, 51, "driver", "text_data",                    "Free-text data event");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Archive metrics  (typeCode = 1, 45 events)
    // ─────────────────────────────────────────────────────────────────────────

    private static void registerArchiveMetrics() {
        final int TC = 1;

        // ── Session management ───────────────────────────────────────────────
        reg(TC,  1, "archive", "cmd_in_connect",              "Client connected to the archive");
        reg(TC, 27, "archive", "cmd_in_auth_connect",         "Client connected with authentication");
        reg(TC,  2, "archive", "cmd_in_close_session",        "Client closed archive session");
        reg(TC, 28, "archive", "cmd_in_keep_alive",           "Client keepalive for archive session");
        reg(TC, 30, "archive", "cmd_out_response",            "Archive sent control response to client");
        reg(TC, 35, "archive", "control_session_state_change","Archive control session changed state");

        // ── Recording ────────────────────────────────────────────────────────
        reg(TC,  3, "archive", "cmd_in_start_recording",         "Client requested start recording (v1)");
        reg(TC, 31, "archive", "cmd_in_start_recording2",        "Client requested start recording (v2 with sourceIdentity)");
        reg(TC,  4, "archive", "cmd_in_stop_recording",          "Client requested stop recording by subscription");
        reg(TC, 13, "archive", "cmd_in_stop_recording_subscription", "Client stopped recording by subscription ID");
        reg(TC, 33, "archive", "cmd_in_stop_recording_by_identity",  "Client stopped recording by recording ID");
        reg(TC, 10, "archive", "cmd_in_extend_recording",        "Client extended an existing recording (v1)");
        reg(TC, 32, "archive", "cmd_in_extend_recording2",       "Client extended an existing recording (v2)");
        reg(TC, 11, "archive", "cmd_in_recording_position",      "Client queried current recording position");
        reg(TC, 21, "archive", "cmd_in_start_position",          "Client queried recording start position");
        reg(TC, 14, "archive", "cmd_in_stop_position",           "Client queried recording stop position");
        reg(TC, 45, "archive", "cmd_in_max_recorded_position",   "Client queried maximum recorded position");
        reg(TC, 44, "archive", "recording_session_state_change", "Recording session changed state");
        reg(TC, 40, "archive", "recording_signal",               "Recording signal emitted (START/STOP/SYNC etc.)");

        // ── Catalog queries ──────────────────────────────────────────────────
        reg(TC,  7, "archive", "cmd_in_list_recordings",             "Client listed all recordings");
        reg(TC,  8, "archive", "cmd_in_list_recordings_for_uri",     "Client listed recordings for URI");
        reg(TC,  9, "archive", "cmd_in_list_recording",              "Client retrieved single recording info");
        reg(TC, 16, "archive", "cmd_in_list_recording_subscriptions","Client listed recording subscriptions");
        reg(TC, 15, "archive", "cmd_in_find_last_matching_record",   "Client found last matching recording");

        // ── Segment management ───────────────────────────────────────────────
        reg(TC, 12, "archive", "cmd_in_truncate_recording",       "Client truncated a recording");
        reg(TC, 24, "archive", "cmd_in_purge_segments",           "Client purged segment files");
        reg(TC, 38, "archive", "cmd_in_purge_recording",          "Client purged an entire recording");
        reg(TC, 22, "archive", "cmd_in_detach_segments",          "Client detached segments");
        reg(TC, 23, "archive", "cmd_in_delete_detached_segments", "Client deleted detached segments");
        reg(TC, 25, "archive", "cmd_in_attach_segments",          "Client attached segments");
        reg(TC, 26, "archive", "cmd_in_migrate_segments",         "Client migrated segments");
        reg(TC, 37, "archive", "catalog_resize",                  "Archive catalog file was resized (capacity growth)");

        // ── Replay ───────────────────────────────────────────────────────────
        reg(TC,  5, "archive", "cmd_in_replay",                 "Client started a replay");
        reg(TC, 17, "archive", "cmd_in_start_bounded_replay",   "Client started a bounded replay");
        reg(TC,  6, "archive", "cmd_in_stop_replay",            "Client stopped a replay");
        reg(TC, 18, "archive", "cmd_in_stop_all_replays",       "Client stopped all replays");
        reg(TC, 42, "archive", "cmd_in_request_replay_token",   "Client requested a replay token");
        reg(TC, 43, "archive", "replay_session_state_change",   "Replay session changed state");
        reg(TC, 36, "archive", "replay_session_error",          "Replay session encountered an error");

        // ── Replication ──────────────────────────────────────────────────────
        reg(TC, 19, "archive", "cmd_in_replicate",                   "Client started replication (v1)");
        reg(TC, 39, "archive", "cmd_in_replicate2",                  "Client started replication (v2)");
        reg(TC, 29, "archive", "cmd_in_tagged_replicate",            "Client started tagged replication");
        reg(TC, 20, "archive", "cmd_in_stop_replication",            "Client stopped replication");
        reg(TC, 34, "archive", "replication_session_state_change",   "Replication session changed state");
        reg(TC, 41, "archive", "replication_session_done",           "Replication session completed");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Cluster metrics  (typeCode = 2, 25 events)
    // ─────────────────────────────────────────────────────────────────────────

    private static void registerClusterMetrics() {
        final int TC = 2;

        // ── Election ─────────────────────────────────────────────────────────
        reg(TC, 22, "cluster", "new_election",           "A new election round was initiated");
        reg(TC,  1, "cluster", "election_state_change",  "Election state machine transitioned");
        reg(TC,  5, "cluster", "canvass_position",       "Node broadcast its log position during canvassing");
        reg(TC,  6, "cluster", "request_vote",           "Candidate sent a vote request");
        reg(TC, 25, "cluster", "vote",                   "Node cast a vote");

        // ── Leadership ───────────────────────────────────────────────────────
        reg(TC,  2, "cluster", "new_leadership_term",         "New leadership term started");
        reg(TC, 10, "cluster", "replay_new_leadership_term",  "Historical leadership term replayed during recovery");
        reg(TC,  4, "cluster", "role_change",                 "Node role changed (FOLLOWER / CANDIDATE / LEADER)");

        // ── ConsensusModule state ────────────────────────────────────────────
        reg(TC,  3, "cluster", "state_change",                 "ConsensusModule state changed");
        reg(TC, 16, "cluster", "cluster_backup_state_change",  "Cluster backup mode state changed");

        // ── Log replication ──────────────────────────────────────────────────
        reg(TC, 11, "cluster", "append_position",   "Follower reported its append log position");
        reg(TC, 12, "cluster", "commit_position",   "Leader broadcast the committed log position");
        reg(TC,  7, "cluster", "catchup_position",  "Follower reported its catch-up position");
        reg(TC,  8, "cluster", "stop_catchup",      "Follower catch-up was stopped");
        reg(TC,  9, "cluster", "truncate_log_entry","Log entries were truncated (post-election rollback)");

        // ── Session management ───────────────────────────────────────────────
        reg(TC, 23, "cluster", "append_session_open",          "Cluster client session opened");
        reg(TC, 14, "cluster", "append_session_close",         "Cluster client session closed");
        reg(TC, 24, "cluster", "cluster_session_state_change", "Cluster session changed state");
        reg(TC, 19, "cluster", "service_ack",                  "ClusteredService acknowledged ConsensusModule");

        // ── Termination & snapshot ───────────────────────────────────────────
        reg(TC, 17, "cluster", "termination_position",          "Termination position notified to node");
        reg(TC, 18, "cluster", "termination_ack",               "Node acknowledged termination instruction");
        reg(TC, 20, "cluster", "replication_ended",             "Archive replication ended");
        reg(TC, 21, "cluster", "standby_snapshot_notification", "Standby snapshot notification received");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Custom metrics  (typeCode = 3)
    //
    // These counters are populated by CustomInterceptors via direct AeronMetrics
    // calls – they do NOT go through the Aeron ring-buffer.
    //
    // msgTypeId = (3 << 16) | eventCode  →  never collides with Aeron built-ins
    //   (0 << 16 = driver, 1 << 16 = archive, 2 << 16 = cluster)
    // ─────────────────────────────────────────────────────────────────────────

    private static void registerCustomMetrics() {
        final int TC = 3;

        // ── Publication.offer() result codes ─────────────────────────────────
        reg(TC, 1, "publication", "offer_back_pressured",
            "Publication.offer() returned BACK_PRESSURED (-2): sender ring-buffer full");
        reg(TC, 2, "publication", "offer_not_connected",
            "Publication.offer() returned NOT_CONNECTED (-1): no active subscriber");
        reg(TC, 3, "publication", "offer_max_position_exceeded",
            "Publication.offer() returned MAX_POSITION_EXCEEDED (-3): term limit reached");
        reg(TC, 4, "publication", "offer_closed",
            "Publication.offer() returned CLOSED (Long.MIN_VALUE): publication already closed");

        // ── ExclusivePublication.offer() result codes ─────────────────────────
        reg(TC, 5, "exclusive_publication", "offer_back_pressured",
            "ExclusivePublication.offer() returned BACK_PRESSURED (-2)");
        reg(TC, 6, "exclusive_publication", "offer_not_connected",
            "ExclusivePublication.offer() returned NOT_CONNECTED (-1)");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Helper
    // ─────────────────────────────────────────────────────────────────────────

    private static void reg(final int typeCode, final int eventCode,
                            final String component, final String metricName,
                            final String help) {
        final int msgTypeId = (typeCode << 16) | eventCode;
        final String fullName = NAMESPACE + "_" + component + "_" + metricName + "_total";

        final Counter counter = Counter.build()
            .name(fullName)
            .help(help)
            .register(CollectorRegistry.defaultRegistry);

        REGISTRY.put(msgTypeId, counter);
    }
}
