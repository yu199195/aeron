package io.aeron.spring.agent;

import io.aeron.spring.agent.metrics.AeronMetrics;
import net.bytebuddy.asm.Advice;

/**
 * ByteBuddy {@link Advice} interceptors for custom application-level Prometheus metrics.
 *
 * <p>Each public nested class is a self-contained Advice that can be woven into
 * target methods by {@link CustomMetricsInstaller}.  Interceptors write directly
 * to {@link AeronMetrics} counters – no ring-buffer indirection needed.
 *
 * <h3>Adding a new interceptor</h3>
 * <ol>
 *   <li>Define a new {@code msgTypeId} constant here (use {@code typeCode = 3}).</li>
 *   <li>Add a {@code public static final class} with {@code @Advice.OnMethodEnter/Exit}.</li>
 *   <li>Register the counter in {@link AeronMetrics#registerCustomMetrics()}.</li>
 *   <li>Wire the transformer in {@link CustomMetricsInstaller#install}.</li>
 * </ol>
 *
 * <h3>Publication offer result codes</h3>
 * <pre>
 *   BACK_PRESSURED        = -2L   (sender ring-buffer full)
 *   NOT_CONNECTED         = -1L   (no active subscribers)
 *   MAX_POSITION_EXCEEDED = -3L   (term limit exceeded)
 *   CLOSED                = Long.MIN_VALUE
 *   >= 0                          success – new stream position
 * </pre>
 */
public final class CustomInterceptors {

    private CustomInterceptors() {}

    // ── msgTypeId constants  (typeCode=3 → custom; never overlaps with Aeron built-ins) ──

    /** {@code (3 << 16) | 1} */
    public static final int OFFER_BACK_PRESSURED      = (3 << 16) | 1;
    /** {@code (3 << 16) | 2} */
    public static final int OFFER_NOT_CONNECTED       = (3 << 16) | 2;
    /** {@code (3 << 16) | 3} */
    public static final int OFFER_MAX_POS_EXCEEDED    = (3 << 16) | 3;
    /** {@code (3 << 16) | 4} */
    public static final int OFFER_CLOSED              = (3 << 16) | 4;
    /** {@code (3 << 16) | 5} */
    public static final int EXCLUSIVE_PUB_OFFER_BACK_PRESSURED = (3 << 16) | 5;
    /** {@code (3 << 16) | 6} */
    public static final int EXCLUSIVE_PUB_OFFER_NOT_CONNECTED  = (3 << 16) | 6;

    // ─────────────────────────────────────────────────────────────────────────────
    // Publication.offer() – counts non-success return values
    // ─────────────────────────────────────────────────────────────────────────────

    /**
     * Intercepts every {@code Publication.offer(…)} overload.
     *
     * <p>Wired onto {@code io.aeron.Publication} methods named {@code offer}
     * that return {@code long}.  All four overloads share the same return-value
     * semantics, so one Advice class handles all of them.
     */
    public static final class PublicationOfferReturn {

        @Advice.OnMethodExit
        public static void onExit(@Advice.Return final long result) {
            if (result == -2L) {
                AeronMetrics.increment(OFFER_BACK_PRESSURED);
            } else if (result == -1L) {
                AeronMetrics.increment(OFFER_NOT_CONNECTED);
            } else if (result == -3L) {
                AeronMetrics.increment(OFFER_MAX_POS_EXCEEDED);
            } else if (result == Long.MIN_VALUE) {
                AeronMetrics.increment(OFFER_CLOSED);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // ExclusivePublication.offer() – same result codes, tracked separately
    // ─────────────────────────────────────────────────────────────────────────────

    /**
     * Intercepts {@code ExclusivePublication.offer(…)} overloads.
     *
     * <p>Exclusive publications are single-writer, so their backpressure and
     * connectivity counters are worth tracking independently of shared publications.
     */
    public static final class ExclusivePublicationOfferReturn {

        @Advice.OnMethodExit
        public static void onExit(@Advice.Return final long result) {
            if (result == -2L) {
                AeronMetrics.increment(EXCLUSIVE_PUB_OFFER_BACK_PRESSURED);
            } else if (result == -1L) {
                AeronMetrics.increment(EXCLUSIVE_PUB_OFFER_NOT_CONNECTED);
            }
        }
    }
}
