package io.aeron.spring.agent;

import io.aeron.spring.agent.metrics.AeronMetrics;
import org.agrona.MutableDirectBuffer;
import org.agrona.concurrent.Agent;
import org.agrona.concurrent.MessageHandler;
import org.agrona.concurrent.ringbuffer.RingBuffer;

import java.lang.reflect.Field;
import java.util.logging.Logger;

/**
 * Agrona {@link Agent} that drains the Aeron event ring-buffer and increments
 * the corresponding Prometheus counter for every event consumed.
 *
 * <p>Instantiated by {@code EventLogAgent} via no-arg reflection when the system
 * property {@code aeron.event.log.reader.classname} is set to this class name.
 *
 * <p>{@code EventConfiguration} is package-private in aeron-agent 1.44.1, so
 * {@code EVENT_RING_BUFFER} is accessed once at startup via reflection.
 */
public final class PrometheusEventReaderAgent implements Agent {

    private static final Logger LOG = Logger.getLogger(PrometheusEventReaderAgent.class.getName());
    private static final int FRAME_LIMIT = 20;

    private final RingBuffer ringBuffer;
    private long totalEventsConsumed = 0L;
    private final MessageHandler handler = this::onMessage;

    /** No-arg constructor required by {@code EventLogAgent} reflection instantiation. */
    public PrometheusEventReaderAgent() {
        this.ringBuffer = resolveRingBuffer();
    }

    @Override
    public String roleName() {
        return "aeron-prometheus-reader";
    }

    @Override
    public void onStart() {
        LOG.info("[PrometheusEventReaderAgent] started – draining ring-buffer");
    }

    @Override
    public int doWork() throws Exception {
        return ringBuffer.read(handler, FRAME_LIMIT);
    }

    @Override
    public void onClose() {
        LOG.info("[PrometheusEventReaderAgent] stopped – total events consumed: " + totalEventsConsumed);
    }

    private void onMessage(final int msgTypeId,
                           final MutableDirectBuffer buffer,
                           final int index,
                           final int length) {
        totalEventsConsumed++;
        AeronMetrics.increment(msgTypeId);
    }

    /**
     * Resolves {@code EventConfiguration.EVENT_RING_BUFFER} via reflection.
     * {@code EventConfiguration} is package-private in aeron-agent 1.44.x, so
     * direct access from outside the package is not possible at compile time.
     */
    private static RingBuffer resolveRingBuffer() {
        try {
            final Class<?> cls = Class.forName("io.aeron.agent.EventConfiguration");
            final Field field = cls.getDeclaredField("EVENT_RING_BUFFER");
            field.setAccessible(true);
            return (RingBuffer) field.get(null);
        } catch (final Exception e) {
            throw new IllegalStateException(
                "[PrometheusEventReaderAgent] cannot access EventConfiguration.EVENT_RING_BUFFER", e);
        }
    }
}
