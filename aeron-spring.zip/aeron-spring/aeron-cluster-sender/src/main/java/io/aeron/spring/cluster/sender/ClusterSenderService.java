package io.aeron.spring.cluster.sender;

import io.aeron.Publication;
import io.aeron.cluster.client.AeronCluster;
import io.aeron.driver.MediaDriver;
import io.aeron.spring.cluster.config.ClusterProperties;
import io.aeron.spring.cluster.config.SenderProperties;
import io.aeron.spring.cluster.listener.HtxEgressListener;
import io.aeron.spring.cluster.model.OrderRequest;
import io.aeron.spring.cluster.model.UserRequest;
import io.aeron.spring.cluster.sbe.MessageHeaderEncoder;
import io.aeron.spring.cluster.sbe.OrderEncoder;
import io.aeron.spring.cluster.sbe.UserEncoder;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.agrona.CloseHelper;
import org.agrona.ExpandableArrayBuffer;
import org.agrona.concurrent.BackoffIdleStrategy;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Spring Service：封装集群连接和消息发送逻辑。
 *
 * <h3>设计模式（官方 BasicAuctionClusterClient 一致）</h3>
 * <p>
 * 使用单一 duty-cycle 线程独占访问 {@link AeronCluster}，无需任何锁：
 * <ol>
 *   <li>{@code pollEgress()} — 接收集群响应，处理 Leader 变更</li>
 *   <li>发送队列 — 消费 HTTP 线程提交的待发消息</li>
 *   <li>{@code sendKeepAlive()} — 超过 1 秒无消息发送时主动心跳，防止 session 超时</li>
 * </ol>
 * HTTP 线程只负责编码消息并提交到 {@link LinkedBlockingQueue}，
 * 通过 {@link CompletableFuture} 等待 duty-cycle 线程的发送结果。
 */
@Service
public class ClusterSenderService
{
    private final ClusterProperties clusterProps;
    private final SenderProperties  senderProps;

    private MediaDriver  mediaDriver;
    // volatile：duty-cycle 线程写（重连），HTTP 线程读（status 查询）
    private volatile AeronCluster aeronCluster;

    private Thread          dutyCycleThread;
    private volatile boolean running = false;

    /** HTTP 线程 → duty-cycle 线程的消息队列 */
    private final LinkedBlockingQueue<PendingMessage> sendQueue = new LinkedBlockingQueue<>();

    /** 与官方 demo 保持一致：1 秒内无 offer 则发送 keep-alive */
    private static final long KEEP_ALIVE_INTERVAL_MS = 1_000;

    private static final int  MAX_RECONNECT_ATTEMPTS = 3;
    private static final long RECONNECT_DELAY_MS     = 1_000;

    public ClusterSenderService(final ClusterProperties clusterProps, final SenderProperties senderProps)
    {
        this.clusterProps = clusterProps;
        this.senderProps  = senderProps;
    }

    // ──────────────────────────────────────────────
    // 生命周期
    // ──────────────────────────────────────────────

    @PostConstruct
    public void connect()
    {
        final String ingressEndpoints = resolveIngressEndpoints();
        System.out.println("[Sender] Connecting to cluster, ingressEndpoints=" + ingressEndpoints);

        mediaDriver = MediaDriver.launch(new MediaDriver.Context());

        aeronCluster = AeronCluster.connect(buildClusterContext(ingressEndpoints));

        System.out.println("[Sender] Connected, sessionId=" + aeronCluster.clusterSessionId()
            + ", leader=" + aeronCluster.leaderMemberId());

        startDutyCycle();
    }

    @PreDestroy
    public void disconnect()
    {
        System.out.println("[Sender] Disconnecting...");
        running = false;
        if (dutyCycleThread != null)
        {
            dutyCycleThread.interrupt();
        }
        CloseHelper.closeAll(aeronCluster, mediaDriver);
    }

    // ──────────────────────────────────────────────
    // 发送接口（HTTP 线程调用）
    // ──────────────────────────────────────────────

    /**
     * 向集群发送 Order 消息。
     * <p>
     * 在 HTTP 线程完成编码，提交至队列后阻塞等待 duty-cycle 线程发送结果。
     *
     * @return 发送成功时的 publication position（>0）
     */
    public long sendOrder(final OrderRequest req)
    {
        final byte[] symbolBytes = req.getSymbol().getBytes(StandardCharsets.UTF_8);
        final ExpandableArrayBuffer buf = new ExpandableArrayBuffer();
        final OrderEncoder orderEncoder = new OrderEncoder();

        orderEncoder.wrapAndApplyHeader(buf, 0, new MessageHeaderEncoder())
            .orderId(req.getOrderId())
            .price((long)(req.getPrice() * 100))
            .quantity(req.getQuantity())
            .side((byte) req.getSide())
            .timestamp(System.currentTimeMillis())
            .putSymbol(symbolBytes, 0, symbolBytes.length);

        final int length = MessageHeaderEncoder.ENCODED_LENGTH + orderEncoder.encodedLength();
        return submitAndWait(buf, length);
    }

    /**
     * 向集群发送 User 消息。
     *
     * @return 发送成功时的 publication position（>0）
     */
    public long sendUser(final UserRequest req)
    {
        final byte[] usernameBytes = req.getUsername().getBytes(StandardCharsets.UTF_8);
        final byte[] emailBytes    = req.getEmail().getBytes(StandardCharsets.UTF_8);
        final ExpandableArrayBuffer buf = new ExpandableArrayBuffer();
        final UserEncoder userEncoder = new UserEncoder();

        userEncoder.wrapAndApplyHeader(buf, 0, new MessageHeaderEncoder())
            .userId(req.getUserId())
            .age(req.getAge())
            .balance((long)(req.getBalance() * 100))
            .isActive((short)(req.isActive() ? 1 : 0))
            .putUsername(usernameBytes, 0, usernameBytes.length)
            .putEmail(emailBytes, 0, emailBytes.length);

        final int length = MessageHeaderEncoder.ENCODED_LENGTH + userEncoder.encodedLength();
        return submitAndWait(buf, length);
    }

    /** 查询集群连接状态（HTTP 线程安全，只读 volatile 引用） */
    public SenderStatus status()
    {
        final AeronCluster cluster = aeronCluster;
        if (cluster == null || cluster.isClosed())
        {
            return new SenderStatus(false, -1, -1, -1);
        }
        return new SenderStatus(
            true,
            cluster.clusterSessionId(),
            cluster.leaderMemberId(),
            cluster.leadershipTermId());
    }

    // ──────────────────────────────────────────────
    // duty-cycle 线程
    // ──────────────────────────────────────────────

    private void startDutyCycle()
    {
        running         = true;
        dutyCycleThread = new Thread(this::dutyCycle, "aeron-duty-cycle");
        dutyCycleThread.setDaemon(true);
        dutyCycleThread.start();
        System.out.println("[Sender] DutyCycle thread started");
    }

    /**
     * Duty-cycle 主循环，独占访问 {@link AeronCluster}，无需任何锁。
     *
     * <p>与官方 {@code BasicAuctionClusterClient.bidInAuction()} 逻辑一致：
     * <ol>
     *   <li>pollEgress — 接收响应 / Leader 变更通知</li>
     *   <li>发送消息  — 从队列取出待发消息，调用 offer</li>
     *   <li>keep-alive — 超过 1 秒无 offer 时主动发送心跳</li>
     * </ol>
     */
    private void dutyCycle()
    {
        final BackoffIdleStrategy idle = new BackoffIdleStrategy();
        long keepAliveDeadlineMs = System.currentTimeMillis() + KEEP_ALIVE_INTERVAL_MS;

        while (running && !Thread.currentThread().isInterrupted())
        {
            int workCount = 0;

            // 1. pollEgress：接收集群响应；收到 NewLeaderEvent 时内部自动切换 ingress publication
            if (aeronCluster != null && !aeronCluster.isClosed())
            {
                workCount += aeronCluster.pollEgress();
            }

            // 2. 尝试发送队列首条消息（peek 不移除，失败时下次循环重试）
            final PendingMessage msg = sendQueue.peek();
            if (msg != null)
            {
                if (aeronCluster == null || aeronCluster.isClosed())
                {
                    reconnect();
                }

                final long result = aeronCluster.offer(msg.buffer(), 0, msg.length());

                if (result > 0)
                {
                    // 发送成功：移出队列，通知 HTTP 线程
                    sendQueue.poll();
                    msg.future().complete(result);
                    keepAliveDeadlineMs = System.currentTimeMillis() + KEEP_ALIVE_INTERVAL_MS;
                    workCount++;
                }
                else if (result == Publication.CLOSED)
                {
                    reconnect(); // 重连后下次循环继续重试同一条消息
                }
                else if (result == Publication.MAX_POSITION_EXCEEDED)
                {
                    sendQueue.poll();
                    msg.future().completeExceptionally(
                        new IllegalStateException("[Sender] Max position exceeded"));
                }
                // BACK_PRESSURED / NOT_CONNECTED / ADMIN_ACTION：留队列，下次循环重试
            }

            // 3. keep-alive：与官方 demo 一致，超过 1 秒无 offer 则发送心跳
            final long nowMs = System.currentTimeMillis();
            if (nowMs >= keepAliveDeadlineMs)
            {
                if (aeronCluster != null && !aeronCluster.isClosed())
                {
                    aeronCluster.sendKeepAlive();
                }
                keepAliveDeadlineMs = nowMs + KEEP_ALIVE_INTERVAL_MS;
            }

            idle.idle(workCount);
        }
    }

    // ──────────────────────────────────────────────
    // 重连（仅由 duty-cycle 线程调用）
    // ──────────────────────────────────────────────

    private void reconnect()
    {
        if (aeronCluster != null && !aeronCluster.isClosed())
        {
            return;
        }

        System.out.println("[Sender] Session closed, reconnecting...");
        CloseHelper.quietClose(aeronCluster);

        final String ingressEndpoints = resolveIngressEndpoints();
        Exception lastException = null;

        for (int attempt = 1; attempt <= MAX_RECONNECT_ATTEMPTS; attempt++)
        {
            try
            {
                System.out.println("[Sender] Reconnect attempt " + attempt + "/" + MAX_RECONNECT_ATTEMPTS);
                aeronCluster = AeronCluster.connect(buildClusterContext(ingressEndpoints));
                System.out.println("[Sender] Reconnected, sessionId=" + aeronCluster.clusterSessionId()
                    + ", leader=" + aeronCluster.leaderMemberId());
                return;
            }
            catch (final Exception e)
            {
                lastException = e;
                System.err.println("[Sender] Reconnect attempt " + attempt + " failed: " + e.getMessage());
                if (attempt < MAX_RECONNECT_ATTEMPTS)
                {
                    try { Thread.sleep(RECONNECT_DELAY_MS); }
                    catch (final InterruptedException ie)
                    {
                        Thread.currentThread().interrupt();
                        throw new IllegalStateException("Interrupted during reconnect", ie);
                    }
                }
            }
        }

        throw new IllegalStateException(
            "[Sender] Failed to reconnect after " + MAX_RECONNECT_ATTEMPTS + " attempts", lastException);
    }

    // ──────────────────────────────────────────────
    // 私有工具
    // ──────────────────────────────────────────────

    /**
     * 将编码好的消息提交到队列，阻塞等待 duty-cycle 线程发送完成。
     *
     * @param buf    已编码的消息缓冲区（由 HTTP 线程编码，duty-cycle 线程只读）
     * @param length 消息字节长度
     * @return publication position
     */
    private long submitAndWait(final ExpandableArrayBuffer buf, final int length)
    {
        final CompletableFuture<Long> future = new CompletableFuture<>();
        sendQueue.offer(new PendingMessage(buf, length, future));
        try
        {
            return future.get(5, TimeUnit.SECONDS);
        }
        catch (final Exception e)
        {
            future.cancel(false);
            throw new IllegalStateException("[Sender] Send timed out or interrupted", e);
        }
    }

    private AeronCluster.Context buildClusterContext(final String ingressEndpoints)
    {
        return new AeronCluster.Context()
            .aeronDirectoryName(mediaDriver.aeronDirectoryName())
            .ingressChannel("aeron:udp")
            .ingressEndpoints(ingressEndpoints)
            .egressListener(new HtxEgressListener())
            .egressChannel("aeron:udp?endpoint=localhost:0")
            .errorHandler(t -> System.err.println("[Sender] Error: " + t.getMessage()));
    }

    private String resolveIngressEndpoints()
    {
        if (senderProps.hasIngressEndpoints())
        {
            return senderProps.getIngressEndpoints();
        }
        return clusterProps.ingressEndpoints();
    }

    // ──────────────────────────────────────────────
    // 内部类型
    // ──────────────────────────────────────────────

    /** duty-cycle 线程与 HTTP 线程之间传递待发消息的载体 */
    private record PendingMessage(
        ExpandableArrayBuffer  buffer,
        int                    length,
        CompletableFuture<Long> future) {}

    public record SenderStatus(
        boolean connected,
        long    sessionId,
        int     leaderMemberId,
        long    leadershipTermId) {}
}
