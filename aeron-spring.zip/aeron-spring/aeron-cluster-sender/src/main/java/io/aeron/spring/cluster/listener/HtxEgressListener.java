package io.aeron.spring.cluster.listener;

import io.aeron.cluster.client.EgressListener;
import io.aeron.cluster.codecs.AdminRequestType;
import io.aeron.cluster.codecs.AdminResponseCode;
import io.aeron.cluster.codecs.EventCode;
import io.aeron.logbuffer.Header;
import org.agrona.DirectBuffer;

import java.nio.charset.StandardCharsets;

/**
 * The type Htx egress listener.
 */
public class HtxEgressListener implements EgressListener {
    
    @Override
    public void onMessage(
            final long clusterSessionId,
            final long timestamp,
            final DirectBuffer buf,
            final int offset,
            final int length,
            final Header header)
    {
        final byte[] bytes = new byte[length];
        buf.getBytes(offset, bytes);
        System.out.println("[Sender] Cluster response: " + new String(bytes, StandardCharsets.UTF_8));
    }
    
    @Override
    public void onSessionEvent(
            final long correlationId,
            final long clusterSessionId,
            final long leadershipTermId,
            final int leaderMemberId,
            final EventCode code,
            final String detail)
    {
        System.out.println("[Sender] SessionEvent: code=" + code
                + ", detail=" + detail + ", leader=" + leaderMemberId);
    }
    
    @Override
    public void onNewLeader(
            final long clusterSessionId,
            final long leadershipTermId,
            final int leaderMemberId,
            final String endpoints)
    {
        System.out.println("[Sender] New Leader: memberId=" + leaderMemberId + ", term=" + leadershipTermId);
    }

    @Override
    public void onAdminResponse(
            final long clusterSessionId,
            final long correlationId,
            final AdminRequestType requestType,
            final AdminResponseCode responseCode,
            final String message,
            final DirectBuffer payload,
            final int payloadOffset,
            final int payloadLength)
    {
        System.out.println("[Sender] AdminResponse: type=" + requestType
                + ", code=" + responseCode
                + ", correlationId=" + correlationId
                + (message != null && !message.isEmpty() ? ", msg=" + message : ""));
    }
}
