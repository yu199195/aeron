package io.aeron.spring.cluster.sender;

import io.aeron.spring.cluster.model.OrderRequest;
import io.aeron.spring.cluster.model.UserRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * REST 接口：通过 HTTP 向 Aeron Cluster 发送消息。
 * <p>
 * <b>接口列表</b>：
 * <pre>
 * GET  /cluster/sender/status            - 查询连接状态
 * POST /cluster/sender/order             - 发送 Order 消息
 * POST /cluster/sender/user              - 发送 User 消息
 * </pre>
 *
 * <b>发送 Order 示例</b>：
 * <pre>
 * curl -X POST http://localhost:8090/cluster/sender/order \
 *   -H "Content-Type: application/json" \
 *   -d '{"orderId":1001,"symbol":"AAPL","price":150.50,"quantity":100,"side":"B"}'
 * </pre>
 *
 * <b>发送 User 示例</b>：
 * <pre>
 * curl -X POST http://localhost:8090/cluster/sender/user \
 *   -H "Content-Type: application/json" \
 *   -d '{"userId":2001,"username":"alice","email":"alice@example.com","age":25,"balance":1000.50}'
 * </pre>
 */
@RestController
@RequestMapping("/cluster/sender")
public class ClusterSenderController
{
    private final ClusterSenderService senderService;

    public ClusterSenderController(final ClusterSenderService senderService)
    {
        this.senderService = senderService;
    }

    /**
     * GET /cluster/sender/status
     */
    @GetMapping("/status")
    public ClusterSenderService.SenderStatus status()
    {
        return senderService.status();
    }

    /**
     * POST /cluster/sender/order
     */
    @PostMapping("/order")
    public ResponseEntity<Map<String, Object>> sendOrder(@RequestBody final OrderRequest req)
    {
        final long position = senderService.sendOrder(req);
        if (position > 0)
        {
            return ResponseEntity.ok(Map.of(
                "success", true,
                "position", position,
                "orderId", req.getOrderId(),
                "symbol", req.getSymbol()));
        }
        else
        {
            return ResponseEntity.internalServerError().body(Map.of(
                "success", false,
                "error", "Send failed, result=" + position));
        }
    }

    /**
     * POST /cluster/sender/user
     */
    @PostMapping("/user")
    public ResponseEntity<Map<String, Object>> sendUser(@RequestBody final UserRequest req)
    {
        final long position = senderService.sendUser(req);
        if (position > 0)
        {
            return ResponseEntity.ok(Map.of(
                "success", true,
                "position", position,
                "userId", req.getUserId(),
                "username", req.getUsername()));
        }
        else
        {
            return ResponseEntity.internalServerError().body(Map.of(
                "success", false,
                "error", "Send failed, result=" + position));
        }
    }
}
