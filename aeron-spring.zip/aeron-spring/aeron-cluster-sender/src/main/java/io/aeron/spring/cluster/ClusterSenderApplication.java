package io.aeron.spring.cluster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

/**
 * cluster-sender 启动入口。
 * <p>
 * 作为独立客户端连接到 Aeron Cluster，通过 REST API 发送消息。
 *
 * <h3>启动示例</h3>
 * <pre>
 * # 连接本地集群（自动从 cluster 配置生成 ingress endpoints）
 * java -jar cluster-sender.jar
 *
 * # 连接远程集群（手动指定 ingress endpoints）
 * java -jar cluster-sender.jar \
 *   --aeron.sender.ingress-endpoints="0=192.168.1.100:9002,1=192.168.1.101:9102,2=192.168.1.102:9202" \
 *   --server.port=8090
 * </pre>
 *
 * <h3>REST 接口</h3>
 * <pre>
 * GET  /cluster/sender/status    - 查询连接状态
 * POST /cluster/sender/order     - 发送 Order 消息
 * POST /cluster/sender/user      - 发送 User 消息
 * </pre>
 */
@SpringBootApplication
@EnableConfigurationProperties
public class ClusterSenderApplication
{
    public static void main(final String[] args)
    {
        SpringApplication.run(ClusterSenderApplication.class, args);
    }
}
