package io.aeron.spring.cluster.config;

import io.aeron.spring.cluster.util.ClusterPortConfig;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.stereotype.Component;

/**
 * Aeron Cluster 配置属性，绑定 application.yml 中的 aeron.cluster.* 前缀。
 * <p>
 * cluster-sender 使用此配置自动生成 ingress endpoints（当 SenderProperties 未显式配置时）。
 */
@Data
@Component
@ConfigurationProperties(prefix = "aeron.cluster")
public class ClusterProperties
{
    /** 集群主机列表（逗号分隔） */
    private String hostnames = "localhost,localhost,localhost";

    /** 端口基础值 */
    private int portBase = 9000;

    /** MediaDriver 调优配置 */
    @NestedConfigurationProperty
    private MediaDriverProperties mediaDriver = new MediaDriverProperties();

    /** Aeron 客户端配置 */
    @NestedConfigurationProperty
    private AeronContextProperties aeron = new AeronContextProperties();

    /** 将逗号分隔的 hostnames 字符串转为 List */
    public java.util.List<String> hostnameList()
    {
        return java.util.Arrays.asList(hostnames.split(","));
    }

    /**
     * 根据 hostnames 和 portBase 自动生成 ingress endpoints 字符串。
     *
     * @see ClusterPortConfig#ingressEndpoints(java.util.List, int)
     */
    public String ingressEndpoints()
    {
        return ClusterPortConfig.ingressEndpoints(hostnameList(), portBase);
    }
}
