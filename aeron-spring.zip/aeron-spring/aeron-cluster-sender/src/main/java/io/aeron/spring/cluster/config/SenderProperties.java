package io.aeron.spring.cluster.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Aeron Cluster Sender 配置属性，绑定 application.yml 中的 aeron.sender.* 前缀。
 */
@Data
@Component
@ConfigurationProperties(prefix = "aeron.sender")
public class SenderProperties
{
    /**
     * Ingress endpoints 字符串（"0=host:port,1=host:port,..."）。
     * 为空时由 ClusterProperties 自动生成。
     */
    private String ingressEndpoints = "";

    public boolean hasIngressEndpoints()
    {
        return ingressEndpoints != null && !ingressEndpoints.isBlank();
    }
}
